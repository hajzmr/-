<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$message = '';
$error   = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = sanitize($_POST['name']    ?? '');
    $phone   = sanitize($_POST['phone']   ?? '');
    $email   = sanitize($_POST['email']   ?? '');
    $subject = sanitize($_POST['subject'] ?? '');
    $body    = sanitize($_POST['body']    ?? '');

    if (!$name || !$phone || !$body) {
        $error = 'يرجى تعبئة الاسم ورقم الهاتف والرسالة.';
    } else {
        try {
            $db = getDB();
            ensureContactMessagesTable($db);
            $stmt = $db->prepare("INSERT INTO contact_messages (name,phone,email,subject,body,created_at) VALUES (?,?,?,?,?,?)");
            $stmt->execute([$name, $phone, $email, $subject, $body, date('Y-m-d H:i:s')]);
        } catch (Exception $e) { /* تجاهل خطأ قاعدة البيانات */ }
        $message = 'تم استلام رسالتك بنجاح! سنتواصل معك قريباً.';
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>اتصل بنا - نقل موريتانيا</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --green-dark:  #0a4f3a;
    --green-mid:   #1a7a58;
    --green-light: #2db37e;
    --gold:        #c8a227;
    --sand:        #f5f0e8;
    --red-flag:    #d63031;
}
* { box-sizing: border-box; }
body { font-family: 'Segoe UI', Tahoma, sans-serif; background: var(--sand); color: #1a1a1a; margin: 0; }

/* ── Header ── */
.site-header { background: linear-gradient(135deg, var(--green-dark) 0%, var(--green-mid) 60%, var(--green-light) 100%); box-shadow: 0 2px 12px rgba(0,0,0,.25); }
.header-top  { display: flex; align-items: center; justify-content: space-between; padding: 12px 1.5rem; border-bottom: 2px solid var(--gold); flex-wrap: wrap; gap: 10px; }
.logo-area   { display: flex; align-items: center; gap: 10px; }
.logo-icon   { width: 48px; height: 48px; background: var(--gold); border-radius: 50%; display: flex; align-items: center; justify-content: center; flex-shrink: 0; }
.logo-icon i { font-size: 1.4rem; color: #fff; }
.logo-text h1 { color: #fff; font-size: 1.2rem; font-weight: 800; margin: 0; white-space: nowrap; }
.logo-text p  { color: rgba(255,255,255,.75); font-size: .75rem; margin: 0; }
.header-nav  { display: flex; flex-wrap: wrap; gap: .25rem; background: rgba(255,255,255,.1); border-radius: 30px; padding: 4px; }
.header-nav a { color: rgba(255,255,255,.85); text-decoration: none; padding: .35rem .9rem; border-radius: 25px; font-size: .85rem; font-weight: 500; transition: all .2s; white-space: nowrap; }
.header-nav a:hover, .header-nav a.active { background: var(--gold); color: #fff; }
.flag-stripe { height: 6px; background: linear-gradient(90deg, var(--green-mid) 0%, var(--green-mid) 33%, var(--gold) 33%, var(--gold) 66%, var(--red-flag) 66%); }

/* ── Hero ── */
.contact-hero { background: linear-gradient(135deg, var(--green-dark), var(--green-mid)); padding: 2.2rem 1rem; text-align: center; color: #fff; }
.contact-hero h2 { font-size: 1.7rem; font-weight: 800; margin-bottom: .4rem; }
.contact-hero p  { color: rgba(255,255,255,.8); font-size: .95rem; margin: 0; }

/* ── Cards ── */
.info-card  { background: #fff; border-radius: 14px; padding: 1.3rem; box-shadow: 0 3px 14px rgba(0,0,0,.08); height: 100%; }
.info-icon  { width: 50px; height: 50px; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 1.2rem; margin-bottom: .8rem; flex-shrink: 0; }
.form-card  { background: #fff; border-radius: 14px; padding: 1.5rem; box-shadow: 0 3px 14px rgba(0,0,0,.08); }

/* ── Form ── */
.form-label   { font-weight: 600; color: var(--green-dark); font-size: .88rem; margin-bottom: .3rem; display: block; }
.form-control, .form-select { border-radius: 9px; border: 1.5px solid #ddd; padding: .65rem .9rem; font-size: .93rem; width: 100%; transition: border .2s; }
.form-control:focus, .form-select:focus { border-color: var(--green-mid); box-shadow: 0 0 0 3px rgba(26,122,88,.1); outline: none; }
.btn-submit { background: var(--green-mid); color: #fff; border: none; border-radius: 10px; padding: .85rem; font-size: 1rem; font-weight: 700; width: 100%; cursor: pointer; transition: background .2s; }
.btn-submit:hover { background: var(--green-dark); }

/* ── FAQ ── */
.faq-item { background: #fff; border-radius: 11px; padding: 1rem 1.2rem; margin-bottom: .7rem; box-shadow: 0 2px 8px rgba(0,0,0,.06); cursor: pointer; border-right: 4px solid var(--green-light); }
.faq-item .q { font-weight: 700; color: var(--green-dark); font-size: .93rem; }
.faq-item .a { color: #555; font-size: .88rem; margin-top: .5rem; display: none; line-height: 1.6; }
.faq-item.open .a { display: block; }
.faq-item.open { border-right-color: var(--gold); }

/* ── Map placeholder ── */
.map-placeholder { background: linear-gradient(135deg, #e8f5f0, #d0ede3); border-radius: 12px; height: 180px; display: flex; align-items: center; justify-content: center; flex-direction: column; color: var(--green-mid); }

/* ── Footer ── */
footer { background: var(--green-dark); color: rgba(255,255,255,.75); padding: 1.5rem 1rem; text-align: center; margin-top: 3rem; }
footer a { color: var(--gold); text-decoration: none; }

/* ── Mobile ── */
@media (max-width: 576px) {
    .header-top  { padding: 10px 1rem; }
    .logo-text h1 { font-size: 1rem; }
    .logo-text p  { display: none; }
    .header-nav  { width: 100%; justify-content: center; }
    .header-nav a { padding: .3rem .7rem; font-size: .78rem; }

    .contact-hero h2 { font-size: 1.3rem; }

    .col-sm-6-mob { width: 50% !important; float: right; padding: 0 6px; }
}
</style>
</head>
<body>

<header class="site-header">
    <div class="header-top">
        <div class="logo-area">
            <div class="logo-icon"><i class="fa fa-bus"></i></div>
            <div class="logo-text">
                <h1>نقل موريتانيا</h1>
                <p>Transport Mauritanie · رحلات آمنة في كل مكان</p>
            </div>
        </div>
        <nav class="header-nav">
            <a href="index.php">الرئيسية</a>
            <a href="routes.php">الرحلات</a>
            <a href="check-booking.php">تتبع حجزك</a>
            <a href="contact.php" class="active">اتصل بنا</a>
        </nav>
    </div>
    <div class="flag-stripe"></div>
</header>

<div class="contact-hero">
    <h2><i class="fa fa-headset me-2"></i>اتصل بنا</h2>
    <p>نحن هنا لمساعدتك — تواصل معنا بأي طريقة تناسبك</p>
</div>

<div class="container py-4">

    <?php if ($message): ?>
    <div class="alert alert-success border-0 shadow-sm rounded-3 mb-3">
        <i class="fa fa-check-circle me-2"></i><?= $message ?>
    </div>
    <?php endif; ?>
    <?php if ($error): ?>
    <div class="alert alert-danger border-0 shadow-sm rounded-3 mb-3">
        <i class="fa fa-exclamation-circle me-2"></i><?= $error ?>
    </div>
    <?php endif; ?>

    <!-- صف معلومات التواصل -->
    <div class="row g-3 mb-4">
        <div class="col-6 col-md-3">
            <div class="info-card text-center">
                <div class="info-icon mx-auto" style="background:#e8f5f0;color:var(--green-mid);">
                    <i class="fa fa-phone"></i>
                </div>
                <h6 class="fw-bold mb-1" style="font-size:.88rem;">الهاتف</h6>
                <a href="tel:+22241010052" class="text-decoration-none fw-bold d-block" style="color:var(--green-mid);font-size:.85rem;">22241010052</a>
                <small class="text-muted">24/7</small>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="info-card text-center">
                <div class="info-icon mx-auto" style="background:#fff8e1;color:var(--gold);">
                    <i class="fa fa-envelope"></i>
                </div>
                <h6 class="fw-bold mb-1" style="font-size:.88rem;">الإيميل</h6>
                <a href="mailto:info@hajzmr.com" class="text-decoration-none d-block" style="color:var(--green-mid);font-size:.82rem;">info@hajzmr.com</a>
                <a href="mailto:support@hajzmr.com" class="text-muted d-block" style="font-size:.78rem;">support@hajzmr.com</a>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="info-card text-center">
                <div class="info-icon mx-auto" style="background:#ffeaea;color:#e74c3c;">
                    <i class="fa fa-map-marker-alt"></i>
                </div>
                <h6 class="fw-bold mb-1" style="font-size:.88rem;">العنوان</h6>
                <p class="text-muted mb-0" style="font-size:.82rem;">شارع الاستقلال<br>نواكشوط</p>
                <small class="text-muted" style="font-size:.76rem;">س — خ: 8:00–18:00</small>
            </div>
        </div>
        <div class="col-6 col-md-3">
            <div class="info-card text-center d-flex flex-column justify-content-between">
                <div>
                    <div class="info-icon mx-auto" style="background:#e8fff0;color:#25d366;">
                        <i class="fab fa-whatsapp"></i>
                    </div>
                    <h6 class="fw-bold mb-1" style="font-size:.88rem;">واتساب</h6>
                    <p class="text-muted mb-2" style="font-size:.82rem;">دعم سريع</p>
                </div>
                <a href="https://wa.me/+22241010052" target="_blank"
                   style="background:#25d366;color:#fff;border-radius:8px;padding:.4rem .6rem;text-decoration:none;font-size:.83rem;font-weight:700;display:block;">
                    <i class="fab fa-whatsapp me-1"></i>ابدأ محادثة
                </a>
            </div>
        </div>
    </div>

    <!-- نموذج التواصل -->
    <div class="form-card mb-4">
        <h5 class="fw-bold mb-1" style="color:var(--green-dark);">
            <i class="fa fa-paper-plane me-2 text-success"></i>أرسل لنا رسالة
        </h5>
        <p class="text-muted mb-3" style="font-size:.87rem;">سنرد عليك في أقرب وقت ممكن خلال ساعات العمل.</p>

        <form method="POST">
            <div class="row g-3">
                <div class="col-12 col-sm-6">
                    <label class="form-label">الاسم الكامل *</label>
                    <input type="text" name="name" class="form-control" placeholder="أحمد ولد محمد" required
                           value="<?= htmlspecialchars($_POST['name']??'') ?>">
                </div>
                <div class="col-12 col-sm-6">
                    <label class="form-label">رقم الهاتف *</label>
                    <input type="tel" name="phone" class="form-control" placeholder="220 XX XX XX" required
                           value="<?= htmlspecialchars($_POST['phone']??'') ?>">
                </div>
                <div class="col-12 col-sm-6">
                    <label class="form-label">البريد الإلكتروني <span class="text-muted fw-normal">(اختياري)</span></label>
                    <input type="email" name="email" class="form-control" placeholder="example@email.com"
                           value="<?= htmlspecialchars($_POST['email']??'') ?>">
                </div>
                <div class="col-12 col-sm-6">
                    <label class="form-label">موضوع الرسالة</label>
                    <select name="subject" class="form-select">
                        <option value="استفسار"      <?= ($_POST['subject']??'')==='استفسار'     ?'selected':'' ?>>استفسار عام</option>
                        <option value="شكوى"         <?= ($_POST['subject']??'')==='شكوى'        ?'selected':'' ?>>شكوى</option>
                        <option value="اقتراح"       <?= ($_POST['subject']??'')==='اقتراح'      ?'selected':'' ?>>اقتراح</option>
                        <option value="إلغاء حجز"   <?= ($_POST['subject']??'')==='إلغاء حجز'  ?'selected':'' ?>>إلغاء حجز</option>
                        <option value="استرداد مبلغ" <?= ($_POST['subject']??'')==='استرداد مبلغ'?'selected':'' ?>>استرداد مبلغ</option>
                        <option value="أخرى"         <?= ($_POST['subject']??'')==='أخرى'        ?'selected':'' ?>>أخرى</option>
                    </select>
                </div>
                <div class="col-12">
                    <label class="form-label">الرسالة *</label>
                    <textarea name="body" class="form-control" rows="4"
                              placeholder="اكتب رسالتك هنا..."
                              required><?= htmlspecialchars($_POST['body']??'') ?></textarea>
                </div>
                <div class="col-12">
                    <button type="submit" class="btn-submit">
                        <i class="fa fa-paper-plane me-2"></i>إرسال الرسالة
                    </button>
                </div>
            </div>
        </form>
    </div>

    <!-- الموقع -->
    <div class="map-placeholder mb-5">
        <i class="fa fa-map-marked-alt fa-2x mb-2 opacity-50"></i>
        <p class="fw-bold mb-0" style="font-size:.95rem;">نواكشوط، موريتانيا</p>
        <small class="text-muted">شارع الاستقلال — المقر الرئيسي</small>
    </div>

    <!-- الأسئلة الشائعة -->
    <h5 class="fw-bold mb-3" style="color:var(--green-dark);">
        <i class="fa fa-question-circle me-2 text-success"></i>الأسئلة الشائعة
    </h5>
    <?php
    $faqs = [
        ['q'=>'كيف يمكنني إلغاء حجزي؟',       'a'=>'يمكنك إلغاء الحجز من صفحة "تتبع حجزك" باستخدام رقم الحجز، أو التواصل معنا على الهاتف أو واتساب قبل موعد الرحلة بـ 24 ساعة على الأقل.'],
        ['q'=>'هل يمكنني تعديل تاريخ السفر؟',  'a'=>'نعم، يمكنك تعديل تاريخ السفر بالتواصل مع خدمة العملاء. يُرجى التواصل قبل 12 ساعة من موعد الرحلة.'],
        ['q'=>'ما هي طرق الدفع المتاحة؟',      'a'=>'نقبل الدفع نقداً، عبر الهاتف (Masrvi/Bankily)، وعبر البطاقات البنكية في مكاتبنا.'],
        ['q'=>'هل هناك خصومات للمجموعات؟',     'a'=>'نعم، نوفر خصومات للمجموعات المكونة من 10 أشخاص فأكثر. تواصل معنا مسبقاً للحصول على عرض خاص.'],
    ];
    foreach ($faqs as $faq): ?>
    <div class="faq-item" onclick="this.classList.toggle('open')">
        <div class="q"><i class="fa fa-chevron-left me-2" style="font-size:.72rem;"></i><?= $faq['q'] ?></div>
        <div class="a"><?= $faq['a'] ?></div>
    </div>
    <?php endforeach; ?>

</div>

<footer>
    <p class="mb-1">© <?= date('Y') ?> نقل موريتانيا — Transport Mauritanie</p>
    <p class="mb-0 small">
        <a href="index.php">الرئيسية</a> |
        <a href="check-booking.php">تتبع الحجز</a> |
        <a href="contact.php">اتصل بنا</a> |
        <a href="admin/login.php">لوحة الإدارة</a>
    </p>
</footer>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
</body>
</html>
