<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: index.php');
    exit;
}

// التحقق من البيانات
$routeId        = (int)($_POST['route_id'] ?? 0);
$travelDate     = sanitize($_POST['travel_date'] ?? '');
$passengerName  = sanitize($_POST['passenger_name'] ?? '');
$passengerPhone = sanitize($_POST['passenger_phone'] ?? '');
$passengerId    = sanitize($_POST['passenger_id'] ?? '');
$seatCount      = max(1, (int)($_POST['seat_count'] ?? 1));
$paymentMethod  = sanitize($_POST['payment_method'] ?? '');
// Validate payment method
if (!in_array($paymentMethod, ['bankily','masrafi'])) {
    header('Location: index.php?error=invalid_payment');
    exit;
}
$notes          = sanitize($_POST['notes'] ?? '');
$pricePer       = (float)($_POST['price_per'] ?? 0);

if (!$passengerName || !$passengerPhone || !$routeId || !$travelDate) {
    header('Location: index.php?error=missing_fields');
    exit;
}

// جلب بادئة اسم ممثل الشركة ومعرّف الشركة من الرحلة
$repPrefix  = 'MRT';
$companyId  = 0;
try {
    $dbTemp = getDB();
    // جلب company_id المرتبط بالرحلة
    $stmtC = $dbTemp->prepare(
        "SELECT r.company_id,
                u.username AS rep_username
         FROM routes r
         LEFT JOIN users u ON u.company_id = r.company_id
                           AND u.role = 'company_rep'
                           AND u.active = 1
         WHERE r.id = ?
         LIMIT 1"
    );
    $stmtC->execute([$routeId]);
    $companyRow = $stmtC->fetch(PDO::FETCH_ASSOC);
    if ($companyRow) {
        $companyId = (int)($companyRow['company_id'] ?? 0);
        $repUsername = $companyRow['rep_username'] ?? '';
        if ($repUsername) {
            // أول 3 أحرف من اسم الدخول (دائماً لاتيني)
            $latinOnly = preg_replace('/[^A-Za-z]/', '', $repUsername);
            $repPrefix = strtoupper(str_pad(substr($latinOnly, 0, 3), 3, 'X'));
        }
    }
} catch (Exception $e) {
    // نبقى على القيم الافتراضية
}

$bookingRef  = generateBookingRef($repPrefix, $companyId);
$totalPrice  = $seatCount * $pricePer;
$createdAt   = date('Y-m-d H:i:s');

// رفع وصل الدفع إن وُجد
$receiptPath = null;
if (!empty($_FILES['payment_receipt']['tmp_name']) && $_FILES['payment_receipt']['error'] === 0) {
    $file    = $_FILES['payment_receipt'];
    $allowed = ['image/jpeg','image/jpg','image/png','image/gif'];
    if (in_array($file['type'], $allowed) && $file['size'] <= 5 * 1024 * 1024) {
        $uploadDir = __DIR__ . '/uploads/receipts/';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }
        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $safeName = 'receipt_' . preg_replace('/[^A-Z0-9\-]/', '', strtoupper($bookingRef)) . '_' . time() . '.' . $ext;
        $dest     = $uploadDir . $safeName;
        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $receiptPath = 'uploads/receipts/' . $safeName;
        }
    }
}

try {
    $db = getDB();

    // التحقق من المقاعد المتاحة
    $booked = getBookedSeats($routeId, $travelDate);
    $stmt = $db->prepare("SELECT seats_total FROM routes WHERE id = ?");
    $stmt->execute([$routeId]);
    $route = $stmt->fetch(PDO::FETCH_ASSOC);
    $available = $route['seats_total'] - $booked;

    if ($seatCount > $available) {
        header("Location: index.php?error=no_seats");
        exit;
    }

    // تحديد الحالة بناءً على وجود الوصل
    $status = $receiptPath ? 'payment_pending' : 'pending';

    // إدراج الحجز
    $stmt = $db->prepare("INSERT INTO bookings 
        (booking_ref, route_id, passenger_name, passenger_phone, passenger_id,
         seat_count, travel_date, total_price, status, payment_method, payment_receipt, notes, created_at)
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?)");
    $stmt->execute([
        $bookingRef, $routeId, $passengerName, $passengerPhone, $passengerId,
        $seatCount, $travelDate, $totalPrice, $status, $paymentMethod, $receiptPath, $notes, $createdAt
    ]);

} catch (Exception $e) {
    // في بيئة التطوير نحاكي النجاح
    $bookingRef = generateBookingRef($repPrefix, $companyId);
    $totalPrice = $seatCount * $pricePer;
}

// إعادة التوجيه إلى صفحة التأكيد
header("Location: booking-confirmation.php?ref=" . urlencode($bookingRef) . 
       "&name=" . urlencode($passengerName) . 
       "&seats=" . $seatCount . 
       "&total=" . $totalPrice . 
       "&date=" . urlencode($travelDate));
exit;
?>
