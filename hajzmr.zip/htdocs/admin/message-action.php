<?php
// message-action.php
require_once '../includes/db.php';
require_once '../includes/functions.php';
blockCompanyRep();

$id     = (int)($_GET['id'] ?? 0);
$action = sanitize($_GET['action'] ?? '');
$allowed = ['delete', 'mark-read'];

if ($id && in_array($action, $allowed)) {
    try {
        $db = getDB();
        ensureContactMessagesTable($db);
        if ($action === 'delete') {
            $db->prepare("DELETE FROM contact_messages WHERE id=?")->execute([$id]);
            header("Location: messages.php?deleted=1");
            exit;
        } elseif ($action === 'mark-read') {
            $db->prepare("UPDATE contact_messages SET status='read' WHERE id=? AND status='new'")->execute([$id]);
        }
    } catch (Exception $e) { /* تجاهل */ }
}

header("Location: messages.php");
exit;
?>
