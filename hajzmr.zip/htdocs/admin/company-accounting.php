<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();
// صفحة عرض فقط (لا تعديل إطلاقاً) — متاحة للمدير/المشرف لكل الشركات،
// ولممثل الشركة مقصورة تلقائياً على شركته فقط.

$isRep        = isCompanyRep();
$repCompanyId = getSessionCompanyId();

$companyFilter = $isRep ? $repCompanyId : (int)($_GET['company_id'] ?? 0);
$yearFilter    = (int)($_GET['year'] ?? date('Y'));

// ============================================================
// تصدير PDF — جرد تفصيلي لكل حجز + ملخص حسب الشركة + مجموع كلي
// (تنسيق PDF حقيقي عبر مكتبة TCPDF، يدعم العربية RTL بشكل كامل
//  ويُقرأ بشكل صحيح ومنسق على كل الأجهزة، خلافاً لملف Excel السابق)
// ============================================================
if (isset($_GET['export']) && $_GET['export'] === 'pdf') {
    $exportRows  = [];
    $exportTotal = 0;
    $companyNameForTitle = '';
    $summaryRows = []; // ملخص: إجمالي لكل شركة

    try {
        $db = getDB();
        $sql = "SELECT c.name AS company_name, b.booking_ref, b.passenger_name, b.passenger_phone,
                       r.from_city, r.to_city, b.travel_date, b.seat_count, b.payment_method,
                       b.created_at, b.total_price
                FROM bookings b
                JOIN routes r ON b.route_id = r.id
                JOIN companies c ON r.company_id = c.id
                WHERE b.status = 'confirmed'
                  AND YEAR(b.created_at) = ?";
        $params = [$yearFilter];
        if ($companyFilter) { $sql .= " AND c.id = ?"; $params[] = $companyFilter; }
        $sql .= " ORDER BY c.name, b.created_at DESC";
        $stmt = $db->prepare($sql);
        $stmt->execute($params);
        $exportRows = $stmt->fetchAll(PDO::FETCH_ASSOC);
        foreach ($exportRows as $row) { $exportTotal += (float)$row['total_price']; }
        if (!empty($exportRows)) { $companyNameForTitle = $exportRows[0]['company_name']; }

        foreach ($exportRows as $row) {
            $cn = $row['company_name'];
            if (!isset($summaryRows[$cn])) { $summaryRows[$cn] = ['cnt' => 0, 'total' => 0]; }
            $summaryRows[$cn]['cnt']++;
            $summaryRows[$cn]['total'] += (float)$row['total_price'];
        }
    } catch (Exception $e) {
        $exportRows = [];
    }

    $payLabels = ['cash'=>'نقداً','mobile'=>'هاتف','card'=>'بطاقة'];
    $showCompanyCol = !$companyFilter; // عمود الشركة يظهر فقط إذا كان التقرير لعدة شركات معاً

    $titleText = $companyFilter && $companyNameForTitle
        ? 'جرد حجوزات شركة: ' . $companyNameForTitle
        : 'جرد حجوزات جميع الشركات';

    require_once '../includes/tcpdf/tcpdf.php';

    class AccountingPDF extends TCPDF {
        public $reportTitle = '';
        public $reportSubtitle = '';
        public function Header() {
            $this->SetFont('dejavusans', 'B', 14);
            $this->SetTextColor(10, 79, 58);
            $this->SetXY(10, 10);
            $this->Cell(0, 8, $this->reportTitle, 0, 1, 'C');
            $this->SetFont('dejavusans', '', 9);
            $this->SetTextColor(110, 110, 110);
            $this->Cell(0, 5, $this->reportSubtitle, 0, 1, 'C');
            $this->SetDrawColor(200, 162, 39);
            $this->SetLineWidth(0.5);
            $this->Line(10, 24, 200, 24);
            $this->SetY(28);
        }
        public function Footer() {
            $this->SetY(-15);
            $this->SetDrawColor(220, 220, 220);
            $this->Line(10, $this->GetY(), 200, $this->GetY());
            $this->SetFont('dejavusans', '', 8);
            $this->SetTextColor(140, 140, 140);
            $this->SetY(-12);
            $this->Cell(0, 10, 'صفحة ' . $this->getAliasNumPage() . ' من ' . $this->getAliasNbPages(), 0, 0, 'C');
        }
    }

    $pdf = new AccountingPDF('P', 'mm', 'A4', true, 'UTF-8', false);
    $pdf->reportTitle = $titleText;
    $pdf->reportSubtitle = 'سنة ' . $yearFilter . '  —  تاريخ الإصدار: ' . date('d/m/Y H:i');
    $pdf->setRTL(true);
    $pdf->SetCreator('نقل موريتانيا');
    $pdf->SetAuthor('نقل موريتانيا');
    $pdf->SetTitle($titleText . ' - ' . $yearFilter);
    $pdf->SetMargins(10, 32, 10);
    $pdf->SetHeaderMargin(5);
    $pdf->SetFooterMargin(10);
    $pdf->SetAutoPageBreak(true, 18);
    $pdf->setFontSubsetting(true);
    $pdf->SetFont('dejavusans', '', 9);
    $pdf->AddPage();

    // ---------- ملخص حسب الشركة ----------
    if ($showCompanyCol && count($summaryRows) > 1) {
        $html = '<table cellpadding="5" style="font-size:10px;">';
        $html .= '<tr style="background-color:#0a4f3a;color:#ffffff;font-weight:bold;">'
               . '<td width="50%">الشركة</td><td width="25%">عدد الحجوزات</td><td width="25%">الإجمالي (أوقية)</td></tr>';
        $i = 0;
        foreach ($summaryRows as $cname => $s) {
            $bg = ($i % 2 === 0) ? '#ffffff' : '#f4f6f9';
            $html .= '<tr style="background-color:' . $bg . ';">'
                   . '<td>' . htmlspecialchars($cname) . '</td>'
                   . '<td dir="ltr" style="text-align:center;">' . $s['cnt'] . '</td>'
                   . '<td dir="ltr" style="text-align:center;">' . number_format($s['total'], 0, '.', ',') . '</td></tr>';
            $i++;
        }
        $html .= '<tr style="background-color:#c8a227;color:#ffffff;font-weight:bold;">'
               . '<td>الإجمالي الكلي</td><td dir="ltr" style="text-align:center;">' . count($exportRows) . '</td>'
               . '<td>' . number_format($exportTotal, 0, '.', ',') . '</td></tr>';
        $html .= '</table>';

        $pdf->SetFont('dejavusans', 'B', 11);
        $pdf->SetTextColor(10, 79, 58);
        $pdf->Cell(0, 8, 'ملخص حسب الشركة', 0, 1, 'R');
        $pdf->writeHTML($html, true, false, true, false, '');
        $pdf->Ln(4);
    }

    // ---------- الجرد التفصيلي ----------
    $pdf->SetFont('dejavusans', 'B', 11);
    $pdf->SetTextColor(10, 79, 58);
    $pdf->Cell(0, 8, 'الجرد التفصيلي للحجوزات (' . count($exportRows) . ' حجز)', 0, 1, 'R');

    if (empty($exportRows)) {
        $pdf->SetFont('dejavusans', '', 10);
        $pdf->SetTextColor(120, 120, 120);
        $pdf->Cell(0, 10, 'لا توجد بيانات للفترة المحددة', 0, 1, 'C');
    } else {
        $html = '<table cellpadding="2" style="font-size:7.6px;">';
        $html .= '<thead><tr style="background-color:#1a7a58;color:#ffffff;font-weight:bold;">';
        if ($showCompanyCol) {
            // مع عمود الشركة: المجموع = 11+10+10+8+7+7+9+6+9+23 = 100%
            $html .= '<th width="11%" style="text-align:center;">الشركة</th>'
                   . '<th width="10%" style="text-align:center;">رقم الحجز</th>'
                   . '<th width="10%" style="text-align:center;">الراكب</th>'
                   . '<th width="8%" style="text-align:center;">الهاتف</th>'
                   . '<th width="7%" style="text-align:center;">من</th>'
                   . '<th width="7%" style="text-align:center;">إلى</th>'
                   . '<th width="9%" style="text-align:center;">تاريخ السفر</th>'
                   . '<th width="6%" style="text-align:center;">المقاعد</th>'
                   . '<th width="9%" style="text-align:center;">الدفع</th>'
                   . '<th width="23%" style="text-align:center;">المبلغ</th></tr></thead><tbody>';
        } else {
            // بدون عمود الشركة: المجموع = 12+12+10+9+9+10+7+10+21 = 100%
            $html .= '<th width="12%" style="text-align:center;">رقم الحجز</th>'
                   . '<th width="12%" style="text-align:center;">الراكب</th>'
                   . '<th width="10%" style="text-align:center;">الهاتف</th>'
                   . '<th width="9%" style="text-align:center;">من</th>'
                   . '<th width="9%" style="text-align:center;">إلى</th>'
                   . '<th width="10%" style="text-align:center;">تاريخ السفر</th>'
                   . '<th width="7%" style="text-align:center;">المقاعد</th>'
                   . '<th width="10%" style="text-align:center;">الدفع</th>'
                   . '<th width="21%" style="text-align:center;">المبلغ</th></tr></thead><tbody>';
        }

        $i = 0;
        $currentCompany = null;
        foreach ($exportRows as $row) {
            // فاصل عند تغيّر الشركة (فقط في وضع كل الشركات)
            if ($showCompanyCol && $row['company_name'] !== $currentCompany) {
                $currentCompany = $row['company_name'];
                $colCount = 9 + ($showCompanyCol ? 1 : 0);
                $html .= '<tr style="background-color:#e8f5f0;font-weight:bold;color:#0a4f3a;">'
                       . '<td colspan="' . $colCount . '">' . htmlspecialchars($currentCompany) . '</td></tr>';
            }
            $bg = ($i % 2 === 0) ? '#ffffff' : '#f8f9fa';
            $html .= '<tr style="background-color:' . $bg . ';">';
            if ($showCompanyCol) $html .= '<td>' . htmlspecialchars($row['company_name']) . '</td>';
            $html .= '<td dir="ltr" style="text-align:center;">' . htmlspecialchars($row['booking_ref']) . '</td>'
                   . '<td>' . htmlspecialchars($row['passenger_name']) . '</td>'
                   . '<td dir="ltr" style="text-align:center;">' . htmlspecialchars($row['passenger_phone']) . '</td>'
                   . '<td>' . htmlspecialchars($row['from_city']) . '</td>'
                   . '<td>' . htmlspecialchars($row['to_city']) . '</td>'
                   . '<td dir="ltr" style="text-align:center;">' . ($row['travel_date'] ? date('d/m/Y', strtotime($row['travel_date'])) : '') . '</td>'
                   . '<td>' . (int)$row['seat_count'] . '</td>'
                   . '<td>' . htmlspecialchars($payLabels[$row['payment_method']] ?? $row['payment_method']) . '</td>'
                   . '<td dir="ltr" style="text-align:center;">' . number_format((float)$row['total_price'], 0, '.', ',') . '</td></tr>';
            $i++;
        }

        $colCount = 9 + ($showCompanyCol ? 1 : 0);
        $html .= '<tr style="background-color:#c8a227;color:#ffffff;font-weight:bold;">'
               . '<td colspan="' . ($colCount - 1) . '">الإجمالي (' . count($exportRows) . ' حجز)</td>'
               . '<td dir="ltr" style="text-align:center;">' . number_format($exportTotal, 0, '.', ',') . '</td></tr>';
        $html .= '</tbody></table>';

        $pdf->writeHTML($html, true, false, true, false, '');
    }

    $filename = 'company-accounting_' . $yearFilter . '_' . date('Ymd-His') . '.pdf';
    $pdf->Output($filename, 'D');
    exit;
}

// ============================================================
// جلب البيانات للعرض
// ============================================================
$rows          = [];     // صف لكل (شركة × شهر)
$companyTotals = [];     // إجمالي سنوي لكل شركة
$companies     = [];     // لقائمة الفلترة (للمدير فقط)
$availableYears = [date('Y')];

try {
    $db = getDB();

    if (!$isRep) {
        $companies = $db->query("SELECT id, name FROM companies WHERE active=1 ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
    } elseif ($repCompanyId) {
        // اسم شركة ممثل الشركة، يُستخدم في عنوان الجدول حتى لو لم تكن لديه أي حجوزات بعد
        $coStmt = $db->prepare("SELECT id, name FROM companies WHERE id = ?");
        $coStmt->execute([$repCompanyId]);
        $repCo = $coStmt->fetch(PDO::FETCH_ASSOC);
        if ($repCo) { $companies = [$repCo]; }
    }

    // السنوات المتاحة فعلياً في بيانات الحجوزات المؤكدة (لقائمة اختيار السنة)
    $yearsStmt = $db->query("SELECT DISTINCT YEAR(created_at) AS y FROM bookings WHERE status='confirmed' ORDER BY y DESC");
    $yearsResult = $yearsStmt->fetchAll(PDO::FETCH_COLUMN);
    if (!empty($yearsResult)) { $availableYears = $yearsResult; }
    if (!in_array($yearFilter, $availableYears)) { $availableYears[] = $yearFilter; rsort($availableYears); }

    $sql = "SELECT c.id AS company_id, c.name AS company_name,
                   DATE_FORMAT(b.created_at,'%Y-%m') AS ym,
                   COUNT(*) AS cnt, SUM(b.total_price) AS total
            FROM bookings b
            JOIN routes r ON b.route_id = r.id
            JOIN companies c ON r.company_id = c.id
            WHERE b.status = 'confirmed'
              AND YEAR(b.created_at) = ?";
    $params = [$yearFilter];
    if ($companyFilter) { $sql .= " AND c.id = ?"; $params[] = $companyFilter; }
    $sql .= " GROUP BY c.id, c.name, DATE_FORMAT(b.created_at,'%Y-%m')
              ORDER BY c.name, ym DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $rows = $stmt->fetchAll(PDO::FETCH_ASSOC);

    foreach ($rows as $r) {
        $cid = $r['company_id'];
        if (!isset($companyTotals[$cid])) {
            $companyTotals[$cid] = ['name' => $r['company_name'], 'cnt' => 0, 'total' => 0];
        }
        $companyTotals[$cid]['cnt']   += (int)$r['cnt'];
        $companyTotals[$cid]['total'] += (float)$r['total'];
    }

    // جرد تفصيلي: كل حجز مؤكد على حدة بكل معلوماته
    $detailSql = "SELECT c.id AS company_id, c.name AS company_name,
                         b.id, b.booking_ref, b.passenger_name, b.passenger_phone,
                         r.from_city, r.to_city, b.travel_date, b.seat_count,
                         b.payment_method, b.created_at, b.total_price
                  FROM bookings b
                  JOIN routes r ON b.route_id = r.id
                  JOIN companies c ON r.company_id = c.id
                  WHERE b.status = 'confirmed'
                    AND YEAR(b.created_at) = ?";
    $detailParams = [$yearFilter];
    if ($companyFilter) { $detailSql .= " AND c.id = ?"; $detailParams[] = $companyFilter; }
    $detailSql .= " ORDER BY c.name, b.created_at DESC";
    $detailStmt = $db->prepare($detailSql);
    $detailStmt->execute($detailParams);
    $detailRows = $detailStmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Demo fallback لعرض شكل الصفحة عند عدم توفر اتصال حقيقي
    $companies = [['id'=>1,'name'=>'النقل الوطني الموريتاني'],['id'=>2,'name'=>'شركة الصحراء للنقل'],['id'=>4,'name'=>'طيبة']];
    $demoRows = [
        ['company_id'=>1,'company_name'=>'النقل الوطني الموريتاني','ym'=>date('Y-m'),'cnt'=>14,'total'=>70000],
        ['company_id'=>1,'company_name'=>'النقل الوطني الموريتاني','ym'=>date('Y-m',strtotime('-1 month')),'cnt'=>9,'total'=>45000],
        ['company_id'=>4,'company_name'=>'طيبة','ym'=>date('Y-m'),'cnt'=>3,'total'=>15500],
    ];
    $rows = $isRep ? array_values(array_filter($demoRows, fn($r) => $r['company_id'] == $repCompanyId)) : $demoRows;
    foreach ($rows as $r) {
        $cid = $r['company_id'];
        if (!isset($companyTotals[$cid])) { $companyTotals[$cid] = ['name'=>$r['company_name'],'cnt'=>0,'total'=>0]; }
        $companyTotals[$cid]['cnt']   += $r['cnt'];
        $companyTotals[$cid]['total'] += $r['total'];
    }

    $demoDetail = [
        ['company_id'=>1,'company_name'=>'النقل الوطني الموريتاني','id'=>247,'booking_ref'=>'MRT-A8F2C1D3','passenger_name'=>'أحمد ولد محمد','passenger_phone'=>'22001234','from_city'=>'نواكشوط','to_city'=>'نواذيبو','travel_date'=>date('Y-m-d',strtotime('+1 day')),'seat_count'=>2,'payment_method'=>'cash','created_at'=>date('Y-m-d H:i:s'),'total_price'=>10000],
        ['company_id'=>4,'company_name'=>'طيبة','id'=>7,'booking_ref'=>'MRT-TEST0001','passenger_name'=>'اختبار تجريبي','passenger_phone'=>'22000000','from_city'=>'نواكشوط','to_city'=>'نواذيبو','travel_date'=>date('Y-m-d',strtotime('+1 day')),'seat_count'=>1,'payment_method'=>'cash','created_at'=>date('Y-m-d H:i:s'),'total_price'=>5000],
    ];
    $detailRows = $isRep ? array_values(array_filter($demoDetail, fn($r) => $r['company_id'] == $repCompanyId)) : $demoDetail;
}

$grandCnt   = array_sum(array_column($companyTotals, 'cnt'));
$grandTotal = array_sum(array_column($companyTotals, 'total'));
$detailGrandTotal = array_sum(array_column($detailRows, 'total_price'));
$payLabelsAr = ['cash'=>'نقداً','mobile'=>'هاتف','card'=>'بطاقة'];

// اسم الشركة المفلترة (تُستخدم في عنوان الجدول بدل عمود متكرر لكل صف)
$filteredCompanyName = '';
if ($companyFilter) {
    if (!empty($detailRows)) {
        $filteredCompanyName = $detailRows[0]['company_name'];
    } elseif (!empty($companyTotals)) {
        $first = reset($companyTotals);
        $filteredCompanyName = $first['name'];
    } elseif ($isRep) {
        // ممثل شركة بدون أي حجوزات في الفترة: نجلب اسم شركته مباشرة من قائمة الشركات إن توفرت
        foreach ($companies as $co) { if ($co['id'] == $companyFilter) { $filteredCompanyName = $co['name']; break; } }
    }
}
$showCompanyColumn = !$companyFilter; // عمود "الشركة" يظهر فقط عند عرض عدة شركات معاً

function arMonthLabel($ym) {
    $months = ['01'=>'يناير','02'=>'فبراير','03'=>'مارس','04'=>'أبريل','05'=>'مايو','06'=>'يونيو',
               '07'=>'يوليو','08'=>'أغسطس','09'=>'سبتمبر','10'=>'أكتوبر','11'=>'نوفمبر','12'=>'ديسمبر'];
    $parts = explode('-', $ym);
    return ($months[$parts[1] ?? ''] ?? $ym) . ' ' . ($parts[0] ?? '');
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>محاسبة الشركات - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; justify-content:space-between; box-shadow:0 2px 8px rgba(0,0,0,.08); flex-wrap:wrap; gap:10px; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
.filter-bar { background:#fff; border-radius:12px; padding:1rem 1.5rem; box-shadow:0 2px 8px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.section-card { background:#fff; border-radius:14px; box-shadow:0 2px 12px rgba(0,0,0,.07); overflow:hidden; margin-bottom:1.5rem; }
.section-head { padding:1rem 1.5rem; border-bottom:1px solid #f0f0f0; display:flex; justify-content:space-between; align-items:center; }
.card-stat { background:#fff; border-radius:14px; padding:1.2rem; box-shadow:0 2px 10px rgba(0,0,0,.06); border-right:4px solid var(--green-mid); }
.card-stat .stat-num { font-size:1.6rem; font-weight:800; color:var(--green-dark); }
.table { min-width:700px; }
.table th { background:var(--green-dark); color:#fff; font-weight:600; padding:.85rem 1rem; border:none; font-size:.85rem; }
.table td { padding:.7rem 1rem; vertical-align:middle; border-color:#f0f0f0; font-size:.86rem; }
.table tbody tr:hover { background:#f8fdf9; }
.company-group-row td { background:#f4f6f9!important; font-weight:700; color:var(--green-dark); }
.readonly-badge { background:#eef5ff; color:#3498db; border-radius:20px; font-size:.72rem; padding:3px 10px; font-weight:600; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li><?php endif; ?>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link active" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li><?php endif; ?>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>
<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-file-invoice-dollar me-2"></i>محاسبة الشركات</h5>
        <div class="d-flex align-items-center gap-3 ms-auto">
            <div class="d-flex align-items-center gap-2">
            <div class="admin-avatar" style="width:36px;height:36px;border-radius:50%;background:var(--green-mid);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">
                <?= mb_substr($_SESSION['admin_name']??'م',0,1) ?>
            </div>
            <span class="fw-bold"><?= htmlspecialchars($_SESSION['admin_name']??'مدير') ?></span>
        </div>
            <div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="d-none d-md-inline">خروج</span>
            </a>
        </div>
        </div>
    </div>

    <div class="p-4">

        <?php if ($isRep): ?>
        <div class="alert alert-info d-flex align-items-center gap-2 mb-3">
            <i class="fa fa-info-circle"></i>
            <div>هذا تقرير محاسبي للعرض فقط يخص شركتك، ولا يمكن التعديل عليه من هذه الصفحة.</div>
        </div>
        <?php endif; ?>

        <!-- فلاتر -->
        <div class="filter-bar">
            <form method="GET" class="row g-2 align-items-end">
                <?php if (!$isRep): ?>
                <div class="col-md-4">
                    <label class="form-label fw-bold text-muted small mb-1">الشركة</label>
                    <select name="company_id" class="form-select">
                        <option value="0">كل الشركات</option>
                        <?php foreach ($companies as $co): ?>
                        <option value="<?= $co['id'] ?>" <?= $companyFilter == $co['id'] ? 'selected' : '' ?>>
                            <?= htmlspecialchars($co['name']) ?>
                        </option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <?php endif; ?>
                <div class="col-md-3">
                    <label class="form-label fw-bold text-muted small mb-1">السنة</label>
                    <select name="year" class="form-select">
                        <?php foreach ($availableYears as $y): ?>
                        <option value="<?= $y ?>" <?= $yearFilter == $y ? 'selected' : '' ?>><?= $y ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn w-100 fw-bold" style="background:var(--green-mid);color:#fff;border-radius:8px;">
                        <i class="fa fa-filter me-1"></i>تصفية
                    </button>
                </div>
                <div class="col-md-3 text-md-start">
                    <a href="company-accounting.php?<?= http_build_query(array_merge($_GET, ['export'=>'pdf'])) ?>"
                       class="btn w-100 fw-bold btn-outline-success rounded-3">
                        <i class="fa fa-file-pdf me-1"></i>تصدير PDF
                    </a>
                </div>
            </form>
        </div>

        <!-- إحصائيات إجمالية -->
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="card-stat">
                    <div class="text-muted small"><i class="fa fa-ticket-alt me-1"></i>إجمالي الحجوزات المؤكدة</div>
                    <div class="stat-num"><?= number_format($grandCnt) ?></div>
                    <small class="text-muted">لسنة <?= $yearFilter ?></small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card-stat" style="border-color:var(--gold)">
                    <div class="text-muted small"><i class="fa fa-coins me-1"></i>إجمالي المبلغ</div>
                    <div class="stat-num" style="color:var(--gold)"><?= number_format($grandTotal) ?></div>
                    <small class="text-muted">أوقية</small>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card-stat" style="border-color:#3498db">
                    <div class="text-muted small"><i class="fa fa-building me-1"></i>عدد الشركات</div>
                    <div class="stat-num" style="color:#3498db"><?= count($companyTotals) ?></div>
                </div>
            </div>
        </div>

        <!-- ملخص لكل شركة -->
        <?php if (!$isRep && count($companyTotals) > 1): ?>
        <div class="section-card">
            <div class="section-head">
                <h6 class="fw-bold mb-0"><i class="fa fa-building me-2 text-success"></i>الإجمالي السنوي لكل شركة</h6>
                <span class="readonly-badge"><i class="fa fa-eye me-1"></i>عرض فقط</span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead><tr><th>الشركة</th><th>عدد الحجوزات المؤكدة</th><th>إجمالي المبلغ</th></tr></thead>
                    <tbody>
                        <?php foreach ($companyTotals as $ct): ?>
                        <tr>
                            <td class="fw-bold"><?= htmlspecialchars($ct['name']) ?></td>
                            <td><?= number_format($ct['cnt']) ?></td>
                            <td class="fw-bold" style="color:var(--gold)"><?= number_format($ct['total']) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
        <?php endif; ?>

        <!-- التفصيل الشهري -->
        <div class="section-card">
            <div class="section-head">
                <div>
                    <h6 class="fw-bold mb-0"><i class="fa fa-calendar-alt me-2 text-success"></i>التفصيل الشهري (حسب تاريخ إنشاء الحجز)</h6>
                    <?php if ($companyFilter && $filteredCompanyName): ?>
                    <small class="text-muted"><i class="fa fa-building me-1"></i>شركة: <strong style="color:var(--green-dark)"><?= htmlspecialchars($filteredCompanyName) ?></strong></small>
                    <?php endif; ?>
                </div>
                <span class="readonly-badge"><i class="fa fa-eye me-1"></i>عرض فقط</span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <?php if ($showCompanyColumn): ?><th>الشركة</th><?php endif; ?>
                            <th>الشهر</th>
                            <th>عدد الحجوزات المؤكدة</th>
                            <th>إجمالي المبلغ</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($rows)): ?>
                    <tr><td colspan="<?= $showCompanyColumn ? 4 : 3 ?>" class="text-center py-5 text-muted">
                        <i class="fa fa-inbox fa-3x mb-3 d-block"></i>لا توجد حجوزات مؤكدة في هذه الفترة
                    </td></tr>
                    <?php else: ?>
                        <?php foreach ($rows as $r): ?>
                        <tr>
                            <?php if ($showCompanyColumn): ?>
                            <td class="fw-bold"><?= htmlspecialchars($r['company_name']) ?></td>
                            <?php endif; ?>
                            <td><?= arMonthLabel($r['ym']) ?></td>
                            <td><?= number_format($r['cnt']) ?></td>
                            <td class="fw-bold" style="color:var(--gold)"><?= number_format($r['total']) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- جرد تفصيلي لكل حجز -->
        <div class="section-card">
            <div class="section-head">
                <div>
                    <h6 class="fw-bold mb-0"><i class="fa fa-list-ul me-2 text-success"></i>جرد الحجوزات المؤكدة (تفصيل كامل)</h6>
                    <?php if ($companyFilter && $filteredCompanyName): ?>
                    <small class="text-muted"><i class="fa fa-building me-1"></i>شركة: <strong style="color:var(--green-dark)"><?= htmlspecialchars($filteredCompanyName) ?></strong> — سنة <?= $yearFilter ?></small>
                    <?php endif; ?>
                </div>
                <div class="d-flex align-items-center gap-2">
                    <span class="badge bg-success rounded-pill"><?= count($detailRows) ?> حجز</span>
                    <span class="readonly-badge"><i class="fa fa-eye me-1"></i>عرض فقط</span>
                </div>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <?php if ($showCompanyColumn): ?><th>الشركة</th><?php endif; ?>
                            <th>رقم الحجز</th>
                            <th>المسافر</th>
                            <th>الهاتف</th>
                            <th>الرحلة</th>
                            <th>تاريخ السفر</th>
                            <th>المقاعد</th>
                            <th>الدفع</th>
                            <th>تاريخ إنشاء الحجز</th>
                            <th>المبلغ</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($detailRows)): ?>
                    <tr><td colspan="<?= $showCompanyColumn ? 9 : 8 ?>" class="text-center py-5 text-muted">
                        <i class="fa fa-inbox fa-3x mb-3 d-block"></i>لا توجد حجوزات مؤكدة في هذه الفترة
                    </td></tr>
                    <?php else: ?>
                        <?php foreach ($detailRows as $d): ?>
                        <tr>
                            <?php if ($showCompanyColumn): ?>
                            <td class="fw-bold"><?= htmlspecialchars($d['company_name']) ?></td>
                            <?php endif; ?>
                            <td><code style="font-size:.78rem;background:#f8f9fa;padding:2px 6px;border-radius:4px;"><?= htmlspecialchars($d['booking_ref']) ?></code></td>
                            <td><?= htmlspecialchars($d['passenger_name']) ?></td>
                            <td><small class="text-muted"><?= htmlspecialchars($d['passenger_phone']) ?></small></td>
                            <td style="font-size:.85rem;"><?= htmlspecialchars($d['from_city']) ?> ← <?= htmlspecialchars($d['to_city']) ?></td>
                            <td><?= $d['travel_date'] ? date('d/m/Y', strtotime($d['travel_date'])) : '—' ?></td>
                            <td class="text-center"><?= $d['seat_count'] ?></td>
                            <td><span class="badge bg-light text-dark border"><?= $payLabelsAr[$d['payment_method']] ?? $d['payment_method'] ?></span></td>
                            <td><small class="text-muted"><?= $d['created_at'] ? date('d/m/Y H:i', strtotime($d['created_at'])) : '—' ?></small></td>
                            <td class="fw-bold" style="color:var(--gold)"><?= number_format($d['total_price']) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        </tr>
                        <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                    <?php if (!empty($detailRows)): ?>
                    <tfoot>
                        <tr style="background:#f4f6f9;">
                            <td colspan="<?= $showCompanyColumn ? 8 : 7 ?>" class="text-start fw-bold" style="color:var(--green-dark);">
                                <i class="fa fa-calculator me-1"></i>الإجمالي (<?= count($detailRows) ?> حجز)
                            </td>
                            <td class="fw-bold" style="color:var(--gold);font-size:1rem;"><?= number_format($detailGrandTotal) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        </tr>
                    </tfoot>
                    <?php endif; ?>
                </table>
            </div>
        </div>

    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
