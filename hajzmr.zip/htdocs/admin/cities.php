<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();

$message = '';
$error   = '';
$isRep   = isCompanyRep();

// ── تأكد أن جدول cities يحتوي على عمود active ─────────────────────────────
try {
    $db = getDB();
    // SQLite
    $db->exec("ALTER TABLE cities ADD COLUMN active INTEGER DEFAULT 1");
} catch (Exception $e) { /* العمود موجود بالفعل */ }
try {
    $db->exec("UPDATE cities SET active=1 WHERE active IS NULL");
} catch (Exception $e) {}

// ── إضافة مدينة ───────────────────────────────────────────────────────────
if (!$isRep && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_city') {
    $nameAr = trim($_POST['name_ar'] ?? '');
    $nameFr = trim($_POST['name_fr'] ?? '');
    $region = trim($_POST['region']  ?? '');

    if (!$nameAr) {
        $error = 'يرجى إدخال اسم المدينة بالعربية.';
    } else {
        try {
            $db   = getDB();
            $stmt = $db->prepare("INSERT INTO cities (name_ar, name_fr, region, active) VALUES (?,?,?,1)");
            $stmt->execute([$nameAr, $nameFr ?: null, $region ?: null]);
            $message = "تمت إضافة مدينة «{$nameAr}» بنجاح!";
        } catch (Exception $e) {
            if (stripos($e->getMessage(), 'UNIQUE') !== false || stripos($e->getMessage(), 'duplicate') !== false)
                $error = 'هذه المدينة موجودة بالفعل.';
            else
                $error = 'حدث خطأ: ' . $e->getMessage();
        }
    }
}

// ── تعديل مدينة ───────────────────────────────────────────────────────────
if (!$isRep && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit_city') {
    $cid    = (int)($_POST['city_id'] ?? 0);
    $nameAr = trim($_POST['name_ar'] ?? '');
    $nameFr = trim($_POST['name_fr'] ?? '');
    $region = trim($_POST['region']  ?? '');

    if (!$cid || !$nameAr) {
        $error = 'يرجى إدخال اسم المدينة.';
    } else {
        try {
            $db = getDB();
            $db->prepare("UPDATE cities SET name_ar=?, name_fr=?, region=? WHERE id=?")
               ->execute([$nameAr, $nameFr ?: null, $region ?: null, $cid]);
            $message = "تم تحديث «{$nameAr}» بنجاح!";
        } catch (Exception $e) {
            $error = 'حدث خطأ أثناء التحديث.';
        }
    }
}

// ── تفعيل / تعطيل ────────────────────────────────────────────────────────
if (!$isRep && isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    try {
        $db   = getDB();
        $row  = $db->prepare("SELECT active FROM cities WHERE id=?");
        $row->execute([(int)$_GET['toggle']]);
        $cur  = $row->fetchColumn();
        $db->prepare("UPDATE cities SET active=? WHERE id=?")->execute([$cur ? 0 : 1, (int)$_GET['toggle']]);
        $message = $cur ? 'تم إيقاف المدينة (لن تظهر في خيارات الرحلات).' : 'تم تفعيل المدينة.';
    } catch (Exception $e) { $error = 'حدث خطأ.'; }
}

// ── حذف مدينة ─────────────────────────────────────────────────────────────
if (!$isRep && isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $db = getDB();
        // تحقق أن المدينة لا تُستخدم في رحلات
        $used = $db->prepare("SELECT COUNT(*) FROM routes WHERE (from_city=(SELECT name_ar FROM cities WHERE id=?) OR to_city=(SELECT name_ar FROM cities WHERE id=?)) AND active=1");
        $used->execute([(int)$_GET['delete'], (int)$_GET['delete']]);
        if ($used->fetchColumn() > 0) {
            $error = 'لا يمكن حذف هذه المدينة لأنها مرتبطة برحلات نشطة. أوقفها بدلاً من الحذف.';
        } else {
            $db->prepare("DELETE FROM cities WHERE id=?")->execute([(int)$_GET['delete']]);
            $message = 'تم حذف المدينة.';
        }
    } catch (Exception $e) { $error = 'حدث خطأ أثناء الحذف.'; }
}

// ── جلب المدن ────────────────────────────────────────────────────────────
$cities = [];
try {
    $db     = getDB();
    $cities = $db->query("SELECT c.*, (SELECT COUNT(*) FROM routes r WHERE (r.from_city=c.name_ar OR r.to_city=c.name_ar) AND r.active=1) as route_count FROM cities c ORDER BY c.active DESC, c.name_ar")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $cities = [
        ['id'=>24,'name_ar'=>'نواكشوط','name_fr'=>'Nouakchott','region'=>'','active'=>1,'route_count'=>3],
        ['id'=>25,'name_ar'=>'نواذيبو','name_fr'=>'Nouadhibou','region'=>'','active'=>1,'route_count'=>2],
        ['id'=>26,'name_ar'=>'روصو',   'name_fr'=>'Rosso',     'region'=>'','active'=>1,'route_count'=>1],
    ];
}

// ── تحميل مدينة للتعديل ─────────────────────────────────────────────────
$editCity = null;
if (!$isRep && isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    foreach ($cities as $c) {
        if ((int)$c['id'] === (int)$_GET['edit']) { $editCity = $c; break; }
    }
}

$showAddForm = !$isRep && isset($_GET['action']) && $_GET['action'] === 'add';
$activeCount = count(array_filter($cities, fn($c) => $c['active']));
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة المدن - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; box-shadow:-4px 0 20px rgba(0,0,0,.2); }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.btn-add-main { background:var(--green-mid); color:#fff; border:none; border-radius:10px; padding:.65rem 1.6rem; font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
.btn-add-main:hover { background:var(--green-dark); color:#fff; }
.card-form { background:#fff; border-radius:14px; padding:2rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.card-form.edit-mode { border-top:4px solid var(--gold); }
.card-form.add-mode  { border-top:4px solid var(--green-light); }
.data-table { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.07); }
.data-table .table-responsive { overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%; max-width:100%; }
.table { min-width:700px; }
.table th { background:var(--green-dark); color:#fff; font-weight:600; padding:.9rem 1rem; border:none; font-size:.88rem; }
.table td { padding:.75rem 1rem; vertical-align:middle; border-color:#f0f0f0; }
.table tbody tr:hover { background:#f8fdf9; }
.action-btn { padding:4px 11px; border-radius:7px; font-size:.8rem; border:none; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:4px; transition:opacity .15s; }
.action-btn:hover { opacity:.8; }
.btn-edit   { background:#eef5ff; color:#3498db; }
.btn-on     { background:#e8f5f0; color:var(--green-mid); }
.btn-off    { background:#fff3cd; color:#856404; }
.btn-del    { background:#fef0f0; color:#e74c3c; }
.stat-mini { background:#fff; border-radius:12px; padding:1.1rem 1.4rem; box-shadow:0 2px 10px rgba(0,0,0,.07); border-right:4px solid; display:flex; align-items:center; gap:1rem; }
.city-badge { display:inline-block; background:#f0fdf4; color:var(--green-mid); border-radius:6px; padding:2px 10px; font-size:.85rem; font-weight:600; }
.city-badge.inactive { background:#f8f9fa; color:#aaa; }
.route-count { background:#e8f0ff; color:#3366cc; border-radius:20px; padding:2px 9px; font-size:.78rem; font-weight:700; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>

<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link active" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li><?php endif; ?>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>

<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-map-marker-alt me-2"></i>إدارة المدن<?php if ($isRep): ?> <small class="text-muted fw-normal" style="font-size:.75rem;">— عرض فقط</small><?php endif; ?></h5>
        <?php if (!$isRep): ?>
        <a href="cities.php?action=add" class="btn-add-main">
            <i class="fa fa-plus"></i> إضافة مدينة
        </a>
        <?php endif; ?>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">

        <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fa fa-check-circle me-2"></i><?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fa fa-exclamation-circle me-2"></i><?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- إحصاء -->
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:var(--green-light);">
                    <i class="fa fa-city fa-2x opacity-25 text-success"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:var(--green-mid);"><?= count($cities) ?></div>
                        <div class="text-muted small">إجمالي المدن</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:#3498db;">
                    <i class="fa fa-check-circle fa-2x opacity-25 text-primary"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:#3498db;"><?= $activeCount ?></div>
                        <div class="text-muted small">مدن نشطة</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:var(--gold);">
                    <i class="fa fa-route fa-2x opacity-25" style="color:var(--gold);"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:var(--gold);"><?= array_sum(array_column($cities,'route_count')) ?></div>
                        <div class="text-muted small">رحلات مرتبطة</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- نموذج الإضافة -->
        <?php if ($showAddForm && !$editCity): ?>
        <div class="card-form add-mode" id="add-form-section">
            <h5 class="fw-bold mb-4" style="color:var(--green-dark);">
                <i class="fa fa-plus-circle me-2 text-success"></i>إضافة مدينة جديدة
            </h5>
            <form method="POST">
                <input type="hidden" name="action" value="add_city">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">اسم المدينة بالعربية *</label>
                        <input type="text" name="name_ar" class="form-control" placeholder="مثال: تنبدغة" required>
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">الاسم بالفرنسية <span class="text-muted fw-normal">(اختياري)</span></label>
                        <input type="text" name="name_fr" class="form-control" placeholder="مثال: Timbedgha">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">الولاية <span class="text-muted fw-normal">(اختياري)</span></label>
                        <input type="text" name="region" class="form-control" placeholder="مثال: الحوض الشرقي">
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-add-main btn">
                            <i class="fa fa-save me-1"></i>حفظ المدينة
                        </button>
                        <a href="cities.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- نموذج التعديل -->
        <?php if ($editCity): ?>
        <div class="card-form edit-mode" id="edit-form-section">
            <h5 class="fw-bold mb-4" style="color:var(--green-dark);">
                <i class="fa fa-edit me-2" style="color:var(--gold);"></i>تعديل: <?= htmlspecialchars($editCity['name_ar']) ?>
            </h5>
            <form method="POST">
                <input type="hidden" name="action"  value="edit_city">
                <input type="hidden" name="city_id" value="<?= (int)$editCity['id'] ?>">
                <div class="row g-3">
                    <div class="col-md-4">
                        <label class="form-label fw-bold">اسم المدينة بالعربية *</label>
                        <input type="text" name="name_ar" class="form-control" required
                               value="<?= htmlspecialchars($editCity['name_ar']) ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">الاسم بالفرنسية</label>
                        <input type="text" name="name_fr" class="form-control"
                               value="<?= htmlspecialchars($editCity['name_fr'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">الولاية</label>
                        <input type="text" name="region" class="form-control"
                               value="<?= htmlspecialchars($editCity['region'] ?? '') ?>">
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-add-main btn" style="background:var(--gold);">
                            <i class="fa fa-save me-1"></i>حفظ التعديلات
                        </button>
                        <a href="cities.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- جدول المدن -->
        <div class="data-table">
            <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                <h6 class="fw-bold mb-0">
                    <i class="fa fa-list me-2 text-success"></i>قائمة المدن (<?= count($cities) ?>)
                </h6>
                <small class="text-muted">المدن النشطة تظهر في خيارات إضافة الرحلات</small>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المدينة</th>
                            <th>الاسم الفرنسي</th>
                            <th>الولاية</th>
                            <th>الرحلات المرتبطة</th>
                            <th>الحالة</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($cities)): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted">
                        <i class="fa fa-map-marker-alt fa-3x mb-3 d-block opacity-25"></i>لا توجد مدن بعد
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($cities as $c): ?>
                    <tr class="<?= $editCity && (int)$editCity['id']===(int)$c['id'] ? 'table-warning' : '' ?>">
                        <td class="text-muted small"><?= $c['id'] ?></td>
                        <td>
                            <span class="city-badge <?= $c['active'] ? '' : 'inactive' ?>">
                                <i class="fa fa-map-marker-alt me-1" style="font-size:.75rem;"></i>
                                <?= htmlspecialchars($c['name_ar']) ?>
                            </span>
                        </td>
                        <td class="text-muted"><?= htmlspecialchars($c['name_fr'] ?? '—') ?></td>
                        <td class="text-muted small"><?= htmlspecialchars($c['region'] ?? '—') ?></td>
                        <td>
                            <?php if ($c['route_count'] > 0): ?>
                            <span class="route-count"><i class="fa fa-route me-1"></i><?= $c['route_count'] ?></span>
                            <?php else: ?>
                            <span class="text-muted small">—</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if ($c['active']): ?>
                            <span class="text-success small fw-bold"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#27ae60;margin-left:5px;"></span>نشطة</span>
                            <?php else: ?>
                            <span class="text-danger small fw-bold"><span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#e74c3c;margin-left:5px;"></span>موقوفة</span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <?php if (!$isRep): ?>
                            <div class="d-flex gap-1">
                                <a href="cities.php?edit=<?= $c['id'] ?>" class="action-btn btn-edit">
                                    <i class="fa fa-edit"></i> تعديل
                                </a>
                                <a href="cities.php?toggle=<?= $c['id'] ?>"
                                   class="action-btn <?= $c['active'] ? 'btn-off' : 'btn-on' ?>"
                                   onclick="return confirm('<?= $c['active'] ? 'إيقاف' : 'تفعيل' ?> مدينة <?= htmlspecialchars($c['name_ar']) ?>؟')">
                                    <i class="fa <?= $c['active'] ? 'fa-eye-slash' : 'fa-eye' ?>"></i>
                                    <?= $c['active'] ? 'إيقاف' : 'تفعيل' ?>
                                </a>
                                <?php if ($c['route_count'] == 0): ?>
                                <a href="cities.php?delete=<?= $c['id'] ?>" class="action-btn btn-del"
                                   onclick="return confirm('حذف مدينة «<?= htmlspecialchars($c['name_ar']) ?>» نهائياً؟')">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                            <?php else: ?>
                            <span class="text-muted small"><i class="fa fa-eye me-1"></i>عرض فقط</span>
                            <?php endif; ?>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- ملاحظة -->
        <div class="mt-3 p-3 rounded-3" style="background:#fffbeb;border-right:4px solid var(--gold);">
            <small class="text-muted">
                <i class="fa fa-info-circle me-1" style="color:var(--gold);"></i>
                <strong>ملاحظة:</strong> المدن النشطة فقط تظهر في قوائم الاختيار عند إضافة أو تعديل الرحلات.
                المدن المرتبطة برحلات نشطة لا يمكن حذفها، استخدم "إيقاف" بدلاً من الحذف.
            </small>
        </div>

    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
<?php if ($editCity): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('edit-form-section').scrollIntoView({behavior:'smooth', block:'start'});
});
<?php elseif ($showAddForm): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('add-form-section').scrollIntoView({behavior:'smooth', block:'start'});
});
<?php endif; ?>
</script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
