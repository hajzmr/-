<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();

$isRep        = isCompanyRep();
$repCompanyId = getSessionCompanyId();

// --- تصدير CSV ---
if (isset($_GET['export']) && $_GET['export'] === 'csv') {
    $type      = sanitize($_GET['type'] ?? 'bookings');
    $dateFrom  = sanitize($_GET['date_from'] ?? '');
    $dateTo    = sanitize($_GET['date_to'] ?? '');

    header('Content-Type: text/csv; charset=UTF-8');
    header('Content-Disposition: attachment; filename="' . $type . '_' . date('Ymd') . '.csv"');
    echo "\xEF\xBB\xBF"; // BOM for Excel Arabic

    $out = fopen('php://output', 'w');

    try {
        $db = getDB();

        if ($type === 'bookings') {
            fputcsv($out, ['رقم الحجز','المسافر','الهاتف','من','إلى','تاريخ السفر','المقاعد','المبلغ','طريقة الدفع','الحالة','تاريخ الإنشاء']);
            $sql = "SELECT b.booking_ref, b.passenger_name, b.passenger_phone,
                           r.from_city, r.to_city, b.travel_date,
                           b.seat_count, b.total_price, b.payment_method,
                           b.status, b.created_at
                    FROM bookings b LEFT JOIN routes r ON b.route_id = r.id
                    WHERE 1=1";
            $params = [];
            if ($dateFrom) { $sql .= " AND b.travel_date >= ?"; $params[] = $dateFrom; }
            if ($dateTo)   { $sql .= " AND b.travel_date <= ?"; $params[] = $dateTo; }
            $sql .= " ORDER BY b.id DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            $statusLabels = ['pending'=>'في الانتظار','confirmed'=>'مؤكد','cancelled'=>'ملغي','completed'=>'مكتمل'];
            $payLabels    = ['cash'=>'نقداً','mobile'=>'هاتف','card'=>'بطاقة'];
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $row['status']         = $statusLabels[$row['status']] ?? $row['status'];
                $row['payment_method'] = $payLabels[$row['payment_method']] ?? $row['payment_method'];
                fputcsv($out, $row);
            }
        } elseif ($type === 'routes') {
            fputcsv($out, ['#','من','إلى','وقت الانطلاق','وقت الوصول','السعر','المقاعد','الشركة','نوع الباص']);
            $rows = $db->query("SELECT id,from_city,to_city,departure_time,arrival_time,price,seats_total,company,bus_type FROM routes WHERE active=1 ORDER BY from_city")->fetchAll(PDO::FETCH_ASSOC);
            foreach ($rows as $row) fputcsv($out, $row);
        } elseif ($type === 'revenue') {
            fputcsv($out, ['الشهر','عدد الحجوزات','الإيراد (أوقية)']);
            $sql = "SELECT Left(travel_date,7) as month, COUNT(*) as cnt, SUM(total_price) as rev
                    FROM bookings WHERE status <> 'cancelled'";
            $params = [];
            if ($dateFrom) { $sql .= " AND travel_date >= ?"; $params[] = $dateFrom; }
            if ($dateTo)   { $sql .= " AND travel_date <= ?"; $params[] = $dateTo; }
            $sql .= " GROUP BY Left(travel_date,7) ORDER BY Left(travel_date,7) DESC";
            $stmt = $db->prepare($sql);
            $stmt->execute($params);
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) fputcsv($out, $row);
        }
    } catch (Exception $e) {
        // demo fallback
        if ($type === 'bookings') {
            fputcsv($out, ['رقم الحجز','المسافر','الهاتف','من','إلى','تاريخ السفر','المقاعد','المبلغ','طريقة الدفع','الحالة','تاريخ الإنشاء']);
            fputcsv($out, ['MRT-A8F2C1D3','أحمد ولد محمد','22001234','نواكشوط','نواذيبو',date('Y-m-d'),2,10000,'نقداً','مؤكد',date('Y-m-d H:i:s')]);
            fputcsv($out, ['MRT-B9E3F2A1','فاطمة بنت أحمد','22005678','نواكشوط','روصو',date('Y-m-d',strtotime('+1 day')),1,2500,'هاتف','في الانتظار',date('Y-m-d H:i:s')]);
        }
    }
    fclose($out);
    exit;
}

// --- إحصائيات ---
$stats = ['total'=>0,'confirmed'=>0,'pending'=>0,'cancelled'=>0,'revenue'=>0,'routes'=>0,'avg'=>0];
$monthlyData  = [];
$topRoutes    = [];
$recentBookings = [];

$dateFrom = sanitize($_GET['date_from'] ?? date('Y-m-01'));
$dateTo   = sanitize($_GET['date_to']   ?? date('Y-m-t'));

try {
    $db = getDB();

    // شرط تصفية الشركة لممثل الشركة
    $companyJoin  = $isRep && $repCompanyId ? " LEFT JOIN routes r2 ON b.route_id=r2.id" : "";
    $companyWhere = $isRep && $repCompanyId ? " AND r2.company_id={$repCompanyId}" : "";

    $r = $db->query("SELECT COUNT(*) as c FROM bookings b{$companyJoin} WHERE 1=1{$companyWhere}")->fetch(); $stats['total'] = $r['c'];
    $r = $db->query("SELECT COUNT(*) as c FROM bookings b{$companyJoin} WHERE b.status='confirmed'{$companyWhere}")->fetch(); $stats['confirmed'] = $r['c'];
    $r = $db->query("SELECT COUNT(*) as c FROM bookings b{$companyJoin} WHERE b.status='pending'{$companyWhere}")->fetch(); $stats['pending'] = $r['c'];
    $r = $db->query("SELECT COUNT(*) as c FROM bookings b{$companyJoin} WHERE b.status='cancelled'{$companyWhere}")->fetch(); $stats['cancelled'] = $r['c'];
    $r = $db->query("SELECT SUM(b.total_price) as s FROM bookings b{$companyJoin} WHERE b.status<>'cancelled'{$companyWhere}")->fetch(); $stats['revenue'] = $r['s'] ?? 0;
    $r = $db->query("SELECT COUNT(*) as c FROM routes WHERE active=1" . ($isRep && $repCompanyId ? " AND company_id={$repCompanyId}" : ""))->fetch(); $stats['routes'] = $r['c'];
    $stats['avg'] = $stats['confirmed'] > 0 ? round($stats['revenue'] / $stats['confirmed']) : 0;

    // شهرياً
    $stmt = $db->prepare("SELECT TOP 6 Left(travel_date,7) as month, COUNT(*) as cnt, SUM(total_price) as rev
                           FROM bookings WHERE status<>'cancelled' AND travel_date BETWEEN ? AND ?
                           GROUP BY Left(travel_date,7) ORDER BY Left(travel_date,7) DESC");
    $stmt->execute([$dateFrom, $dateTo]);
    $monthlyData = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // أفضل مسارات
    $stmt = $db->prepare("SELECT TOP 5 r.from_city, r.to_city, COUNT(b.id) as trips, SUM(b.total_price) as rev
                           FROM bookings b JOIN routes r ON b.route_id=r.id
                           WHERE b.status<>'cancelled' AND b.travel_date BETWEEN ? AND ?
                           GROUP BY r.id, r.from_city, r.to_city ORDER BY COUNT(b.id) DESC");
    $stmt->execute([$dateFrom, $dateTo]);
    $topRoutes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // آخر حجوزات
    $stmt = $db->prepare("SELECT TOP 10 b.*, r.from_city, r.to_city FROM bookings b
                           LEFT JOIN routes r ON b.route_id=r.id
                           WHERE b.travel_date BETWEEN ? AND ?
                           ORDER BY b.id DESC");
    $stmt->execute([$dateFrom, $dateTo]);
    $recentBookings = $stmt->fetchAll(PDO::FETCH_ASSOC);

} catch (Exception $e) {
    // Demo
    $stats = ['total'=>247,'confirmed'=>189,'pending'=>41,'cancelled'=>17,'revenue'=>892500,'routes'=>18,'avg'=>4723];
    $monthlyData = [
        ['month'=>date('Y-m'),'cnt'=>38,'rev'=>179400],
        ['month'=>date('Y-m',strtotime('-1 month')),'cnt'=>52,'rev'=>245700],
        ['month'=>date('Y-m',strtotime('-2 month')),'cnt'=>45,'rev'=>212500],
        ['month'=>date('Y-m',strtotime('-3 month')),'cnt'=>41,'rev'=>193200],
        ['month'=>date('Y-m',strtotime('-4 month')),'cnt'=>35,'rev'=>165300],
        ['month'=>date('Y-m',strtotime('-5 month')),'cnt'=>29,'rev'=>137900],
    ];
    $topRoutes = [
        ['from_city'=>'نواكشوط','to_city'=>'نواذيبو','trips'=>68,'rev'=>340000],
        ['from_city'=>'نواكشوط','to_city'=>'روصو','trips'=>42,'rev'=>105000],
        ['from_city'=>'نواكشوط','to_city'=>'أطار','trips'=>31,'rev'=>139500],
        ['from_city'=>'نواذيبو','to_city'=>'زويرات','trips'=>28,'rev'=>84000],
        ['from_city'=>'نواكشوط','to_city'=>'كيفة','trips'=>21,'rev'=>73500],
    ];
    $recentBookings = [
        ['id'=>247,'booking_ref'=>'MRT-A8F2C1D3','from_city'=>'نواكشوط','to_city'=>'نواذيبو','passenger_name'=>'أحمد ولد محمد','seat_count'=>2,'total_price'=>10000,'status'=>'confirmed','travel_date'=>date('Y-m-d',strtotime('+1 day'))],
        ['id'=>246,'booking_ref'=>'MRT-B9E3F2A1','from_city'=>'نواكشوط','to_city'=>'روصو','passenger_name'=>'فاطمة بنت أحمد','seat_count'=>1,'total_price'=>2500,'status'=>'pending','travel_date'=>date('Y-m-d',strtotime('+2 day'))],
        ['id'=>245,'booking_ref'=>'MRT-C7D4E5B2','from_city'=>'نواذيبو','to_city'=>'زويرات','passenger_name'=>'محمد سالم','seat_count'=>3,'total_price'=>9000,'status'=>'confirmed','travel_date'=>date('Y-m-d')],
        ['id'=>244,'booking_ref'=>'MRT-D1A5B8C9','from_city'=>'كيفة','to_city'=>'نواكشوط','passenger_name'=>'مريم بنت سيدي','seat_count'=>1,'total_price'=>3500,'status'=>'cancelled','travel_date'=>date('Y-m-d',strtotime('-1 day'))],
        ['id'=>243,'booking_ref'=>'MRT-E2F6G7H8','from_city'=>'نواكشوط','to_city'=>'أطار','passenger_name'=>'عبد الله ولد بكر','seat_count'=>2,'total_price'=>9000,'status'=>'confirmed','travel_date'=>date('Y-m-d',strtotime('+3 day'))],
    ];
}

$maxRev = count($monthlyData) ? max(array_column($monthlyData, 'rev')) : 1;
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>التقارير - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; overflow-x:hidden; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; justify-content:space-between; box-shadow:0 2px 8px rgba(0,0,0,.08); flex-wrap:wrap; row-gap:.75rem; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.card-stat { background:#fff; border-radius:14px; padding:1.4rem; box-shadow:0 2px 12px rgba(0,0,0,.07); border-top:4px solid; }
.card-stat.green  { border-color:var(--green-light); }
.card-stat.blue   { border-color:#3498db; }
.card-stat.gold   { border-color:var(--gold); }
.card-stat.orange { border-color:#f39c12; }
.card-stat.red    { border-color:#e74c3c; }
.card-stat.purple { border-color:#9b59b6; }
.stat-num { font-size:1.8rem; font-weight:800; margin:.3rem 0; }
.section-card { background:#fff; border-radius:14px; box-shadow:0 2px 12px rgba(0,0,0,.07); overflow:hidden; }
.section-head { padding:1rem 1.5rem; border-bottom:1px solid #f0f0f0; display:flex; align-items:center; justify-content:space-between; }
.bar-wrap { display:flex; align-items:flex-end; gap:8px; height:140px; padding:0 1rem 0; }
.bar-col { flex:1; display:flex; flex-direction:column; align-items:center; gap:4px; }
.bar { background:linear-gradient(0deg,var(--green-mid),var(--green-light)); border-radius:6px 6px 0 0; width:100%; min-height:4px; transition:height .5s; }
.bar-label { font-size:.65rem; color:#888; text-align:center; }
.bar-val { font-size:.65rem; font-weight:700; color:var(--green-dark); }
.export-btn { background:var(--green-mid); color:#fff; border:none; border-radius:8px; padding:.5rem 1.2rem; font-size:.9rem; font-weight:600; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
.export-btn:hover { background:var(--green-dark); color:#fff; }
.export-btn.gold-btn { background:var(--gold); }
.export-btn.gold-btn:hover { background:#a88018; }
.table { min-width:700px; }
.table th { background:var(--green-dark); color:#fff; font-size:.85rem; padding:.8rem 1rem; border:none; }
.table td { font-size:.85rem; padding:.7rem 1rem; border-color:#f0f0f0; vertical-align:middle; }
.progress-bar-custom { height:8px; border-radius:4px; background:var(--green-light); }
.filter-bar { background:#fff; border-radius:12px; padding:1rem 1.5rem; box-shadow:0 2px 8px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
    .topbar .d-flex.gap-2 { width:100%; order:3; flex-wrap:wrap; }
    .export-btn { flex:1 1 auto; justify-content:center; padding:.5rem .8rem; font-size:.8rem; }
    .quick-actions { order:2; }
}
@media (max-width: 575px) {
    .export-btn span { display:none; }
    .export-btn { padding:.55rem .7rem; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li><?php endif; ?>
        <li><a class="nav-link active" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>
<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-chart-bar me-2"></i>التقارير والإحصائيات</h5>
        <div class="d-flex gap-2">
            <a href="reports.php?export=csv&type=bookings&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" class="export-btn">
                <i class="fa fa-download"></i> <span>تصدير الحجوزات CSV</span>
            </a>
            <a href="reports.php?export=csv&type=revenue&date_from=<?= $dateFrom ?>&date_to=<?= $dateTo ?>" class="export-btn gold-btn">
                <i class="fa fa-file-excel"></i> <span>تصدير الإيرادات</span>
            </a>
            <a href="reports.php?export=csv&type=routes" class="export-btn" style="background:#6c757d;">
                <i class="fa fa-route"></i> <span>تصدير الرحلات</span>
            </a>
        </div>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">

        <!-- فلتر التاريخ -->
        <div class="filter-bar mb-4">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-auto">
                    <label class="form-label fw-bold small text-muted mb-1">من تاريخ</label>
                    <input type="date" name="date_from" class="form-control" value="<?= $dateFrom ?>">
                </div>
                <div class="col-auto">
                    <label class="form-label fw-bold small text-muted mb-1">إلى تاريخ</label>
                    <input type="date" name="date_to" class="form-control" value="<?= $dateTo ?>">
                </div>
                <div class="col-auto">
                    <button class="btn fw-bold" style="background:var(--green-mid);color:#fff;border-radius:8px;">
                        <i class="fa fa-filter me-1"></i> تطبيق
                    </button>
                </div>
                <div class="col-auto">
                    <a href="reports.php" class="btn btn-outline-secondary rounded-3">إعادة تعيين</a>
                </div>
                <div class="col-auto ms-auto">
                    <small class="text-muted">الفترة: <?= date('d/m/Y', strtotime($dateFrom)) ?> — <?= date('d/m/Y', strtotime($dateTo)) ?></small>
                </div>
            </form>
        </div>

        <!-- بطاقات الإحصاء -->
        <div class="row g-3 mb-4">
            <div class="col-md-2">
                <div class="card-stat green">
                    <div class="text-muted small"><i class="fa fa-ticket-alt me-1"></i>إجمالي الحجوزات</div>
                    <div class="stat-num text-success"><?= number_format($stats['total']) ?></div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card-stat blue">
                    <div class="text-muted small"><i class="fa fa-check-circle me-1"></i>مؤكدة</div>
                    <div class="stat-num" style="color:#3498db"><?= number_format($stats['confirmed']) ?></div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card-stat orange">
                    <div class="text-muted small"><i class="fa fa-clock me-1"></i>في الانتظار</div>
                    <div class="stat-num text-warning"><?= number_format($stats['pending']) ?></div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card-stat red">
                    <div class="text-muted small"><i class="fa fa-times-circle me-1"></i>ملغاة</div>
                    <div class="stat-num text-danger"><?= number_format($stats['cancelled']) ?></div>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card-stat gold">
                    <div class="text-muted small"><i class="fa fa-coins me-1"></i>الإيرادات</div>
                    <div class="stat-num" style="color:var(--gold);font-size:1.3rem"><?= number_format($stats['revenue']) ?></div>
                    <small class="text-muted">أوقية</small>
                </div>
            </div>
            <div class="col-md-2">
                <div class="card-stat purple">
                    <div class="text-muted small"><i class="fa fa-route me-1"></i>الرحلات النشطة</div>
                    <div class="stat-num" style="color:#9b59b6"><?= number_format($stats['routes']) ?></div>
                </div>
            </div>
        </div>

        <div class="row g-4">
            <!-- رسم بياني شهري -->
            <div class="col-md-7">
                <div class="section-card">
                    <div class="section-head">
                        <h6 class="fw-bold mb-0"><i class="fa fa-chart-bar me-2 text-success"></i>الإيرادات الشهرية</h6>
                        <small class="text-muted">آخر 6 أشهر</small>
                    </div>
                    <div class="p-3">
                        <?php if (empty($monthlyData)): ?>
                        <div class="text-center text-muted py-5"><i class="fa fa-chart-bar fa-3x mb-2 d-block opacity-25"></i>لا توجد بيانات</div>
                        <?php else: ?>
                        <div class="bar-wrap">
                            <?php foreach (array_reverse($monthlyData) as $m):
                                $pct = $maxRev > 0 ? round(($m['rev'] / $maxRev) * 120) : 4;
                                $label = date('M Y', strtotime($m['month'] . '-01'));
                            ?>
                            <div class="bar-col">
                                <div class="bar-val"><?= number_format($m['rev']/1000, 0) ?>ك</div>
                                <div class="bar" style="height:<?= $pct ?>px;" title="<?= number_format($m['rev']) ?> أوقية"></div>
                                <div class="bar-label"><?= $label ?></div>
                                <div class="bar-label" style="color:var(--green-mid);"><?= $m['cnt'] ?> حجز</div>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </div>

            <!-- أفضل المسارات -->
            <div class="col-md-5">
                <div class="section-card">
                    <div class="section-head">
                        <h6 class="fw-bold mb-0"><i class="fa fa-trophy me-2 text-warning"></i>أكثر المسارات حجزاً</h6>
                    </div>
                    <div class="p-3">
                        <?php if (empty($topRoutes)): ?>
                        <div class="text-center text-muted py-4"><i class="fa fa-route fa-2x mb-2 d-block opacity-25"></i>لا توجد بيانات</div>
                        <?php else:
                            $maxTrips = max(array_column($topRoutes,'trips'));
                        ?>
                        <?php foreach ($topRoutes as $i => $tr):
                            $pct = $maxTrips > 0 ? round(($tr['trips']/$maxTrips)*100) : 0;
                            $colors = ['var(--gold)','var(--green-mid)','#3498db','#f39c12','#9b59b6'];
                        ?>
                        <div class="mb-3">
                            <div class="d-flex justify-content-between align-items-center mb-1">
                                <span class="fw-bold" style="font-size:.85rem;">
                                    <span class="badge rounded-pill me-1" style="background:<?= $colors[$i]??'#888' ?>"><?= $i+1 ?></span>
                                    <?= htmlspecialchars($tr['from_city']) ?> ← <?= htmlspecialchars($tr['to_city']) ?>
                                </span>
                                <small class="text-muted"><?= $tr['trips'] ?> حجز</small>
                            </div>
                            <div class="progress" style="height:6px;border-radius:4px;">
                                <div class="progress-bar" style="width:<?= $pct ?>%;background:<?= $colors[$i]??'var(--green-mid)' ?>;border-radius:4px;"></div>
                            </div>
                            <small class="text-muted"><?= number_format($tr['rev']) ?> أوقية</small>
                        </div>
                        <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </div>

        <!-- جدول الحجوزات الأخيرة في الفترة -->
        <div class="section-card mt-4">
            <div class="section-head">
                <h6 class="fw-bold mb-0"><i class="fa fa-list-alt me-2 text-success"></i>الحجوزات في الفترة المحددة</h6>
                <span class="badge bg-success rounded-pill"><?= count($recentBookings) ?></span>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>رقم الحجز</th>
                            <th>المسافر</th>
                            <th>الرحلة</th>
                            <th>تاريخ السفر</th>
                            <th>المقاعد</th>
                            <th>المبلغ</th>
                            <th>الحالة</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($recentBookings)): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted"><i class="fa fa-inbox fa-2x mb-2 d-block"></i>لا توجد حجوزات في هذه الفترة</td></tr>
                    <?php else: ?>
                    <?php foreach ($recentBookings as $b): ?>
                    <tr>
                        <td><code style="font-size:.78rem;background:#f8f9fa;padding:2px 6px;border-radius:4px;"><?= htmlspecialchars($b['booking_ref']) ?></code></td>
                        <td><?= htmlspecialchars($b['passenger_name']) ?></td>
                        <td><?= htmlspecialchars($b['from_city']??'—') ?> ← <?= htmlspecialchars($b['to_city']??'—') ?></td>
                        <td><?= $b['travel_date'] ? date('d/m/Y', strtotime($b['travel_date'])) : '—' ?></td>
                        <td class="text-center"><?= $b['seat_count'] ?></td>
                        <td class="fw-bold" style="color:var(--gold)"><?= number_format($b['total_price']) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        <td><?= getStatusBadge($b['status']) ?></td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
