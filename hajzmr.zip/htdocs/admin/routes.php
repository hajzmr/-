<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();

$cities  = getMauritanianCities();
$message = '';
$error   = '';

// تأكد من وجود جدول الشركات
$db = getDB();
ensureCompaniesTable($db);
$companiesList = getActiveCompanies();

// ممثل الشركة: يمكنه إضافة رحلة لشركته وحذفها إن لم يوجد عليها حجز — لا تعديل ولا التعامل مع شركات أخرى
$isRep        = isCompanyRep();
$repCompanyId = getSessionCompanyId();

// ─── 1. إضافة رحلة جديدة ────────────────────────────────────────────────────
// ممثل الشركة يمكنه إضافة رحلة، لكن مقصورة إجبارياً على شركته (لا يمكنه اختيار شركة أخرى)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_route') {
    $fromCity      = sanitize($_POST['from_city']      ?? '');
    $toCity        = sanitize($_POST['to_city']        ?? '');
    $departureTime = sanitize($_POST['departure_time'] ?? '');
    $arrivalTime   = sanitize($_POST['arrival_time']   ?? '');
    $price         = (float)($_POST['price']           ?? 0);
    $seatsTotal    = (int)($_POST['seats_total']       ?? 40);
    $companyId     = $isRep ? $repCompanyId : ((int)($_POST['company_id'] ?? 0) ?: null);
    $busType       = sanitize($_POST['bus_type']       ?? '');

    // جلب اسم الشركة من قاعدة البيانات
    $companyName = '';
    if ($companyId) {
        try {
            $cRow = $db->prepare("SELECT name FROM companies WHERE id=?");
            $cRow->execute([$companyId]);
            $companyName = $cRow->fetchColumn() ?: '';
        } catch(Exception $e) {}
    }

    if ($isRep && !$repCompanyId) {
        $error = 'حسابك غير مرتبط بأي شركة، لا يمكنك إضافة رحلة.';
    } elseif (!$fromCity || !$toCity || !$price) {
        $error = 'يرجى تعبئة الحقول المطلوبة (من، إلى، السعر).';
    } else {
        try {
            $stmt = $db->prepare("INSERT INTO routes
                (from_city,to_city,departure_time,arrival_time,price,seats_total,company,company_id,bus_type,active,created_at)
                VALUES (?,?,?,?,?,?,?,?,?,1,?)");
            $stmt->execute([$fromCity,$toCity,$departureTime,$arrivalTime,
                            $price,$seatsTotal,$companyName,$companyId,$busType,date('Y-m-d H:i:s')]);
            $message = 'تمت إضافة الرحلة بنجاح!';
        } catch (Exception $e) {
            $message = 'تمت الإضافة (وضع التجربة)!';
        }
    }
}

// ─── 2. تعديل رحلة ─────────────────────────────────────────────────────────
if (!$isRep && $_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit_route') {
    $id            = (int)($_POST['route_id']          ?? 0);
    $fromCity      = sanitize($_POST['from_city']      ?? '');
    $toCity        = sanitize($_POST['to_city']        ?? '');
    $departureTime = sanitize($_POST['departure_time'] ?? '');
    $arrivalTime   = sanitize($_POST['arrival_time']   ?? '');
    $price         = (float)($_POST['price']           ?? 0);
    $seatsTotal    = (int)($_POST['seats_total']       ?? 40);
    $companyId     = (int)($_POST['company_id']        ?? 0) ?: null;
    $busType       = sanitize($_POST['bus_type']       ?? '');

    $companyName = '';
    if ($companyId) {
        try {
            $cRow = $db->prepare("SELECT name FROM companies WHERE id=?");
            $cRow->execute([$companyId]);
            $companyName = $cRow->fetchColumn() ?: '';
        } catch(Exception $e) {}
    }

    if (!$id || !$fromCity || !$toCity || !$price) {
        $error = 'يرجى تعبئة جميع الحقول المطلوبة.';
    } else {
        try {
            $stmt = $db->prepare("UPDATE routes SET
                from_city=?, to_city=?, departure_time=?, arrival_time=?,
                price=?, seats_total=?, company=?, company_id=?, bus_type=?
                WHERE id=?");
            $stmt->execute([$fromCity,$toCity,$departureTime,$arrivalTime,
                            $price,$seatsTotal,$companyName,$companyId,$busType,$id]);
            $message = 'تم تحديث الرحلة بنجاح!';
        } catch (Exception $e) {
            $message = 'تم تحديث الرحلة (وضع التجربة)!';
        }
    }
}

// ─── 3. حذف رحلة ───────────────────────────────────────────────────────────
if (isset($_GET['delete'])) {
    $delId = (int)$_GET['delete'];
    $canDelete = true;

    if ($isRep) {
        // التحقق من ملكية الرحلة لشركة الممثل
        try {
            $ownStmt = $db->prepare("SELECT company_id FROM routes WHERE id=?");
            $ownStmt->execute([$delId]);
            $ownerCompanyId = $ownStmt->fetchColumn();
            if ((int)$ownerCompanyId !== (int)$repCompanyId) {
                $canDelete = false;
                $error = 'لا يمكنك حذف رحلة لا تتبع شركتك.';
            }
        } catch (Exception $e) { $canDelete = false; }
    }

    if ($canDelete && routeHasBookings($delId)) {
        $canDelete = false;
        $error = 'لا يمكن حذف هذه الرحلة لوجود حجوزات عليها.';
    }

    if ($canDelete) {
        try {
            $db->prepare("UPDATE routes SET active=0 WHERE id=?")->execute([$delId]);
            $message = 'تم حذف الرحلة.';
        } catch (Exception $e) { $message = 'تم تنفيذ العملية (وضع التجربة).'; }
    }
}

// ─── 4. جلب الرحلات ─────────────────────────────────────────────────────────
$routes = [];
try {
    if ($isRep && $repCompanyId) {
        // ممثل الشركة: رحلات شركته فقط
        $stmt = $db->prepare("SELECT r.*, c.name as company_name FROM routes r LEFT JOIN companies c ON r.company_id=c.id WHERE r.active=1 AND r.company_id=? ORDER BY r.from_city, r.departure_time");
        $stmt->execute([$repCompanyId]);
        $routes = $stmt->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $routes = $db->query("SELECT r.*, c.name as company_name FROM routes r LEFT JOIN companies c ON r.company_id=c.id WHERE r.active=1 ORDER BY r.from_city, r.departure_time")
                     ->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $routes = [
        ['id'=>1,'from_city'=>'نواكشوط','to_city'=>'نواذيبو','departure_time'=>'06:00','arrival_time'=>'12:30','price'=>5000,'seats_total'=>40,'company_name'=>'النقل الوطني الموريتاني','bus_type'=>'مكيف - فئة A','active'=>1,'company_id'=>1],
        ['id'=>2,'from_city'=>'نواكشوط','to_city'=>'روصو',   'departure_time'=>'08:00','arrival_time'=>'11:00','price'=>2500,'seats_total'=>35,'company_name'=>'شركة الصحراء للنقل',   'bus_type'=>'VIP','active'=>1,'company_id'=>2],
    ];
}

// ─── 5. تحميل بيانات الرحلة للتعديل ──────────────────────────────────────
$editRoute = null;
if (!$isRep && isset($_GET['edit'])) {
    $editId = (int)$_GET['edit'];
    foreach ($routes as $r) {
        if ((int)$r['id'] === $editId) { $editRoute = $r; break; }
    }
    if (!$editRoute) {
        try {
            $stmt = $db->prepare("SELECT r.*, c.name as company_name FROM routes r LEFT JOIN companies c ON r.company_id=c.id WHERE r.id=? AND r.active=1");
            $stmt->execute([$editId]);
            $editRoute = $stmt->fetch(PDO::FETCH_ASSOC) ?: null;
        } catch (Exception $e) {}
    }
}

$showAddForm  = isset($_GET['action']) && $_GET['action'] === 'add';
$showEditForm = ($editRoute !== null);
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>الرحلات - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; min-width:0; }
.topbar > * { flex-shrink:0; }
.topbar .page-title { flex-shrink:1; min-width:0; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.add-form { background:#fff; border-radius:14px; padding:2rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.edit-form { background:#fff; border-radius:14px; padding:2rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; border-top:4px solid var(--gold); }
.route-card { background:#fff; border-radius:12px; padding:1.2rem; box-shadow:0 2px 10px rgba(0,0,0,.07); border-right:4px solid var(--green-light); margin-bottom:1rem; }
.btn-add { background:var(--green-mid); color:#fff; border:none; border-radius:10px; padding:.7rem 1.8rem; font-weight:700; text-decoration:none; }
.btn-save-edit { background:var(--gold); color:#fff; border:none; border-radius:10px; padding:.7rem 1.8rem; font-weight:700; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link active" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <?php if (!$isRep): ?>
        <li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li>
        <?php endif; ?>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <?php if (!$isRep): ?>
        <li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li>
        <?php endif; ?>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>

<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-route me-2"></i>إدارة الرحلات<?php if ($isRep): ?> <small class="text-muted fw-normal" style="font-size:.75rem;">— رحلات شركتك فقط</small><?php endif; ?></h5>
        <a href="routes.php?action=add" class="btn-add btn">
            <i class="fa fa-plus me-2"></i>إضافة رحلة
        </a>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">
        <?php if ($message): ?><div class="alert alert-success"><i class="fa fa-check me-2"></i><?= $message ?></div><?php endif; ?>
        <?php if ($error):   ?><div class="alert alert-danger"><i class="fa fa-times me-2"></i><?= $error ?></div><?php endif; ?>

        <!-- ─── نموذج الإضافة ─── -->
        <?php if ($showAddForm && !$showEditForm): ?>
        <div class="add-form">
            <h5 class="fw-bold mb-3 text-success"><i class="fa fa-plus-circle me-2"></i>إضافة رحلة جديدة</h5>
            <form method="POST">
                <input type="hidden" name="action" value="add_route">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">من مدينة *</label>
                        <select name="from_city" class="form-select" required>
                            <option value="">اختر</option>
                            <?php foreach($cities as $c): ?><option><?= $c ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">إلى مدينة *</label>
                        <select name="to_city" class="form-select" required>
                            <option value="">اختر</option>
                            <?php foreach($cities as $c): ?><option><?= $c ?></option><?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">وقت الانطلاق</label>
                        <input type="time" name="departure_time" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">وقت الوصول</label>
                        <input type="time" name="arrival_time" class="form-control">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">السعر (أوقية) *</label>
                        <input type="number" name="price" class="form-control" required min="100">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">عدد المقاعد</label>
                        <input type="number" name="seats_total" class="form-control" value="40" min="10" max="80">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">الشركة</label>
                        <?php if ($isRep): ?>
                        <?php
                            $repCompanyName = '';
                            foreach ($companiesList as $co) { if ((int)$co['id'] === (int)$repCompanyId) { $repCompanyName = $co['name']; break; } }
                        ?>
                        <input type="text" class="form-control" value="<?= htmlspecialchars($repCompanyName ?: '—') ?>" disabled>
                        <small class="text-muted">سيتم تسجيل الرحلة باسم شركتك تلقائياً.</small>
                        <?php else: ?>
                        <select name="company_id" class="form-select">
                            <option value="">— اختر الشركة —</option>
                            <?php foreach ($companiesList as $co): ?>
                            <option value="<?= $co['id'] ?>"><?= htmlspecialchars($co['name']) ?></option>
                            <?php endforeach; ?>
                        </select>
                        <?php endif; ?>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">نوع الباص</label>
                        <select name="bus_type" class="form-select">
                            <option>مكيف - فئة A</option>
                            <option>VIP - مكيف فاخر</option>
                            <option>مكيف</option>
                            <option>عادي</option>
                        </select>
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-add btn"><i class="fa fa-save me-2"></i>حفظ الرحلة</button>
                        <a href="routes.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- ─── نموذج التعديل ─── -->
        <?php if ($showEditForm): ?>
        <div class="edit-form">
            <h5 class="fw-bold mb-3" style="color:var(--gold);">
                <i class="fa fa-edit me-2"></i>تعديل الرحلة: <?= htmlspecialchars($editRoute['from_city']) ?> ← <?= htmlspecialchars($editRoute['to_city']) ?>
            </h5>
            <form method="POST">
                <input type="hidden" name="action"   value="edit_route">
                <input type="hidden" name="route_id" value="<?= (int)$editRoute['id'] ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">من مدينة *</label>
                        <select name="from_city" class="form-select" required>
                            <option value="">اختر</option>
                            <?php foreach($cities as $c): ?>
                            <option <?= $c === $editRoute['from_city'] ? 'selected' : '' ?>><?= $c ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">إلى مدينة *</label>
                        <select name="to_city" class="form-select" required>
                            <option value="">اختر</option>
                            <?php foreach($cities as $c): ?>
                            <option <?= $c === $editRoute['to_city'] ? 'selected' : '' ?>><?= $c ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">وقت الانطلاق</label>
                        <input type="time" name="departure_time" class="form-control"
                               value="<?= htmlspecialchars($editRoute['departure_time'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">وقت الوصول</label>
                        <input type="time" name="arrival_time" class="form-control"
                               value="<?= htmlspecialchars($editRoute['arrival_time'] ?? '') ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">السعر (أوقية) *</label>
                        <input type="number" name="price" class="form-control" required min="100"
                               value="<?= (int)($editRoute['price'] ?? 0) ?>">
                    </div>
                    <div class="col-md-3">
                        <label class="form-label fw-bold">عدد المقاعد</label>
                        <input type="number" name="seats_total" class="form-control" min="10" max="80"
                               value="<?= (int)($editRoute['seats_total'] ?? 40) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">الشركة</label>
                        <select name="company_id" class="form-select">
                            <option value="">— اختر الشركة —</option>
                            <?php foreach ($companiesList as $co): ?>
                            <option value="<?= $co['id'] ?>" <?= ($editRoute['company_id'] ?? 0) == $co['id'] ? 'selected' : '' ?>>
                                <?= htmlspecialchars($co['name']) ?>
                            </option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">نوع الباص</label>
                        <select name="bus_type" class="form-select">
                            <?php foreach(['مكيف - فئة A','VIP - مكيف فاخر','مكيف','عادي'] as $bt): ?>
                            <option <?= $bt === ($editRoute['bus_type']??'') ? 'selected' : '' ?>><?= $bt ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-save-edit btn">
                            <i class="fa fa-save me-2"></i>حفظ التعديلات
                        </button>
                        <a href="routes.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- ─── قائمة الرحلات ─── -->
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="fw-bold mb-0">
                <i class="fa fa-list me-2 text-success"></i>الرحلات النشطة (<?= count($routes) ?>)
            </h6>
        </div>

        <?php if (empty($routes)): ?>
        <div class="text-center text-muted py-5 bg-white rounded-3 shadow-sm">
            <i class="fa fa-route fa-3x mb-3 d-block opacity-25"></i>لا توجد رحلات بعد
        </div>
        <?php else: ?>
        <?php foreach($routes as $r): ?>
        <div class="route-card <?= ($editRoute && $editRoute['id']==$r['id']) ? 'border border-warning' : '' ?>">
            <div class="row align-items-center">
                <div class="col-md-4">
                    <div class="d-flex align-items-center gap-2">
                        <i class="fa fa-map-marker-alt text-success"></i>
                        <div>
                            <strong><?= htmlspecialchars($r['from_city']) ?></strong>
                            <i class="fa fa-arrow-left mx-2 text-muted" style="font-size:.8rem;"></i>
                            <strong><?= htmlspecialchars($r['to_city']) ?></strong>
                        </div>
                    </div>
                    <small class="text-muted ms-4"><i class="fa fa-building me-1"></i><?= htmlspecialchars($r['company_name'] ?? $r['company'] ?? '') ?></small>
                </div>
                <div class="col-md-2 text-center">
                    <div class="fw-bold"><?= $r['departure_time'] ?> ← <?= $r['arrival_time'] ?></div>
                    <small class="text-muted">الانطلاق ← الوصول</small>
                </div>
                <div class="col-md-2 text-center">
                    <span class="badge" style="background:#f0f9ff;color:#0369a1;font-size:.8rem;"><?= htmlspecialchars($r['bus_type']) ?></span>
                </div>
                <div class="col-md-2 text-center">
                    <div class="fw-bold" style="color:var(--gold);font-size:1.1rem;"><?= number_format($r['price'],0) ?></div>
                    <small class="text-muted">أوقية | <?= $r['seats_total'] ?> مقعد</small>
                </div>
                <div class="col-md-2 text-center">
                    <?php if (!$isRep): ?>
                    <a href="routes.php?edit=<?= $r['id'] ?>"
                       class="btn btn-sm btn-outline-primary rounded-pill me-1"
                       title="تعديل الرحلة">
                        <i class="fa fa-edit"></i>
                    </a>
                    <a href="routes.php?delete=<?= $r['id'] ?>"
                       class="btn btn-sm btn-outline-danger rounded-pill"
                       onclick="return confirm('هل تريد حذف هذه الرحلة؟')"
                       title="حذف الرحلة">
                        <i class="fa fa-trash"></i>
                    </a>
                    <?php else: ?>
                        <?php if (routeHasBookings($r['id'])): ?>
                        <span class="text-muted small" title="توجد حجوزات على هذه الرحلة">
                            <i class="fa fa-lock me-1"></i>لا يمكن الحذف (يوجد حجوزات)
                        </span>
                        <?php else: ?>
                        <a href="routes.php?delete=<?= $r['id'] ?>"
                           class="btn btn-sm btn-outline-danger rounded-pill"
                           onclick="return confirm('هل تريد حذف هذه الرحلة؟')"
                           title="حذف الرحلة">
                            <i class="fa fa-trash me-1"></i>حذف
                        </a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </div>
        </div>
        <?php endforeach; ?>
        <?php endif; ?>

    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
// التمرير تلقائياً إلى نموذج التعديل عند فتحه
<?php if ($showEditForm): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.querySelector('.edit-form').scrollIntoView({behavior:'smooth', block:'start'});
});
<?php endif; ?>
</script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
