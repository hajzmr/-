<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
blockCompanyRep();

$id = (int)($_GET['id'] ?? 0);
$msg = null;
$flash = '';

try {
    $db = getDB();
    ensureContactMessagesTable($db);

    // حفظ الرد
    if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['admin_reply'])) {
        $reply = trim($_POST['admin_reply']);
        if ($reply !== '') {
            $stmt = $db->prepare("UPDATE contact_messages SET admin_reply=?, replied_by=?, replied_at=?, status='replied' WHERE id=?");
            $stmt->execute([$reply, $_SESSION['admin_name'] ?? 'مدير', date('Y-m-d H:i:s'), $id]);
            $flash = 'تم حفظ الرد بنجاح. يمكنك الآن إرساله للعميل عبر واتساب أو البريد.';
        }
    }

    // عند فتح الرسالة لأول مرة، تُعتبر "مقروءة" تلقائياً (إن كانت جديدة)
    $stmt = $db->prepare("SELECT * FROM contact_messages WHERE id=?");
    $stmt->execute([$id]);
    $msg = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($msg && $msg['status'] === 'new') {
        $db->prepare("UPDATE contact_messages SET status='read' WHERE id=?")->execute([$id]);
        $msg['status'] = 'read';
    }
} catch (Exception $e) {
    $msg = null;
}

if (!$msg) {
    echo '<div class="container py-5 text-center"><h4>الرسالة غير موجودة</h4><a href="messages.php" class="btn btn-success mt-3">العودة للرسائل</a></div>';
    exit;
}

function msgStatusBadge2($status) {
    $b = [
        'new'     => ['label'=>'جديدة',   'class'=>'danger'],
        'read'    => ['label'=>'مقروءة',  'class'=>'secondary'],
        'replied' => ['label'=>'تم الرد', 'class'=>'success'],
    ];
    $x = $b[$status] ?? ['label'=>$status,'class'=>'secondary'];
    return "<span class=\"badge bg-{$x['class']}\">{$x['label']}</span>";
}

// روابط رد سريعة
$waPhone = preg_replace('/[^0-9]/', '', $msg['phone']);
$waText  = rawurlencode("مرحباً " . $msg['name'] . "،\n" . ($msg['admin_reply'] ?: "بخصوص رسالتك: \n"));
$waLink  = "https://wa.me/{$waPhone}?text={$waText}";

$mailSubject = rawurlencode('رد على رسالتك - نقل موريتانيا');
$mailBody    = rawurlencode($msg['admin_reply'] ?: '');
$mailLink    = $msg['email'] ? "mailto:" . $msg['email'] . "?subject={$mailSubject}&body={$mailBody}" : '';
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تفاصيل الرسالة - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; min-width:0; }
.topbar > * { flex-shrink:0; }
.topbar .page-title { flex-shrink:1; min-width:0; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.detail-card { background:#fff; border-radius:14px; padding:1.8rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.detail-row { display:flex; align-items:center; padding:.6rem 0; border-bottom:1px solid #f5f5f5; }
.detail-row:last-child { border-bottom:none; }
.detail-label { color:#888; font-size:.85rem; width:140px; flex-shrink:0; }
.detail-value { font-weight:600; font-size:.95rem; }
.message-box { background:#f8fdf9; border-right:4px solid var(--green-light); border-radius:10px; padding:1.2rem 1.5rem; white-space:pre-wrap; line-height:1.8; }
.reply-box { background:#fffdf5; border-right:4px solid var(--gold); border-radius:10px; padding:1.2rem 1.5rem; white-space:pre-wrap; line-height:1.8; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <li><a class="nav-link active" href="messages.php"><i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا</a></li>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>

<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title">
            <a href="messages.php" class="text-decoration-none text-muted me-2"><i class="fa fa-arrow-right"></i></a>
            <i class="fa fa-envelope-open-text me-2"></i>تفاصيل الرسالة
        </h5>
        <a href="messages.php" class="btn btn-sm btn-outline-success rounded-3"><i class="fa fa-list me-1"></i> كل الرسائل</a>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">
        <?php if ($flash): ?>
        <div class="alert alert-success"><i class="fa fa-check me-2"></i><?= $flash ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <div class="col-md-7">
                <!-- بيانات المرسل -->
                <div class="detail-card">
                    <div class="d-flex justify-content-between align-items-start mb-2">
                        <h6 class="fw-bold mb-0" style="color:var(--green-dark);">
                            <i class="fa fa-user me-2 text-success"></i>بيانات المرسل
                        </h6>
                        <?= msgStatusBadge2($msg['status']) ?>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">الاسم</span>
                        <span class="detail-value"><?= htmlspecialchars($msg['name']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">الهاتف</span>
                        <span class="detail-value">
                            <a href="tel:<?= htmlspecialchars($msg['phone']) ?>" class="text-decoration-none" style="color:var(--green-mid);">
                                <i class="fa fa-phone me-1"></i><?= htmlspecialchars($msg['phone']) ?>
                            </a>
                        </span>
                    </div>
                    <?php if ($msg['email']): ?>
                    <div class="detail-row">
                        <span class="detail-label">البريد الإلكتروني</span>
                        <span class="detail-value"><?= htmlspecialchars($msg['email']) ?></span>
                    </div>
                    <?php endif; ?>
                    <div class="detail-row">
                        <span class="detail-label">الموضوع</span>
                        <span class="detail-value"><span class="badge bg-light text-dark border"><?= htmlspecialchars($msg['subject'] ?: '—') ?></span></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">تاريخ الإرسال</span>
                        <span class="detail-value"><?= date('d/m/Y H:i', strtotime($msg['created_at'])) ?></span>
                    </div>
                </div>

                <!-- نص الرسالة -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark);">
                        <i class="fa fa-comment-dots me-2 text-success"></i>نص الرسالة
                    </h6>
                    <div class="message-box"><?= htmlspecialchars($msg['body']) ?></div>
                </div>

                <?php if ($msg['admin_reply']): ?>
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark);">
                        <i class="fa fa-reply me-2 text-warning"></i>الرد المُرسل
                        <small class="text-muted fw-normal">
                            — بواسطة <?= htmlspecialchars($msg['replied_by'] ?? '') ?>
                            في <?= $msg['replied_at'] ? date('d/m/Y H:i', strtotime($msg['replied_at'])) : '' ?>
                        </small>
                    </h6>
                    <div class="reply-box"><?= htmlspecialchars($msg['admin_reply']) ?></div>
                </div>
                <?php endif; ?>
            </div>

            <div class="col-md-5">
                <!-- كتابة / تعديل الرد -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark);">
                        <i class="fa fa-pen me-2 text-success"></i><?= $msg['admin_reply'] ? 'تعديل الرد' : 'كتابة رد' ?>
                    </h6>
                    <form method="POST">
                        <textarea name="admin_reply" class="form-control mb-3" rows="6"
                                  placeholder="اكتب ردك على العميل هنا..."><?= htmlspecialchars($msg['admin_reply'] ?? '') ?></textarea>
                        <button type="submit" class="btn w-100 fw-bold" style="background:var(--green-mid);color:#fff;border:none;border-radius:10px;padding:.7rem;">
                            <i class="fa fa-save me-2"></i>حفظ الرد
                        </button>
                    </form>
                    <p class="text-muted small mt-3 mb-0">
                        <i class="fa fa-info-circle me-1"></i>
                        حفظ الرد هنا يسجّله في النظام فقط. لإرساله فعلياً للعميل استخدم الأزرار أدناه.
                    </p>
                </div>

                <!-- إرسال فعلي -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark);">
                        <i class="fa fa-paper-plane me-2 text-success"></i>إرسال الرد للعميل
                    </h6>
                    <a href="<?= $waLink ?>" target="_blank" class="btn w-100 fw-bold mb-2"
                       style="background:#25d366;color:#fff;border-radius:10px;padding:.7rem;">
                        <i class="fab fa-whatsapp me-2"></i>إرسال عبر واتساب
                    </a>
                    <?php if ($mailLink): ?>
                    <a href="<?= $mailLink ?>" class="btn btn-outline-secondary w-100 fw-bold" style="border-radius:10px;padding:.7rem;">
                        <i class="fa fa-envelope me-2"></i>إرسال عبر البريد الإلكتروني
                    </a>
                    <?php else: ?>
                    <button class="btn btn-outline-secondary w-100 fw-bold" style="border-radius:10px;padding:.7rem;" disabled>
                        <i class="fa fa-envelope me-2"></i>لا يوجد بريد إلكتروني للعميل
                    </button>
                    <?php endif; ?>
                </div>

                <div class="detail-card">
                    <a href="message-action.php?id=<?= $msg['id'] ?>&action=delete" class="btn btn-outline-danger w-100 fw-bold" style="border-radius:10px;padding:.6rem;"
                       onclick="return confirm('هل تريد حذف هذه الرسالة نهائياً؟')">
                        <i class="fa fa-trash me-2"></i>حذف الرسالة
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
