<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdminOrSupervisor();

$message = '';
$error   = '';

$db = getDB();
ensureCompaniesTable($db);

// ── إضافة شركة ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'add_company') {
    $name    = trim($_POST['name']    ?? '');
    $nameFr  = trim($_POST['name_fr'] ?? '');
    $phone   = trim($_POST['phone']   ?? '');
    $email   = trim($_POST['email']   ?? '');
    $address = trim($_POST['address'] ?? '');

    if (!$name) {
        $error = 'يرجى إدخال اسم الشركة.';
    } else {
        try {
            $db->prepare("INSERT INTO companies (name, name_fr, phone, email, address, active, created_at) VALUES (?,?,?,?,?,1,?)")
               ->execute([$name, $nameFr ?: null, $phone ?: null, $email ?: null, $address ?: null, date('Y-m-d H:i:s')]);
            $message = "تمت إضافة شركة «{$name}» بنجاح!";
        } catch (Exception $e) {
            if (stripos($e->getMessage(), 'UNIQUE') !== false || stripos($e->getMessage(), 'duplicate') !== false)
                $error = 'هذه الشركة موجودة بالفعل.';
            else
                $error = 'حدث خطأ: ' . $e->getMessage();
        }
    }
}

// ── تعديل شركة ───────────────────────────────────────────────────────────────
if ($_SERVER['REQUEST_METHOD'] === 'POST' && ($_POST['action'] ?? '') === 'edit_company') {
    $cid     = (int)($_POST['company_id'] ?? 0);
    $name    = trim($_POST['name']    ?? '');
    $nameFr  = trim($_POST['name_fr'] ?? '');
    $phone   = trim($_POST['phone']   ?? '');
    $email   = trim($_POST['email']   ?? '');
    $address = trim($_POST['address'] ?? '');

    if (!$cid || !$name) {
        $error = 'يرجى إدخال اسم الشركة.';
    } else {
        try {
            $db->prepare("UPDATE companies SET name=?, name_fr=?, phone=?, email=?, address=? WHERE id=?")
               ->execute([$name, $nameFr ?: null, $phone ?: null, $email ?: null, $address ?: null, $cid]);
            $message = "تم تحديث «{$name}» بنجاح!";
        } catch (Exception $e) {
            $error = 'حدث خطأ أثناء التحديث.';
        }
    }
}

// ── تفعيل / تعطيل ─────────────────────────────────────────────────────────────
if (isset($_GET['toggle']) && is_numeric($_GET['toggle'])) {
    try {
        $row = $db->prepare("SELECT active FROM companies WHERE id=?");
        $row->execute([(int)$_GET['toggle']]);
        $cur = $row->fetchColumn();
        $db->prepare("UPDATE companies SET active=? WHERE id=?")->execute([$cur ? 0 : 1, (int)$_GET['toggle']]);
        $message = $cur ? 'تم إيقاف الشركة (لن تظهر في خيارات الرحلات).' : 'تم تفعيل الشركة.';
    } catch (Exception $e) { $error = 'حدث خطأ.'; }
}

// ── حذف شركة ─────────────────────────────────────────────────────────────────
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    try {
        $used = $db->prepare("SELECT COUNT(*) FROM routes WHERE company_id=? AND active=1");
        $used->execute([(int)$_GET['delete']]);
        if ($used->fetchColumn() > 0) {
            $error = 'لا يمكن حذف هذه الشركة لأنها مرتبطة برحلات نشطة. أوقفها بدلاً من الحذف.';
        } else {
            // إلغاء ربط المستخدمين
            $db->prepare("UPDATE users SET company_id=NULL WHERE company_id=?")->execute([(int)$_GET['delete']]);
            $db->prepare("DELETE FROM companies WHERE id=?")->execute([(int)$_GET['delete']]);
            $message = 'تم حذف الشركة.';
        }
    } catch (Exception $e) { $error = 'حدث خطأ أثناء الحذف.'; }
}

// ── جلب الشركات ───────────────────────────────────────────────────────────────
$companies = [];
try {
    $companies = $db->query(
        "SELECT c.*,
            (SELECT COUNT(*) FROM routes r WHERE r.company_id = c.id AND r.active=1) as route_count,
            (SELECT COUNT(*) FROM users u WHERE u.company_id = c.id AND u.active=1) as rep_count
         FROM companies c ORDER BY c.active DESC, c.name"
    )->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $companies = [];
}

// ── تحميل شركة للتعديل ─────────────────────────────────────────────────────────
$editCompany = null;
if (isset($_GET['edit']) && is_numeric($_GET['edit'])) {
    foreach ($companies as $c) {
        if ((int)$c['id'] === (int)$_GET['edit']) { $editCompany = $c; break; }
    }
}

$showAddForm  = isset($_GET['action']) && $_GET['action'] === 'add';
$activeCount  = count(array_filter($companies, fn($c) => $c['active']));
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>إدارة الشركات - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; box-shadow:-4px 0 20px rgba(0,0,0,.2); }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.btn-add-main { background:var(--green-mid); color:#fff; border:none; border-radius:10px; padding:.65rem 1.6rem; font-weight:700; text-decoration:none; display:inline-flex; align-items:center; gap:6px; }
.btn-add-main:hover { background:var(--green-dark); color:#fff; }
.card-form { background:#fff; border-radius:14px; padding:2rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.card-form.edit-mode { border-top:4px solid var(--gold); }
.card-form.add-mode  { border-top:4px solid var(--green-light); }
.data-table { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.07); }
.data-table .table-responsive { overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%; max-width:100%; }
.table { min-width:700px; }
.table th { background:var(--green-dark); color:#fff; font-weight:600; padding:.9rem 1rem; border:none; font-size:.88rem; }
.table td { padding:.75rem 1rem; vertical-align:middle; border-color:#f0f0f0; }
.table tbody tr:hover { background:#f8fdf9; }
.action-btn { padding:4px 11px; border-radius:7px; font-size:.8rem; border:none; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; gap:4px; transition:opacity .15s; }
.action-btn:hover { opacity:.8; }
.btn-edit { background:#eef5ff; color:#3498db; }
.btn-on   { background:#e8f5f0; color:var(--green-mid); }
.btn-off  { background:#fff3cd; color:#856404; }
.btn-del  { background:#fef0f0; color:#e74c3c; }
.stat-mini { background:#fff; border-radius:12px; padding:1.1rem 1.4rem; box-shadow:0 2px 10px rgba(0,0,0,.07); border-right:4px solid; display:flex; align-items:center; gap:1rem; }
.company-badge { display:inline-flex; align-items:center; gap:6px; background:#f0fdf4; color:var(--green-mid); border-radius:8px; padding:4px 12px; font-size:.88rem; font-weight:600; }
.company-badge.inactive { background:#f8f9fa; color:#aaa; }
.count-pill { border-radius:20px; padding:2px 9px; font-size:.78rem; font-weight:700; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width:991px){
    .sidebar { right:-280px; transition:right .25s ease; }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}
.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>

<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <li><a class="nav-link active" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>

<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-building me-2"></i>إدارة الشركات</h5>
        <a href="companies.php?action=add" class="btn-add-main">
            <i class="fa fa-plus"></i> إضافة شركة
        </a>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">

        <?php if ($message): ?>
        <div class="alert alert-success alert-dismissible fade show">
            <i class="fa fa-check-circle me-2"></i><?= $message ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>
        <?php if ($error): ?>
        <div class="alert alert-danger alert-dismissible fade show">
            <i class="fa fa-exclamation-circle me-2"></i><?= $error ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert"></button>
        </div>
        <?php endif; ?>

        <!-- إحصاء -->
        <div class="row g-3 mb-4">
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:var(--green-light);">
                    <i class="fa fa-building fa-2x opacity-25 text-success"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:var(--green-mid);"><?= count($companies) ?></div>
                        <div class="text-muted small">إجمالي الشركات</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:#3498db;">
                    <i class="fa fa-check-circle fa-2x opacity-25 text-primary"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:#3498db;"><?= $activeCount ?></div>
                        <div class="text-muted small">شركات نشطة</div>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="stat-mini" style="border-color:var(--gold);">
                    <i class="fa fa-route fa-2x opacity-25" style="color:var(--gold);"></i>
                    <div>
                        <div style="font-size:1.6rem;font-weight:800;color:var(--gold);"><?= array_sum(array_column($companies,'route_count')) ?></div>
                        <div class="text-muted small">رحلات مرتبطة</div>
                    </div>
                </div>
            </div>
        </div>

        <!-- نموذج الإضافة -->
        <?php if ($showAddForm && !$editCompany): ?>
        <div class="card-form add-mode" id="add-form-section">
            <h5 class="fw-bold mb-4" style="color:var(--green-dark);">
                <i class="fa fa-plus-circle me-2 text-success"></i>إضافة شركة جديدة
            </h5>
            <form method="POST">
                <input type="hidden" name="action" value="add_company">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">اسم الشركة بالعربية *</label>
                        <input type="text" name="name" class="form-control" placeholder="مثال: شركة الصحراء للنقل" required>
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">الاسم بالفرنسية <span class="text-muted fw-normal">(اختياري)</span></label>
                        <input type="text" name="name_fr" class="form-control" placeholder="مثال: Sahara Transport">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">رقم الهاتف</label>
                        <input type="text" name="phone" class="form-control" placeholder="مثال: 22201234">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">البريد الإلكتروني</label>
                        <input type="email" name="email" class="form-control" placeholder="info@company.mr">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">العنوان</label>
                        <input type="text" name="address" class="form-control" placeholder="العنوان">
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-add-main btn">
                            <i class="fa fa-save me-1"></i>حفظ الشركة
                        </button>
                        <a href="companies.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- نموذج التعديل -->
        <?php if ($editCompany): ?>
        <div class="card-form edit-mode" id="edit-form-section">
            <h5 class="fw-bold mb-4" style="color:var(--green-dark);">
                <i class="fa fa-edit me-2" style="color:var(--gold);"></i>تعديل: <?= htmlspecialchars($editCompany['name']) ?>
            </h5>
            <form method="POST">
                <input type="hidden" name="action"     value="edit_company">
                <input type="hidden" name="company_id" value="<?= (int)$editCompany['id'] ?>">
                <div class="row g-3">
                    <div class="col-md-6">
                        <label class="form-label fw-bold">اسم الشركة بالعربية *</label>
                        <input type="text" name="name" class="form-control" required value="<?= htmlspecialchars($editCompany['name']) ?>">
                    </div>
                    <div class="col-md-6">
                        <label class="form-label fw-bold">الاسم بالفرنسية</label>
                        <input type="text" name="name_fr" class="form-control" value="<?= htmlspecialchars($editCompany['name_fr'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">رقم الهاتف</label>
                        <input type="text" name="phone" class="form-control" value="<?= htmlspecialchars($editCompany['phone'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">البريد الإلكتروني</label>
                        <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($editCompany['email'] ?? '') ?>">
                    </div>
                    <div class="col-md-4">
                        <label class="form-label fw-bold">العنوان</label>
                        <input type="text" name="address" class="form-control" value="<?= htmlspecialchars($editCompany['address'] ?? '') ?>">
                    </div>
                    <div class="col-12 d-flex gap-2">
                        <button type="submit" class="btn-add-main btn" style="background:var(--gold);">
                            <i class="fa fa-save me-1"></i>حفظ التعديلات
                        </button>
                        <a href="companies.php" class="btn btn-outline-secondary rounded-3 px-4">إلغاء</a>
                    </div>
                </div>
            </form>
        </div>
        <?php endif; ?>

        <!-- جدول الشركات -->
        <div class="data-table">
            <div class="d-flex justify-content-between align-items-center p-3 border-bottom">
                <h6 class="fw-bold mb-0">
                    <i class="fa fa-list me-2 text-success"></i>قائمة الشركات (<?= count($companies) ?>)
                </h6>
                <small class="text-muted">الشركات النشطة تظهر في قوائم الرحلات</small>
            </div>
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>اسم الشركة</th>
                            <th>الهاتف</th>
                            <th>الرحلات</th>
                            <th>الممثلون</th>
                            <th>الحالة</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($companies)): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted">
                        <i class="fa fa-building fa-3x mb-3 d-block opacity-25"></i>لا توجد شركات بعد
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($companies as $c): ?>
                    <tr class="<?= $editCompany && (int)$editCompany['id']===(int)$c['id'] ? 'table-warning' : '' ?>">
                        <td class="text-muted small"><?= $c['id'] ?></td>
                        <td>
                            <div class="company-badge <?= $c['active'] ? '' : 'inactive' ?>">
                                <i class="fa fa-building" style="font-size:.8rem;"></i>
                                <?= htmlspecialchars($c['name']) ?>
                            </div>
                            <?php if (!empty($c['name_fr'])): ?>
                            <div class="text-muted small mt-1"><?= htmlspecialchars($c['name_fr']) ?></div>
                            <?php endif; ?>
                        </td>
                        <td class="text-muted small"><?= htmlspecialchars($c['phone'] ?? '—') ?></td>
                        <td>
                            <?php if ($c['route_count'] > 0): ?>
                            <span class="count-pill" style="background:#e8f0ff;color:#3366cc;">
                                <i class="fa fa-route me-1"></i><?= $c['route_count'] ?>
                            </span>
                            <?php else: ?><span class="text-muted small">—</span><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($c['rep_count'] > 0): ?>
                            <span class="count-pill" style="background:#fff3cd;color:#856404;">
                                <i class="fa fa-user me-1"></i><?= $c['rep_count'] ?>
                            </span>
                            <?php else: ?><span class="text-muted small">—</span><?php endif; ?>
                        </td>
                        <td>
                            <?php if ($c['active']): ?>
                            <span class="text-success small fw-bold">
                                <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#27ae60;margin-left:5px;"></span>نشطة
                            </span>
                            <?php else: ?>
                            <span class="text-danger small fw-bold">
                                <span style="display:inline-block;width:8px;height:8px;border-radius:50%;background:#e74c3c;margin-left:5px;"></span>موقوفة
                            </span>
                            <?php endif; ?>
                        </td>
                        <td>
                            <div class="d-flex gap-1 flex-wrap">
                                <a href="companies.php?edit=<?= $c['id'] ?>" class="action-btn btn-edit">
                                    <i class="fa fa-edit"></i> تعديل
                                </a>
                                <a href="companies.php?toggle=<?= $c['id'] ?>"
                                   class="action-btn <?= $c['active'] ? 'btn-off' : 'btn-on' ?>"
                                   onclick="return confirm('<?= $c['active'] ? 'إيقاف' : 'تفعيل' ?> شركة <?= htmlspecialchars($c['name']) ?>؟')">
                                    <i class="fa <?= $c['active'] ? 'fa-eye-slash' : 'fa-eye' ?>"></i>
                                    <?= $c['active'] ? 'إيقاف' : 'تفعيل' ?>
                                </a>
                                <?php if ($c['route_count'] == 0 && $c['rep_count'] == 0): ?>
                                <a href="companies.php?delete=<?= $c['id'] ?>" class="action-btn btn-del"
                                   onclick="return confirm('حذف شركة «<?= htmlspecialchars($c['name']) ?>» نهائياً؟')">
                                    <i class="fa fa-trash"></i>
                                </a>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-3 p-3 rounded-3" style="background:#fffbeb;border-right:4px solid var(--gold);">
            <small class="text-muted">
                <i class="fa fa-info-circle me-1" style="color:var(--gold);"></i>
                <strong>ملاحظة:</strong> الشركات النشطة تظهر في قوائم الاختيار عند إضافة الرحلات.
                الشركات المرتبطة برحلات أو ممثلين نشطين لا يمكن حذفها، استخدم «إيقاف» بدلاً من الحذف.
                يمكنك ربط كل مستخدم بشركة من صفحة <a href="users.php">إدارة المستخدمين</a>.
            </small>
        </div>

    </div>
</div>

<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
<?php if ($editCompany): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('edit-form-section').scrollIntoView({behavior:'smooth', block:'start'});
});
<?php elseif ($showAddForm): ?>
document.addEventListener('DOMContentLoaded', function() {
    document.getElementById('add-form-section').scrollIntoView({behavior:'smooth', block:'start'});
});
<?php endif; ?>
</script>
<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){ btn.addEventListener('click', function(){ sidebar.classList.contains('open') ? closeSidebar() : openSidebar(); }); });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){ link.addEventListener('click', closeSidebar); });
})();
</script>
</body>
</html>
