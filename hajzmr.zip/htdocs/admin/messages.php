<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
blockCompanyRep();

$statusFilter = sanitize($_GET['status'] ?? '');
$search       = sanitize($_GET['search'] ?? '');
$messages     = [];
$counts       = ['all'=>0,'new'=>0,'read'=>0,'replied'=>0];

try {
    $db = getDB();
    ensureContactMessagesTable($db);

    // عدّادات لكل حالة
    $r = $db->query("SELECT status, COUNT(*) as cnt FROM contact_messages GROUP BY status")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($r as $row) { $counts[$row['status']] = (int)$row['cnt']; }
    $counts['all'] = array_sum($counts) - $counts['all']; // مجموع الحالات الثلاث فقط

    $sql = "SELECT * FROM contact_messages WHERE 1=1";
    $params = [];
    if ($statusFilter) { $sql .= " AND status = ?"; $params[] = $statusFilter; }
    if ($search) {
        $sql .= " AND (name LIKE ? OR phone LIKE ? OR email LIKE ? OR body LIKE ?)";
        $params = array_merge($params, ["%$search%","%$search%","%$search%","%$search%"]);
    }
    $sql .= " ORDER BY id DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $messages = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $messages = [];
}

function msgStatusBadge($status) {
    $b = [
        'new'     => ['label'=>'جديدة',   'class'=>'danger'],
        'read'    => ['label'=>'مقروءة',  'class'=>'secondary'],
        'replied' => ['label'=>'تم الرد', 'class'=>'success'],
    ];
    $x = $b[$status] ?? ['label'=>$status,'class'=>'secondary'];
    return "<span class=\"badge bg-{$x['class']}\">{$x['label']}</span>";
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>رسائل اتصل بنا - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; min-width:0; }
.topbar > * { flex-shrink:0; }
.topbar .page-title { flex-shrink:1; min-width:0; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.data-table { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.07); }
.data-table .table-responsive { overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%; max-width:100%; }
.table { min-width:700px; }
.table th { background:var(--green-dark); color:#fff; font-weight:600; padding:.9rem 1rem; border:none; font-size:.88rem; }
.table td { padding:.75rem 1rem; vertical-align:middle; border-color:#f0f0f0; font-size:.88rem; }
.table tbody tr.is-new { background:#fffaf0; }
.table tbody tr:hover { background:#f8fdf9; }
.badge { border-radius:20px; font-size:.75rem; padding:4px 10px; }
.filter-bar { background:#fff; border-radius:12px; padding:1rem 1.5rem; box-shadow:0 2px 8px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.action-btn { padding:4px 10px; border-radius:6px; font-size:.8rem; border:none; cursor:pointer; text-decoration:none; display:inline-block; }
.action-btn.view    { background:#eef5ff; color:#3498db; }
.action-btn.cancel  { background:#fef0f0; color:#e74c3c; }
.body-snippet { max-width:260px; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; color:#555; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <li>
            <a class="nav-link active" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if ($counts['new'] > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= $counts['new'] ?></span>
                <?php endif; ?>
            </a>
        </li>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>
<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-envelope-open-text me-2"></i>رسائل اتصل بنا</h5>
        <div class="d-flex align-items-center gap-3 ms-auto">
            <div class="d-flex align-items-center gap-2">
            <div class="admin-avatar" style="width:36px;height:36px;border-radius:50%;background:var(--green-mid);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">
                <?= mb_substr($_SESSION['admin_name']??'م',0,1) ?>
            </div>
            <span class="fw-bold"><?= htmlspecialchars($_SESSION['admin_name']??'مدير') ?></span>
        </div>
            <div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div>
        </div>
    </div>

    <div class="p-4">
        <?php if (isset($_GET['deleted'])): ?>
        <div class="alert alert-success"><i class="fa fa-check me-2"></i>تم حذف الرسالة بنجاح.</div>
        <?php endif; ?>

        <!-- Filters -->
        <div class="filter-bar">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-7">
                    <label class="form-label fw-bold text-muted small mb-1">بحث</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa fa-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="اسم، هاتف، بريد، نص الرسالة..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <button type="submit" class="btn w-100 fw-bold" style="background:var(--green-mid);color:#fff;border-radius:8px;">
                        <i class="fa fa-filter me-1"></i>تصفية
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="messages.php" class="btn btn-outline-secondary w-100 rounded-3">مسح</a>
                </div>
            </form>
        </div>

        <!-- Summary tabs -->
        <div class="d-flex gap-2 mb-3 flex-wrap">
            <a href="messages.php" class="btn btn-sm <?= !$statusFilter?'btn-success':'btn-outline-secondary' ?> rounded-pill">الكل (<?= $counts['all'] ?>)</a>
            <a href="messages.php?status=new" class="btn btn-sm <?= $statusFilter==='new'?'btn-warning':'btn-outline-warning' ?> rounded-pill">جديدة (<?= $counts['new'] ?>)</a>
            <a href="messages.php?status=read" class="btn btn-sm <?= $statusFilter==='read'?'btn-secondary':'btn-outline-secondary' ?> rounded-pill">مقروءة (<?= $counts['read'] ?>)</a>
            <a href="messages.php?status=replied" class="btn btn-sm <?= $statusFilter==='replied'?'btn-primary':'btn-outline-primary' ?> rounded-pill">تم الرد (<?= $counts['replied'] ?>)</a>
        </div>

        <!-- Table -->
        <div class="data-table">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>المرسل</th>
                            <th>الموضوع</th>
                            <th>الرسالة</th>
                            <th>الحالة</th>
                            <th>التاريخ</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($messages)): ?>
                    <tr><td colspan="7" class="text-center py-5 text-muted">
                        <i class="fa fa-inbox fa-3x mb-3 d-block"></i>لا توجد رسائل
                    </td></tr>
                    <?php else: ?>
                    <?php foreach ($messages as $m): ?>
                    <tr class="<?= $m['status']==='new' ? 'is-new' : '' ?>">
                        <td class="text-muted"><?= $m['id'] ?></td>
                        <td>
                            <strong><?= htmlspecialchars($m['name']) ?></strong><br>
                            <small class="text-muted"><i class="fa fa-phone me-1"></i><?= htmlspecialchars($m['phone']) ?></small>
                        </td>
                        <td><span class="badge bg-light text-dark border"><?= htmlspecialchars($m['subject'] ?: '—') ?></span></td>
                        <td class="body-snippet" title="<?= htmlspecialchars($m['body']) ?>"><?= htmlspecialchars($m['body']) ?></td>
                        <td><?= msgStatusBadge($m['status']) ?></td>
                        <td><small class="text-muted"><?= date('d/m/Y H:i', strtotime($m['created_at'])) ?></small></td>
                        <td>
                            <div class="d-flex gap-1">
                                <a href="message-detail.php?id=<?= $m['id'] ?>" class="action-btn view"><i class="fa fa-eye"></i> عرض / رد</a>
                                <a href="message-action.php?id=<?= $m['id'] ?>&action=delete" class="action-btn cancel" onclick="return confirm('هل تريد حذف هذه الرسالة نهائياً؟')"><i class="fa fa-trash"></i></a>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
