<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();

$statusFilter = sanitize($_GET['status'] ?? '');
$search       = sanitize($_GET['search'] ?? '');
$bookings     = [];

$isRep        = isCompanyRep();
$repCompanyId = getSessionCompanyId();

try {
    $db  = getDB();
    $sql = "SELECT b.*, r.from_city, r.to_city, r.departure_time, r.company, r.company_id, COALESCE(b.travelled,0) as travelled, COALESCE(b.cancelled,0) as cancelled
            FROM bookings b LEFT JOIN routes r ON b.route_id = r.id
            WHERE 1=1";
    $params = [];

    // ممثل الشركة: يرى حجوزات شركته فقط
    if ($isRep && $repCompanyId) {
        $sql .= " AND r.company_id = ?";
        $params[] = $repCompanyId;
    }

    if ($statusFilter) { $sql .= " AND b.status = ?"; $params[] = $statusFilter; }
    if ($search) {
        $sql .= " AND (b.booking_ref LIKE ? OR b.passenger_name LIKE ? OR b.passenger_phone LIKE ?)";
        $params = array_merge($params, ["%$search%","%$search%","%$search%"]);
    }
    $sql .= " ORDER BY b.id DESC";
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    $bookings = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $bookings = [
        ['id'=>247,'booking_ref'=>'MRT-A8F2C1D3','from_city'=>'نواكشوط','to_city'=>'نواذيبو','departure_time'=>'06:00','company'=>'النقل الوطني','passenger_name'=>'أحمد ولد محمد','passenger_phone'=>'22001234','seat_count'=>2,'total_price'=>10000,'status'=>'confirmed','travel_date'=>date('Y-m-d',strtotime('+1 day')),'payment_method'=>'cash','created_at'=>date('Y-m-d H:i:s')],
        ['id'=>246,'booking_ref'=>'MRT-B9E3F2A1','from_city'=>'نواكشوط','to_city'=>'روصو','departure_time'=>'09:30','company'=>'شركة الصحراء','passenger_name'=>'فاطمة بنت أحمد','passenger_phone'=>'22005678','seat_count'=>1,'total_price'=>2500,'status'=>'pending','travel_date'=>date('Y-m-d',strtotime('+2 day')),'payment_method'=>'mobile','created_at'=>date('Y-m-d H:i:s',strtotime('-1 hour'))],
        ['id'=>245,'booking_ref'=>'MRT-C7D4E5B2','from_city'=>'نواذيبو','to_city'=>'زويرات','departure_time'=>'08:00','company'=>'النقل الوطني','passenger_name'=>'محمد سالم','passenger_phone'=>'22009012','seat_count'=>3,'total_price'=>9000,'status'=>'confirmed','travel_date'=>date('Y-m-d'),'payment_method'=>'card','created_at'=>date('Y-m-d H:i:s',strtotime('-2 hour'))],
        ['id'=>244,'booking_ref'=>'MRT-D1A5B8C9','from_city'=>'كيفة','to_city'=>'نواكشوط','departure_time'=>'07:00','company'=>'خطوط الأمل','passenger_name'=>'مريم بنت سيدي','passenger_phone'=>'22003456','seat_count'=>1,'total_price'=>3500,'status'=>'cancelled','travel_date'=>date('Y-m-d',strtotime('-1 day')),'payment_method'=>'cash','created_at'=>date('Y-m-d H:i:s',strtotime('-5 hour'))],
        ['id'=>243,'booking_ref'=>'MRT-E2F6G7H8','from_city'=>'نواكشوط','to_city'=>'أطار','departure_time'=>'06:30','company'=>'النقل الوطني','passenger_name'=>'عبد الله ولد بكر','passenger_phone'=>'22007890','seat_count'=>2,'total_price'=>9000,'status'=>'confirmed','travel_date'=>date('Y-m-d',strtotime('+3 day')),'payment_method'=>'cash','created_at'=>date('Y-m-d H:i:s',strtotime('-6 hour'))],
        ['id'=>242,'booking_ref'=>'MRT-F3G8H9I0','from_city'=>'نواكشوط','to_city'=>'كيهيدي','departure_time'=>'10:00','company'=>'شركة الصحراء','passenger_name'=>'زينب بنت محمد','passenger_phone'=>'22001111','seat_count'=>2,'total_price'=>7000,'status'=>'pending','travel_date'=>date('Y-m-d',strtotime('+1 day')),'payment_method'=>'mobile','created_at'=>date('Y-m-d H:i:s',strtotime('-8 hour'))],
    ];
}

$paymentLabels = ['cash'=>'نقداً','mobile'=>'هاتف','card'=>'بطاقة','bankily'=>'بنكيلي','masrafi'=>'مصرفي'];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>الحجوزات - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; min-width:0; }
.topbar > * { flex-shrink:0; }
.topbar .page-title { flex-shrink:1; min-width:0; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.data-table { background:#fff; border-radius:14px; overflow:hidden; box-shadow:0 2px 12px rgba(0,0,0,.07); }
.data-table .table-responsive { border-radius:0; overflow-x:auto; -webkit-overflow-scrolling:touch; width:100%; max-width:100%; }
.table { min-width:850px; }
.table th { background:var(--green-dark); color:#fff; font-weight:600; padding:.75rem .75rem; border:none; font-size:.82rem; white-space:nowrap; }
.table td { padding:.65rem .75rem; vertical-align:middle; border-color:#f0f0f0; font-size:.82rem; }
.table tbody tr:hover { background:#f8fdf9; }
.badge { border-radius:20px; font-size:.72rem; padding:3px 8px; white-space:nowrap; }
.filter-bar { background:#fff; border-radius:12px; padding:1rem 1.5rem; box-shadow:0 2px 8px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.action-btn { padding:5px 8px; border-radius:6px; font-size:.8rem; border:none; cursor:pointer; text-decoration:none; display:inline-flex; align-items:center; justify-content:center; width:28px; height:28px; }
th:last-child, td:last-child { white-space:nowrap; }
.action-btn.confirm { background:#e8f5f0; color:var(--green-mid); }
.action-btn.cancel  { background:#fef0f0; color:#e74c3c; }
.action-btn.view    { background:#eef5ff; color:#3498db; }
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i>لوحة التحكم</a></li>
        <li><a class="nav-link active" href="bookings.php"><i class="fa fa-ticket-alt"></i>الحجوزات</a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i>رسائل اتصل بنا
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i>إدارة الرحلات</a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i>المدن</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i>الشركات</a></li><?php endif; ?>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i>التقارير</a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i>محاسبة الشركات</a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i>المستخدمون</a></li><?php endif; ?>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i>عرض الموقع</a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i>تسجيل الخروج</a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>
<div class="main-content">
    <div class="topbar">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title"><i class="fa fa-ticket-alt me-2"></i>إدارة الحجوزات</h5>
        <div class="d-flex align-items-center gap-3 ms-auto">
            <div class="d-flex align-items-center gap-2">
            <div class="admin-avatar" style="width:36px;height:36px;border-radius:50%;background:var(--green-mid);display:flex;align-items:center;justify-content:center;color:#fff;font-weight:700;">
                <?= mb_substr($_SESSION['admin_name']??'م',0,1) ?>
            </div>
            <span class="fw-bold"><?= htmlspecialchars($_SESSION['admin_name']??'مدير') ?></span>
        </div>
            <div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div>
        </div>
    </div>

    <div class="p-4">
        <!-- Filters -->
        <div class="filter-bar">
            <form method="GET" class="row g-2 align-items-end">
                <div class="col-md-5">
                    <label class="form-label fw-bold text-muted small mb-1">بحث</label>
                    <div class="input-group">
                        <span class="input-group-text"><i class="fa fa-search"></i></span>
                        <input type="text" name="search" class="form-control" placeholder="رقم حجز، اسم، هاتف..." value="<?= htmlspecialchars($search) ?>">
                    </div>
                </div>
                <div class="col-md-3">
                    <label class="form-label fw-bold text-muted small mb-1">الحالة</label>
                    <select name="status" class="form-select">
                        <option value="">جميع الحالات</option>
                        <option value="pending"   <?= $statusFilter==='pending'  ?'selected':'' ?>>في الانتظار</option>
                        <option value="confirmed" <?= $statusFilter==='confirmed'?'selected':'' ?>>مؤكد</option>
                        <option value="cancelled" <?= $statusFilter==='cancelled'?'selected':'' ?>>ملغي</option>
                        <option value="payment_pending" <?= $statusFilter==='payment_pending'?'selected':'' ?>>⏳ بانتظار تأكيد الدفع</option>
                        <option value="completed" <?= $statusFilter==='completed'?'selected':'' ?>>مكتمل</option>
                    </select>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="btn w-100 fw-bold" style="background:var(--green-mid);color:#fff;border-radius:8px;">
                        <i class="fa fa-filter me-1"></i>تصفية
                    </button>
                </div>
                <div class="col-md-2">
                    <a href="bookings.php" class="btn btn-outline-secondary w-100 rounded-3">مسح</a>
                </div>
            </form>
        </div>

        <!-- Summary tabs -->
        <div class="d-flex gap-2 mb-3 flex-wrap">
            <a href="bookings.php" class="btn btn-sm <?= !$statusFilter?'btn-success':'btn-outline-secondary' ?> rounded-pill">الكل (<?= count($bookings) ?>)</a>
            <a href="bookings.php?status=pending" class="btn btn-sm <?= $statusFilter==='pending'?'btn-warning':'btn-outline-warning' ?> rounded-pill">في الانتظار</a>
            <a href="bookings.php?status=confirmed" class="btn btn-sm <?= $statusFilter==='confirmed'?'btn-primary':'btn-outline-primary' ?> rounded-pill">مؤكد</a>
            <a href="bookings.php?status=payment_pending" class="btn btn-sm <?= $statusFilter==='payment_pending'?'btn-warning text-dark':'btn-outline-warning' ?> rounded-pill">⏳ بانتظار الدفع</a>
            <a href="bookings.php?status=cancelled" class="btn btn-sm <?= $statusFilter==='cancelled'?'btn-danger':'btn-outline-danger' ?> rounded-pill">ملغي</a>
        </div>

        <!-- Table -->
        <div class="data-table">
            <div class="table-responsive">
                <table class="table table-hover mb-0">
                    <thead>
                        <tr<?= !empty($b['cancelled']) ? ' style="background:#fff5f5;"' : '' ?>>
                            <th>رقم الحجز</th>
                            <th>المسافر</th>
                            <th>الرحلة</th>
                            <th>تاريخ السفر</th>
                            <th>م</th>
                            <th>المبلغ</th>
                            <th>الدفع</th>
                            <th>الحالة</th>
                            <th>السفر</th>
                            <th>الحجز</th>
                            <th>إجراءات</th>
                        </tr>
                    </thead>
                    <tbody>
                    <?php if (empty($bookings)): ?>
                    <tr><td colspan="10" class="text-center py-5 text-muted">
                        <i class="fa fa-inbox fa-3x mb-3 d-block"></i>لا توجد حجوزات
                    </td></tr>
                    <?php else: ?>
                    <?php foreach($bookings as $b): ?>
                    <tr>
                        <td><code style="font-size:.75rem;background:#f8f9fa;padding:2px 5px;border-radius:4px;white-space:nowrap;"><?= htmlspecialchars($b['booking_ref']) ?></code></td>
                        <td>
                            <strong><?= htmlspecialchars($b['passenger_name']) ?></strong><br>
                            <small class="text-muted"><i class="fa fa-phone me-1"></i><?= htmlspecialchars($b['passenger_phone']??'') ?></small>
                        </td>
                        <td>
                            <span style="font-size:.85rem;">
                                <?= htmlspecialchars($b['from_city']??'—') ?>
                                <i class="fa fa-arrow-left mx-1 text-success"></i>
                                <?= htmlspecialchars($b['to_city']??'—') ?>
                            </span><br>
                            <small class="text-muted"><i class="fa fa-clock me-1"></i><?= htmlspecialchars($b['departure_time']??'') ?></small>
                        </td>
                        <td><?= $b['travel_date'] ? date('d/m/Y', strtotime($b['travel_date'])) : '—' ?></td>
                        <td class="text-center fw-bold"><?= $b['seat_count'] ?></td>
                        <td class="fw-bold" style="color:var(--gold)"><?= number_format($b['total_price'], 0) ?> <small class="text-muted fw-normal">أوقية</small></td>
                        <td><span class="badge bg-light text-dark border"><?= $paymentLabels[$b['payment_method']??''] ?? $b['payment_method'] ?></span></td>
                        <td><?= getStatusBadge($b['status']) ?></td>
                        <td class="text-center">
                            <?php if (!empty($b['cancelled'])): ?>
                                <span class="badge" style="background:#7b1c1c;color:#fff;font-size:.75rem;"><i class="fa fa-ban me-1"></i>مُقالة</span>
                            <?php elseif ($b['status'] === 'confirmed'): ?>
                                <?php if (!empty($b['travelled'])): ?>
                                    <span class="badge" style="background:#0a4f3a;color:#fff;font-size:.75rem;"><i class="fa fa-check-double me-1"></i>تم</span>
                                <?php else: ?>
                                    <span class="badge bg-secondary" style="font-size:.75rem;">لا</span>
                                <?php endif; ?>
                            <?php else: ?>
                                <span class="text-muted">—</span>
                            <?php endif; ?>
                        </td>
                        <td><small class="text-muted"><?= isset($b['created_at']) ? date('d/m H:i', strtotime($b['created_at'])) : '—' ?></small></td>
                        <td>
                            <div class="d-flex gap-1">
                                <div style="display:flex;gap:3px;flex-wrap:nowrap;align-items:center;min-width:0;">
                                <a href="booking-detail.php?id=<?= $b['id'] ?>" class="action-btn view" title="تفاصيل"><i class="fa fa-eye"></i></a>
                                <?php if (!empty($b['payment_receipt'])): ?>
                                <a href="booking-detail.php?id=<?= $b['id'] ?>#receipt" class="action-btn" title="وصل الدفع" style="background:#e8f5f0;color:#1a7a58;border:1px solid #2db37e;"><i class="fa fa-receipt"></i></a>
                                <?php endif; ?>
                                <?php if (!empty($b['cancelled'])): ?>
                                <span class="action-btn" title="تمت الإقالة — لا يمكن الطباعة" style="background:#f8d7da;color:#7b1c1c;border:1px solid #f5c2c7;cursor:not-allowed;opacity:.7;"><i class="fa fa-ban"></i></span>
                                <?php elseif ($b['status'] === 'confirmed' && empty($b['travelled'])): ?>
                                <a href="booking-detail.php?id=<?= $b['id'] ?>" onclick="setTimeout(()=>window.print(),800);return true;" class="action-btn" title="طباعة التذكرة" style="background:#fff8e1;color:#b8860b;border:1px solid #f0c040;"><i class="fa fa-print"></i></a>
                                <?php elseif ($b['status'] === 'confirmed' && !empty($b['travelled'])): ?>
                                <span class="action-btn" title="تم السفر — لا يمكن الطباعة" style="background:#f8d7da;color:#842029;border:1px solid #f5c2c7;cursor:not-allowed;opacity:.6;"><i class="fa fa-ban"></i></span>
                                <?php endif; ?>
                                <?php if (!$isRep && in_array($b['status'],['pending','payment_pending'])): ?>
                                <a href="update-status.php?id=<?= $b['id'] ?>&status=confirmed&back=bookings" class="action-btn confirm" onclick="return confirm('تأكيد؟')" title="تأكيد"><i class="fa fa-check"></i></a>
                                <a href="update-status.php?id=<?= $b['id'] ?>&status=cancelled&back=bookings" class="action-btn cancel" onclick="return confirm('إلغاء؟')" title="إلغاء"><i class="fa fa-times"></i></a>
                                <?php endif; ?>
                                </div>
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; ?>
                    <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
