<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';
requireAdmin();

$id        = (int)($_GET['id'] ?? 0);
$booking   = null;
$message   = '';

$isRep        = isCompanyRep();
$repCompanyId = getSessionCompanyId();

// تحديث الحالة من هذه الصفحة — ممنوع على ممثل الشركة (عرض فقط)
if (!$isRep && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_status'])) {
    $newStatus = sanitize($_POST['new_status']);
    try {
        $db = getDB();
        $db->prepare("UPDATE bookings SET status=? WHERE id=?")->execute([$newStatus, $id]);
        $message = 'تم تحديث حالة الحجز بنجاح!';
    } catch (Exception $e) { $message = 'تم التحديث (وضع التجربة).'; }
}

// تعديل معلومات الحجز — للمدير فقط
if (!$isRep && $_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['edit_booking'])) {
    // حماية من الخادم: رفض أي تعديل إذا تم السفر أو تمت الإقالة
    try {
        $_chkDb   = getDB();
        $_chkStmt = $_chkDb->prepare("SELECT travelled, cancelled FROM bookings WHERE id=?");
        $_chkStmt->execute([$id]);
        $_chkRow  = $_chkStmt->fetch(PDO::FETCH_ASSOC);
        if ($_chkRow && (!empty($_chkRow['travelled']) || !empty($_chkRow['cancelled']))) {
            $message = 'لا يمكن تعديل هذا الحجز — تم السفر أو تمت الإقالة.';
            goto skip_edit;
        }
    } catch (Exception $e) {}
    $passengerName  = sanitize($_POST['passenger_name'] ?? '');
    $passengerPhone = sanitize($_POST['passenger_phone'] ?? '');
    $passengerId2   = sanitize($_POST['passenger_id'] ?? '');
    $seatCount2     = max(1, (int)($_POST['seat_count'] ?? 1));
    $travelDate2    = sanitize($_POST['travel_date'] ?? '');
    $paymentMethod2 = sanitize($_POST['payment_method'] ?? 'cash');
    $notes2         = sanitize($_POST['notes'] ?? '');
    $travelled2     = (($_POST['travelled'] ?? '0') === '1') ? 1 : 0;
    $cancelled2     = (($_POST['cancelled'] ?? '0') === '1') ? 1 : 0;
    // إذا تمت الإقالة نغير الحالة إلى ملغي تلقائياً
    if ($cancelled2) { $newStatus2 = 'cancelled'; $travelled2 = 0; }
    $newStatus2     = sanitize($_POST['status'] ?? 'pending');
    try {
        $db = getDB();
        $routeStmt = $db->prepare("SELECT price FROM routes WHERE id = (SELECT route_id FROM bookings WHERE id=?)");
        $routeStmt->execute([$id]);
        $routeRow = $routeStmt->fetch(PDO::FETCH_ASSOC);
        $unitPrice2  = $routeRow ? (float)$routeRow['price'] : 0;
        $totalPrice2 = $unitPrice2 * $seatCount2;
        $db->prepare("UPDATE bookings SET
            passenger_name=?, passenger_phone=?, passenger_id=?,
            seat_count=?, travel_date=?, payment_method=?,
            notes=?, status=?, total_price=?, travelled=?, cancelled=?
            WHERE id=?")
           ->execute([$passengerName, $passengerPhone, $passengerId2,
                      $seatCount2, $travelDate2, $paymentMethod2,
                      $notes2, $newStatus2, $totalPrice2, $travelled2, $cancelled2, $id]);
        $message = 'تم تحديث معلومات الحجز بنجاح!';
    } catch (Exception $e) { $message = 'تم التحديث (وضع التجربة).'; }
    skip_edit:
}

// جلب بيانات الحجز
try {
    $db   = getDB();
    // إضافة عمود صلاحية التذكرة إن لم يكن موجوداً
    try { $db->exec("ALTER TABLE bookings ADD COLUMN travelled TINYINT(1) NOT NULL DEFAULT 0"); } catch(Exception $e){}
    try { $db->exec("ALTER TABLE bookings ADD COLUMN cancelled TINYINT(1) NOT NULL DEFAULT 0"); } catch(Exception $e){}
    $stmt = $db->prepare("SELECT b.*, r.from_city, r.to_city, r.departure_time, r.arrival_time, r.company, r.company_id, r.bus_type, r.price as unit_price
                           FROM bookings b LEFT JOIN routes r ON b.route_id=r.id
                           WHERE b.id=?");
    $stmt->execute([$id]);
    $booking = $stmt->fetch(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    // Demo
    $booking = [
        'id'=>$id,'booking_ref'=>'MRT-A8F2C1D3','from_city'=>'نواكشوط','to_city'=>'نواذيبو',
        'departure_time'=>'06:00','arrival_time'=>'12:30','company'=>'النقل الوطني الموريتاني','company_id'=>null,'bus_type'=>'مكيف - فئة A',
        'passenger_name'=>'أحمد ولد محمد','passenger_phone'=>'22001234','passenger_id'=>'1234567890',
        'seat_count'=>2,'travel_date'=>date('Y-m-d',strtotime('+1 day')),
        'total_price'=>10000,'unit_price'=>5000,'payment_method'=>'bankily',
        'payment_receipt'=>'',
        'status'=>'payment_pending','notes'=>'','travelled'=>0,'cancelled'=>0,'created_at'=>date('Y-m-d H:i:s'),
    ];
}

// ممثل الشركة: لا يمكنه رؤية حجوزات شركات أخرى
if ($booking && $isRep && (int)($booking['company_id'] ?? 0) !== (int)$repCompanyId) {
    $booking = null;
}

if (!$booking) {
    echo '<div class="container py-5 text-center"><h4>الحجز غير موجود</h4><a href="bookings.php" class="btn btn-success mt-3">العودة للحجوزات</a></div>';
    exit;
}

$paymentLabels = ['cash'=>'نقداً','mobile'=>'هاتف / موبايل','card'=>'بطاقة بنكية','bankily'=>'بنكيلي','masrafi'=>'مصرفي'];
$paymentPending = ($booking['status'] === 'payment_pending') || !empty($booking['payment_receipt']);
$statusOptions = ['pending'=>'في الانتظار','payment_pending'=>'في انتظار تأكيد الدفع','confirmed'=>'مؤكد','cancelled'=>'ملغي','completed'=>'مكتمل'];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تفاصيل الحجز - لوحة التحكم</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { font-family:'Segoe UI',Tahoma,sans-serif; background:#f4f6f9; }
.sidebar { width:260px; height:100vh; overflow-y:auto; background:linear-gradient(180deg,var(--green-dark),#0d6644); position:fixed; top:0; right:0; z-index:100; }
.sidebar-logo { padding:1.5rem; border-bottom:1px solid rgba(255,255,255,.1); display:flex; align-items:center; gap:10px; }
.sidebar-logo .icon { font-size:1.6rem; color:var(--gold); }
.sidebar-logo span { color:#fff; font-weight:700; }
.nav-link { color:rgba(255,255,255,.75)!important; padding:.75rem 1.5rem!important; display:flex; align-items:center; gap:10px; transition:all .2s; }
.nav-link:hover,.nav-link.active { background:rgba(255,255,255,.12)!important; color:#fff!important; border-right:3px solid var(--gold); }
.nav-link i { width:20px; text-align:center; }
.nav-section { padding:.5rem 1.5rem; font-size:.7rem; color:rgba(255,255,255,.4); text-transform:uppercase; letter-spacing:1px; margin-top:1rem; }
.main-content { margin-right:260px; }
.topbar { background:#fff; padding:1rem 1.5rem; display:flex; align-items:center; gap:.75rem; box-shadow:0 2px 8px rgba(0,0,0,.08); position:sticky; top:0; z-index:50; min-width:0; }
.topbar > * { flex-shrink:0; }
.topbar .page-title { flex-shrink:1; min-width:0; }
.page-title { font-size:1.2rem; font-weight:700; color:var(--green-dark); margin:0; }
.detail-card { background:#fff; border-radius:14px; padding:1.8rem; box-shadow:0 2px 12px rgba(0,0,0,.07); margin-bottom:1.5rem; }
.detail-card h6 { display:flex; align-items:center; gap:0.5rem; }
.detail-row { display:flex; align-items:center; padding:.8rem 0; border-bottom:1px solid #f5f5f5; }
.detail-row:last-child { border-bottom:none; }
.detail-label { color:#888; font-size:.85rem; width:160px; flex-shrink:0; font-weight:600; }
.detail-value { font-weight:600; font-size:.95rem; color:#333; }

/* تحسينات التذكرة */
.ticket-box { 
    background:#fff; 
    color:#333; 
    border-radius:16px; 
    border:2px solid var(--green-mid); 
    overflow:hidden; 
    box-shadow:0 4px 16px rgba(0,0,0,.1);
    position:relative;
}
.ticket-header { 
    background:linear-gradient(135deg,var(--green-dark),var(--green-mid)); 
    color:#fff; 
    padding:1.8rem 1.5rem; 
}
.ticket-body { 
    padding:2rem 1.5rem; 
}
.ticket-ref { 
    font-size:1.8rem; 
    font-weight:800; 
    letter-spacing:2px; 
    color:var(--gold); 
    margin-bottom:0.5rem;
}
.ticket-company { 
    font-size:1rem; 
    font-weight:700; 
    letter-spacing:1px;
    margin-bottom:1rem;
    display:flex;
    align-items:center;
    justify-content:center;
    gap:8px;
}
.ticket-company i { font-size:1.2rem; color:var(--gold); }

.ticket-header-content {
    display:flex !important;
    justify-content:space-between !important;
    align-items:flex-start !important;
}

.ticket-ref-group {
    flex: 1;
}

.ticket-ref-label {
    font-size:0.75rem;
    color:rgba(255,255,255,.7);
    margin-top:0.25rem;
    text-align:right;
}

.ticket-status {
    text-align:left;
}

.passenger-section {
    background:#f8f9fa;
    padding:1.2rem;
    border-radius:10px;
    border-right:4px solid var(--green-mid);
    margin-bottom:1.5rem;
}

.passenger-label {
    font-size:0.75rem;
    color:#999;
    text-transform:uppercase;
    letter-spacing:0.5px;
    margin-bottom:0.5rem;
}

.passenger-name {
    font-weight:700;
    font-size:1.05rem;
    color:var(--green-dark);
    margin-bottom:0.8rem;
}

.passenger-details {
    display:flex;
    gap:1.5rem;
    font-size:0.9rem;
    color:#666;
}

.passenger-detail-item {
    flex:1;
}

.passenger-detail-label {
    color:#999;
    font-size:0.75rem;
    margin-bottom:0.25rem;
}

.passenger-detail-value {
    font-weight:600;
}

/* تحسينات قسم الرحلة */
.route-section { 
    display:flex; 
    align-items:center; 
    justify-content:space-between;
    padding:1.5rem 0;
    border-bottom:2px solid #f0f0f0;
    margin-bottom:1.5rem;
}
.city-box { 
    flex:1;
    text-align:center;
}
.city-time { 
    font-size:.85rem;
    color:#666;
    margin-top:0.25rem;
}
.city-name { 
    font-size:1.3rem; 
    font-weight:700; 
    color:var(--green-dark);
    margin-bottom:0.25rem;
}
.route-arrow { 
    font-size:2rem; 
    font-weight:800; 
    margin:0 1.5rem; 
    color:var(--green-mid);
    opacity:.7;
}

/* قسم البيانات الثانوية */
.ticket-info-row {
    display:flex;
    justify-content:space-around;
    gap:1rem;
    padding:1.5rem 0;
    text-align:center;
    border-top:1px solid #f0f0f0;
}
.ticket-info-item {
    flex:1;
}
.ticket-info-label {
    font-size:.75rem;
    color:#999;
    text-transform:uppercase;
    letter-spacing:0.5px;
    margin-bottom:0.5rem;
}
.ticket-info-value{
    font-size:1.1rem;
    font-weight:700;
    color:var(--green-dark);
}

/* تحسينات الأزرار */
.btn-spacing { 
    display:flex; 
    gap:1rem; 
    flex-wrap:wrap;
    margin-top:1.5rem;
    padding-top:1.5rem;
}
.btn-spacing .btn {
    flex:1;
    min-width:150px;
    padding:0.6rem 1.5rem;
    font-weight:600;
    border-radius:8px;
    transition:all 0.2s;
    white-space:normal;
    line-height:1.4;
}
.btn-spacing .btn:hover {
    transform:translateY(-2px);
    box-shadow:0 4px 12px rgba(0,0,0,.15);
}

/* تحسينات النموذج */
.form-section { 
    margin-bottom:1.5rem;
    padding-bottom:1.5rem;
    border-bottom:1px solid #f0f0f0;
}
.form-section:last-child { 
    margin-bottom:0;
    padding-bottom:0;
    border-bottom:none;
}
.form-section-title {
    font-size:.95rem;
    font-weight:700;
    color:var(--green-dark);
    margin-bottom:1rem;
    display:flex;
    align-items:center;
    gap:1rem;
}
.form-section-title i { 
    color:var(--green-light);
    font-size:1.1rem;
}

.form-label { 
    font-size:.85rem; 
    font-weight:600;
    color:#555;
    margin-bottom:0.4rem;
}

/* تحسينات الأغلفة */
.wrapper-buttons {
    display:flex;
    gap:1rem;
    margin-top:1.5rem;
    padding-top:1.5rem;
    border-top:1px solid #f0f0f0;
}
.wrapper-buttons .btn {
    flex:1;
    padding:0.7rem 1.5rem;
}

/* التطبع */
@page {
    size: A4;
    margin: 0 !important;
}

@media print {
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }

    body * { visibility: hidden !important; }

    .ticket-print, .ticket-print * { visibility: visible !important; }

    html, body {
        height: auto !important;
        overflow: visible !important;
        background: #fff !important;
        margin: 0 !important;
        padding: 0 !important;
    }

    .ticket-print {
        position: fixed !important;
        top: 1.5rem !important;
        right: 1.5rem !important;
        left: 1.5rem !important;
        width: auto !important;
        max-width: 100% !important;
        margin: 0 !important;
        padding: 1rem !important;
        background: #fff !important;
    }

    .ticket-box {
        background: #fff !important;
        border: 2px solid #1a7a58 !important;
        border-radius: 16px !important;
        page-break-inside: avoid !important;
        break-inside: avoid !important;
        box-shadow: 0 4px 16px rgba(0,0,0,.1) !important;
    }
    
    .ticket-header {
        background: linear-gradient(135deg, #0a4f3a, #2db37e) !important;
        color: #fff !important;
        padding: 1.5rem !important;
    }
    
    .ticket-body {
        padding: 2rem 1.5rem !important;
        background: #fff !important;
    }
    
    .ticket-ref { 
        color: #c8a227 !important;
        font-size: 1.8rem !important;
        font-weight: 800 !important;
        margin-bottom: 0.5rem !important;
    }
    
    .ticket-company { 
        font-size: 1.1rem !important;
        font-weight: 700 !important;
        margin-bottom: 1.5rem !important;
    }
    
    .route-section {
        padding: 1.5rem 0 !important;
        margin-bottom: 1.5rem !important;
    }
    
    .city-name { 
        color: #0a4f3a !important;
        font-size: 1.3rem !important;
        font-weight: 700 !important;
    }
    
    .city-time {
        color: #666 !important;
        font-size: 0.9rem !important;
    }
    
    .route-arrow { 
        color: #1a7a58 !important;
        font-size: 2rem !important;
    }
    
    .ticket-info-row {
        padding: 1.5rem 0 !important;
        border-top: 1px solid #f0f0f0 !important;
    }
    
    .ticket-info-item {
        text-align: center !important;
    }
    
    .ticket-info-label {
        color: #999 !important;
        font-size: 0.75rem !important;
        text-transform: uppercase !important;
    }
    
    .ticket-info-value{
        color: #0a4f3a !important;
        font-size: 1.1rem !important;
        font-weight: 700 !important;
    }

    .no-print,
    .sidebar,
    .topbar { display: none !important; visibility: hidden !important; }
}
.sidebar-toggle { display:none; background:none; border:none; font-size:1.3rem; color:var(--green-dark); cursor:pointer; padding:6px 10px; }
.sidebar-overlay { display:none; position:fixed; inset:0; background:rgba(0,0,0,.45); z-index:99; }
@media (max-width: 991px) {
    .sidebar { right:-280px; transition: right .25s ease; box-shadow:-4px 0 20px rgba(0,0,0,.25); }
    .sidebar.open { right:0; }
    .main-content { margin-right:0!important; }
    .sidebar-toggle { display:inline-flex; align-items:center; justify-content:center; }
    .sidebar-overlay.show { display:block; }
}
.quick-actions { margin-right:8px; padding-right:8px; border-right:1px solid #eee; }
.quick-action-btn { display:flex; align-items:center; gap:6px; padding:6px 12px; border-radius:8px; font-size:.82rem; font-weight:600; text-decoration:none; background:#f4f6f9; color:var(--green-dark); transition:all .15s; }
.quick-action-btn:hover { background:#e8f5f0; color:var(--green-dark); }
.quick-action-logout { background:#fef0f0; color:#e74c3c; }
.quick-action-logout:hover { background:#fde0e0; color:#c0392b; }
@media (max-width: 575px) { .quick-actions { margin-right:4px; padding-right:4px; } .quick-action-btn { padding:6px 9px; } }
@media (max-width: 480px) {
    .topbar { padding: .75rem 1rem; flex-wrap: nowrap; overflow: hidden; }
    .page-title { font-size: .95rem; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .p-4 { padding: 1rem !important; }
    .btn-spacing { gap:0.75rem; }
    .btn-spacing .btn { min-width:120px; padding:0.5rem 1rem; font-size:.9rem; }
}
</style>
</head>
<body>
<nav class="sidebar">
    <div class="sidebar-logo"><span class="icon"><i class="fa fa-bus"></i></span><span>نقل موريتانيا</span></div>
    <ul class="nav flex-column mt-2">
        <div class="nav-section">القائمة الرئيسية</div>
        <li><a class="nav-link" href="dashboard.php"><i class="fa fa-tachometer-alt"></i><span class="ms-2">لوحة التحكم</span></a></li>
        <li><a class="nav-link active" href="bookings.php"><i class="fa fa-ticket-alt"></i><span class="ms-2">الحجوزات</span></a></li>
        <?php if (!$isRep): ?>
        <li>
            <a class="nav-link" href="messages.php">
                <i class="fa fa-envelope-open-text"></i><span class="ms-2">رسائل اتصل بنا</span>
                <?php if (getUnreadMessagesCount() > 0): ?>
                <span class="badge bg-warning text-dark ms-auto"><?= getUnreadMessagesCount() ?></span>
                <?php endif; ?>
            </a>
        </li>
        <?php endif; ?>
        <div class="nav-section">الإدارة</div>
        <li><a class="nav-link" href="routes.php"><i class="fa fa-route"></i><span class="ms-2">إدارة الرحلات</span></a></li>
        <li><a class="nav-link" href="cities.php"><i class="fa fa-map-marker-alt"></i><span class="ms-2">المدن</span></a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="companies.php"><i class="fa fa-building"></i><span class="ms-2">الشركات</span></a></li><?php endif; ?>
        <li><a class="nav-link" href="reports.php"><i class="fa fa-chart-bar"></i><span class="ms-2">التقارير</span></a></li>
        <li><a class="nav-link" href="company-accounting.php"><i class="fa fa-file-invoice-dollar"></i><span class="ms-2">محاسبة الشركات</span></a></li>
        <?php if (!$isRep): ?><li><a class="nav-link" href="users.php"><i class="fa fa-users-cog"></i><span class="ms-2">المستخدمون</span></a></li><?php endif; ?>
        <div class="nav-section">النظام</div>
        <li><a class="nav-link" href="../index.php" target="_blank"><i class="fa fa-external-link-alt"></i><span class="ms-2">عرض الموقع</span></a></li>
        <li><a class="nav-link text-danger" href="logout.php"><i class="fa fa-sign-out-alt"></i><span class="ms-2">تسجيل الخروج</span></a></li>
    </ul>
</nav>
<div class="sidebar-overlay"></div>

<div class="main-content">
    <div class="topbar no-print">
        <button class="sidebar-toggle" type="button" aria-label="فتح القائمة"><i class="fa fa-bars"></i></button>
        <h5 class="page-title">
            <a href="bookings.php" class="text-decoration-none text-muted me-2"><i class="fa fa-arrow-right"></i></a>
            <i class="fa fa-ticket-alt me-2"></i> تفاصيل الحجز
        </h5>
        <div class="d-flex gap-2">
            <?php if (!empty($booking['cancelled'])): ?>
            <button class="btn btn-sm btn-danger rounded-3 fw-bold" disabled style="opacity:.8;cursor:not-allowed;">
                <i class="fa fa-ban me-2"></i> تمت الإقالة — لا يمكن الطباعة
            </button>
            <?php elseif ($booking['status'] === 'confirmed' && empty($booking['travelled'])): ?>
            <button onclick="printTicket()" class="btn btn-sm btn-success rounded-3 fw-bold">
                <i class="fa fa-print me-2"></i> طباعة التذكرة
            </button>
            <?php elseif ($booking['status'] === 'confirmed' && !empty($booking['travelled'])): ?>
            <button class="btn btn-sm btn-danger rounded-3 fw-bold" disabled style="opacity:.7;cursor:not-allowed;">
                <i class="fa fa-ban me-2"></i> تم السفر — لا يمكن الطباعة
            </button>
            <?php else: ?>
            <button class="btn btn-sm btn-outline-secondary rounded-3 fw-bold" disabled title="الطباعة متاحة للحجوزات المؤكدة فقط" style="opacity:.5;cursor:not-allowed;">
                <i class="fa fa-print me-2"></i> طباعة
            </button>
            <?php endif; ?>
            <a href="bookings.php" class="btn btn-sm btn-outline-success rounded-3">
                <i class="fa fa-list me-2"></i> كل الحجوزات
            </a>
        </div>
        <div class="ms-auto"><div class="quick-actions d-flex align-items-center gap-2">
            <a href="../index.php" target="_blank" class="quick-action-btn" title="عرض الموقع">
                <i class="fa fa-external-link-alt me-1"></i><span class="quick-action-label d-none d-md-inline">الموقع</span>
            </a>
            <a href="logout.php" class="quick-action-btn quick-action-logout" title="تسجيل الخروج" onclick="return confirm('تسجيل الخروج؟')">
                <i class="fa fa-sign-out-alt me-1"></i><span class="quick-action-label d-none d-md-inline">خروج</span>
            </a>
        </div></div>
    </div>

    <div class="p-4">
        <?php if ($message): ?>
        <div class="alert alert-success no-print"><i class="fa fa-check me-2"></i><?= $message ?></div>
        <?php endif; ?>

        <div class="row g-4">
            <!-- التذكرة -->
            <div class="col-lg-5 ticket-print">
                <div class="ticket-box">
                    <!-- رأسية التذكرة -->
                    <div class="ticket-header">
                        <div class="ticket-company">
                            <i class="fa fa-bus"></i>
                            <span><?= htmlspecialchars($booking['company'] ?? 'شركة النقل') ?></span>
                        </div>
                        
                        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem; padding-top:1rem; border-top:1px solid rgba(255,255,255,.2);">
                            <div style="text-align:right;">
                                <div style="font-size:0.75rem; color:rgba(255,255,255,.7); margin-bottom:0.3rem;">رقم الحجز</div>
                                <div class="ticket-ref"><?= htmlspecialchars($booking['booking_ref']) ?></div>
                            </div>
                            <div style="text-align:center;">
                                <div style="font-size:0.75rem; color:rgba(255,255,255,.7); margin-bottom:0.4rem;">حالة الحجز</div>
                                <?= getStatusBadge($booking['status']) ?>
                            </div>
                        </div>
                    </div>

                    <!-- بانر تمت الإقالة -->
                    <?php if (!empty($booking['cancelled'])): ?>
                    <div style="background:#7b1c1c;color:#fff;text-align:center;padding:1rem 1.2rem;border-bottom:3px solid #e74c3c;">
                        <div style="font-size:1.05rem;font-weight:700;letter-spacing:1px;margin-bottom:0.8rem;">
                            <i class="fa fa-ban me-2"></i> تمت إقالة التذكرة ولم تعد صالحة للاستعمال
                        </div>
                        <div style="background:rgba(255,255,255,0.12);border-radius:10px;padding:0.8rem 1rem;margin-top:0.5rem;">
                            <div style="font-size:0.95rem;font-weight:700;margin-bottom:0.6rem;color:#ffd6d6;">
                                <i class="fa fa-headset me-2"></i> يرجى التواصل مع الإدارة
                            </div>
                            <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:0.8rem;font-size:0.85rem;font-weight:600;">
                                <a href="tel:+22241010052" style="color:#fff;text-decoration:none;background:rgba(255,255,255,0.15);border-radius:6px;padding:0.3rem 0.7rem;">
                                    <i class="fa fa-phone me-1"></i> 22241010052
                                </a>
                                <a href="https://wa.me/+22241010052" target="_blank" style="color:#fff;text-decoration:none;background:#25d366;border-radius:6px;padding:0.3rem 0.7rem;">
                                    <i class="fab fa-whatsapp me-1"></i> واتساب
                                </a>
                                <a href="mailto:info@hajzmr.com" style="color:#fff;text-decoration:none;background:rgba(255,255,255,0.15);border-radius:6px;padding:0.3rem 0.7rem;">
                                    <i class="fa fa-envelope me-1"></i> info@hajzmr.com
                                </a>
                            </div>
                            <div style="font-size:0.78rem;color:rgba(255,255,255,0.7);margin-top:0.5rem;">
                                <i class="fa fa-map-marker-alt me-1"></i> شارع الاستقلال، نواكشوط &nbsp;|&nbsp; ساعات العمل: 8:00–18:00
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>

                    <!-- بانر تم السفر -->
                    <?php if (!empty($booking['travelled'])): ?>
                    <div style="background:#c0392b;color:#fff;text-align:center;padding:.8rem 1rem;font-size:1rem;font-weight:700;letter-spacing:1px;">
                        <i class="fa fa-check-double me-2"></i> تم السفر — هذه التذكرة لم تعد صالحة للاستخدام
                    </div>
                    <?php endif; ?>

                    <!-- جسم التذكرة -->
                    <div class="ticket-body">
                        <!-- قسم بيانات الراكب -->
                        <div class="passenger-section">
                            <div class="passenger-label">معلومات الراكب</div>
                            <div class="passenger-name">
                                <?= htmlspecialchars($booking['passenger_name']) ?>
                            </div>
                            <div class="passenger-details">
                                <div class="passenger-detail-item">
                                    <div class="passenger-detail-label">الهاتف</div>
                                    <div class="passenger-detail-value"><?= htmlspecialchars($booking['passenger_phone']) ?></div>
                                </div>
                                <?php if (!empty($booking['passenger_id'])): ?>
                                <div class="passenger-detail-item">
                                    <div class="passenger-detail-label">الهوية</div>
                                    <div class="passenger-detail-value"><?= htmlspecialchars($booking['passenger_id']) ?></div>
                                </div>
                                <?php else: ?>
                                <div class="passenger-detail-item">
                                    <div class="passenger-detail-label">نوع الحافلة</div>
                                    <div class="passenger-detail-value"><?= htmlspecialchars($booking['bus_type'] ?? '—') ?></div>
                                </div>
                                <?php endif; ?>
                            </div>
                        </div>

                        <!-- قسم الرحلة -->
                        <div class="route-section">
                            <div class="city-box">
                                <div class="city-name"><?= htmlspecialchars($booking['from_city']??'—') ?></div>
                                <div class="city-time"><?= $booking['departure_time']??'' ?></div>
                            </div>
                            <div class="route-arrow">
                                <i class="fa fa-arrow-left"></i>
                            </div>
                            <div class="city-box">
                                <div class="city-name"><?= htmlspecialchars($booking['to_city']??'—') ?></div>
                                <div class="city-time"><?= $booking['arrival_time']??'' ?></div>
                            </div>
                        </div>

                        <!-- البيانات الثانوية -->
                        <div class="ticket-info-row">
                            <div class="ticket-info-item">
                                <div class="ticket-info-label">تاريخ السفر</div>
                                <div class="ticket-info-value"><?= $booking['travel_date'] ? date('d/m/Y',strtotime($booking['travel_date'])) : '—' ?></div>
                            </div>
                            <div class="ticket-info-item">
                                <div class="ticket-info-label">عدد المقاعد</div>
                                <div class="ticket-info-value"><?= $booking['seat_count'] ?></div>
                            </div>
                            <div class="ticket-info-item">
                                <div class="ticket-info-label">الإجمالي</div>
                                <div class="ticket-info-value" style="color:var(--gold);"><?= number_format($booking['total_price']) ?> أوقية</div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- تحديث الحالة -->
                <?php if (!$isRep): ?>
                <div class="detail-card no-print" style="margin-top:1.5rem;">
                    <h6 class="fw-bold mb-3"><i class="fa fa-edit me-3 text-warning"></i><span>تحديث حالة الحجز</span></h6>
                    <form method="POST" class="d-flex gap-2">
                        <select name="new_status" class="form-select form-select-sm">
                            <?php foreach ($statusOptions as $val => $label): ?>
                            <option value="<?= $val ?>" <?= $booking['status']===$val?'selected':'' ?>><?= $label ?></option>
                            <?php endforeach; ?>
                        </select>
                        <button type="submit" class="btn btn-sm fw-bold px-4"
                                style="background:var(--green-mid);color:#fff;border:none;border-radius:8px;white-space:nowrap;">
                            <i class="fa fa-save me-1"></i> حفظ
                        </button>
                    </form>
                </div>
                <?php else: ?>
                <div class="detail-card no-print text-center text-muted" style="margin-top:1.5rem;">
                    <i class="fa fa-eye me-2"></i><span>عرض فقط — لا يمكنك تعديل حالة هذا الحجز</span>
                </div>
                <?php endif; ?>
            </div>

            <!-- التفاصيل -->
            <div class="col-lg-7">
                <!-- بيانات المسافر + نموذج التعديل -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark); font-size:1.05rem;">
                        <i class="fa fa-user-edit me-3 text-success"></i>
                        <?php if (!$isRep): ?>تعديل معلومات الحجز<?php else: ?>بيانات المسافر<?php endif; ?>
                    </h6>

                    <?php if (!$isRep): ?>
                    <?php $isFrozen = !empty($booking['travelled']) || !empty($booking['cancelled']); ?>
                    <?php if ($isFrozen): ?>
                    <!-- تنبيه التجميد -->
                    <div class="alert alert-danger d-flex align-items-center gap-2 mb-3 py-2" style="border-radius:10px;font-size:.9rem;">
                        <i class="fa fa-lock fa-lg"></i>
                        <span>
                            <?php if (!empty($booking['cancelled'])): ?>
                                تمت إقالة هذا الحجز — لا يمكن تعديل أي معلومات.
                            <?php else: ?>
                                تم تأكيد السفر — لا يمكن تعديل أي معلومات.
                            <?php endif; ?>
                        </span>
                    </div>
                    <?php endif; ?>

                    <form method="POST" id="editBookingForm">
                        <input type="hidden" name="edit_booking" value="1">

                        <!-- قسم بيانات المسافر -->
                        <div class="form-section">
                            <div class="form-section-title">
                                <i class="fa fa-id-card"></i> بيانات المسافر
                            </div>
                            <div class="row g-3">
                                <div class="col-12">
                                    <label class="form-label">الاسم الكامل <span class="text-danger">*</span></label>
                                    <input type="text" name="passenger_name" class="form-control form-control-sm"
                                           value="<?= htmlspecialchars($booking['passenger_name']) ?>"
                                           <?= $isFrozen ? 'readonly disabled' : 'required' ?>>
                                    <?php if ($isFrozen): ?><input type="hidden" name="passenger_name" value="<?= htmlspecialchars($booking['passenger_name']) ?>"><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">رقم الهاتف</label>
                                    <input type="text" name="passenger_phone" class="form-control form-control-sm"
                                           value="<?= htmlspecialchars($booking['passenger_phone']) ?>"
                                           <?= $isFrozen ? 'readonly disabled' : '' ?>>
                                    <?php if ($isFrozen): ?><input type="hidden" name="passenger_phone" value="<?= htmlspecialchars($booking['passenger_phone']) ?>"><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">رقم الهوية / الجواز</label>
                                    <input type="text" name="passenger_id" class="form-control form-control-sm"
                                           value="<?= htmlspecialchars($booking['passenger_id'] ?? '') ?>"
                                           <?= $isFrozen ? 'readonly disabled' : '' ?>>
                                    <?php if ($isFrozen): ?><input type="hidden" name="passenger_id" value="<?= htmlspecialchars($booking['passenger_id'] ?? '') ?>"><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- قسم بيانات الرحلة -->
                        <div class="form-section">
                            <div class="form-section-title">
                                <i class="fa fa-route"></i> بيانات الرحلة
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">تاريخ السفر <span class="text-danger">*</span></label>
                                    <input type="date" name="travel_date" class="form-control form-control-sm"
                                           value="<?= htmlspecialchars($booking['travel_date'] ?? '') ?>"
                                           <?= $isFrozen ? 'readonly disabled' : 'required' ?>>
                                    <?php if ($isFrozen): ?><input type="hidden" name="travel_date" value="<?= htmlspecialchars($booking['travel_date'] ?? '') ?>"><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">عدد المقاعد <span class="text-danger">*</span></label>
                                    <input type="number" name="seat_count" class="form-control form-control-sm"
                                           min="1" value="<?= (int)$booking['seat_count'] ?>"
                                           <?= $isFrozen ? 'readonly disabled' : 'required' ?>>
                                    <?php if ($isFrozen): ?><input type="hidden" name="seat_count" value="<?= (int)$booking['seat_count'] ?>"><?php endif; ?>
                                </div>
                            </div>
                        </div>

                        <!-- قسم الدفع والحالة -->
                        <div class="form-section">
                            <div class="form-section-title">
                                <i class="fa fa-coins"></i> الدفع والحالة
                            </div>
                            <div class="row g-3">
                                <div class="col-md-6">
                                    <label class="form-label">طريقة الدفع</label>
                                    <select name="payment_method" class="form-select form-select-sm" <?= $isFrozen ? 'disabled' : '' ?>>
                                        <option value="cash" <?= ($booking['payment_method']??'')=='cash' ?'selected':'' ?>>بنكيلي</option>
                                        <option value="mobile" <?= ($booking['payment_method']??'')=='mobile'?'selected':'' ?>>مصرفي</option>
                                    </select>
                                    <?php if ($isFrozen): ?><input type="hidden" name="payment_method" value="<?= htmlspecialchars($booking['payment_method'] ?? 'cash') ?>"><?php endif; ?>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label">حالة الحجز</label>
                                    <select name="status" class="form-select form-select-sm" <?= $isFrozen ? 'disabled' : '' ?>>
                                        <?php foreach ($statusOptions as $val => $label): ?>
                                        <option value="<?= $val ?>" <?= $booking['status']===$val?'selected':'' ?>><?= $label ?></option>
                                        <?php endforeach; ?>
                                    </select>
                                    <?php if ($isFrozen): ?><input type="hidden" name="status" value="<?= htmlspecialchars($booking['status'] ?? '') ?>"><?php endif; ?>
                                </div>
                                <div class="col-12">
                                    <label class="form-label">ملاحظات</label>
                                    <textarea name="notes" class="form-control form-control-sm" rows="3"
                                              <?= $isFrozen ? 'readonly disabled' : '' ?>><?= htmlspecialchars($booking['notes'] ?? '') ?></textarea>
                                    <?php if ($isFrozen): ?><input type="hidden" name="notes" value="<?= htmlspecialchars($booking['notes'] ?? '') ?>"><?php endif; ?>
                                </div>
                                <?php if (($booking['status'] ?? '') === 'confirmed' || !empty($booking['cancelled'])): ?>

                                <?php if (!empty($booking['cancelled'])): ?>
                                <!-- الإقالة مؤكدة: عرض فقط -->
                                <div class="col-12">
                                    <label class="form-label fw-bold" style="color:#dc3545;font-weight:700;">هل تمت الإقالة؟</label>
                                    <select class="form-select form-select-sm" disabled>
                                        <option selected>نعم — تم إلغاء التذكرة</option>
                                    </select>
                                    <input type="hidden" name="cancelled" value="1">
                                    <small class="text-danger mt-1 d-block"><i class="fa fa-lock me-1"></i>تمت الإقالة ولا يمكن التراجع عنها</small>
                                </div>

                                <?php elseif (!empty($booking['travelled'])): ?>
                                <!-- السفر مؤكد: عرض حقل الإقالة معطلاً وحقل السفر معطلاً -->
                                <div class="col-12">
                                    <label class="form-label fw-bold" style="color:#dc3545;font-weight:700;">هل تمت الإقالة؟</label>
                                    <select class="form-select form-select-sm" disabled>
                                        <option selected>لا</option>
                                    </select>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-bold" style="color:#dc3545;font-weight:700;">هل تم السفر؟</label>
                                    <select class="form-select form-select-sm" disabled>
                                        <option selected>نعم — (مؤكد، لا يمكن التعديل)</option>
                                    </select>
                                    <input type="hidden" name="travelled" value="1">
                                    <input type="hidden" name="cancelled" value="0">
                                    <small class="text-danger mt-1 d-block"><i class="fa fa-lock me-1"></i>تم تأكيد السفر ولا يمكن التراجع عنه</small>
                                </div>

                                <?php else: ?>
                                <!-- لم يتم شيء بعد: كلا الحقلين قابلَين للتعديل -->
                                <div class="col-12">
                                    <label class="form-label fw-bold" style="color:#dc3545;font-weight:700;">هل تمت الإقالة؟</label>
                                    <select name="cancelled" class="form-select form-select-sm">
                                        <option value="0" selected>لا</option>
                                        <option value="1">نعم — إلغاء التذكرة</option>
                                    </select>
                                    <small class="text-muted mt-1 d-block"><i class="fa fa-info-circle me-1"></i>اختيار "نعم" سيغير حالة الحجز إلى ملغي ولا يمكن التراجع</small>
                                </div>
                                <div class="col-12">
                                    <label class="form-label fw-bold" style="color:#dc3545;font-weight:700;">هل تم السفر؟</label>
                                    <select name="travelled" class="form-select form-select-sm">
                                        <option value="0" selected>لا</option>
                                        <option value="1">نعم</option>
                                    </select>
                                </div>
                                <?php endif; ?>

                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="wrapper-buttons">
                            <?php if ($isFrozen): ?>
                            <button type="button" class="btn btn-sm fw-bold" disabled
                                    style="background:#aaa;color:#fff;border:none;border-radius:8px;cursor:not-allowed;opacity:.6;">
                                <i class="fa fa-lock me-1"></i> التعديل مجمّد
                            </button>
                            <?php else: ?>
                            <button type="submit" class="btn btn-sm fw-bold" style="background:var(--green-mid);color:#fff;border:none;border-radius:8px;">
                                <i class="fa fa-save me-1"></i> حفظ التعديلات
                            </button>
                            <button type="reset" class="btn btn-sm btn-outline-secondary rounded-3">
                                <i class="fa fa-undo me-1"></i> إلغاء
                            </button>
                            <?php endif; ?>
                        </div>
                    </form>

                    <?php else: ?>
                    <div class="detail-row">
                        <span class="detail-label">الاسم الكامل</span>
                        <span class="detail-value"><?= htmlspecialchars($booking['passenger_name']) ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">رقم الهاتف</span>
                        <span class="detail-value">
                            <a href="tel:<?= htmlspecialchars($booking['passenger_phone']) ?>" class="text-decoration-none" style="color:var(--green-mid);">
                                <i class="fa fa-phone me-1"></i> <?= htmlspecialchars($booking['passenger_phone']) ?>
                            </a>
                        </span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">رقم الهوية</span>
                        <span class="detail-value"><?= htmlspecialchars($booking['passenger_id'] ?? '—') ?></span>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- بيانات الرحلة الثابتة -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark); font-size:1.05rem;">
                        <i class="fa fa-route me-3 text-success"></i> معلومات الرحلة
                    </h6>
                    <div class="detail-row">
                        <span class="detail-label">من</span>
                        <span class="detail-value"><?= htmlspecialchars($booking['from_city']??'—') ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">إلى</span>
                        <span class="detail-value"><?= htmlspecialchars($booking['to_city']??'—') ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">وقت المغادرة</span>
                        <span class="detail-value"><?= $booking['departure_time']??'—' ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">وقت الوصول</span>
                        <span class="detail-value"><?= $booking['arrival_time']??'—' ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">نوع الحافلة</span>
                        <span class="detail-value"><?= htmlspecialchars($booking['bus_type']??'—') ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">سعر الوحدة</span>
                        <span class="detail-value"><?= number_format($booking['unit_price']??0) ?> أوقية</span>
                    </div>
                </div>

                <!-- معلومات الدفع -->
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark); font-size:1.05rem;">
                        <i class="fa fa-credit-card me-3 text-success"></i> معلومات الدفع
                    </h6>
                    <div class="detail-row">
                        <span class="detail-label">طريقة الدفع</span>
                        <span class="detail-value"><?= $paymentLabels[$booking['payment_method']??'']??'—' ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">عدد المقاعد</span>
                        <span class="detail-value"><?= $booking['seat_count'] ?></span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">السعر الإجمالي</span>
                        <span class="detail-value" style="color:var(--gold); font-size:1.1rem;"><?= number_format($booking['total_price']) ?> أوقية</span>
                    </div>
                    <div class="detail-row">
                        <span class="detail-label">حالة الدفع</span>
                        <span class="detail-value">
                            <?php if ($booking['status']==='payment_pending'): ?>
                            <span class="badge bg-warning text-dark">⏳ بانتظار التحقق</span>
                            <?php elseif ($booking['status']==='confirmed'): ?>
                            <span class="badge bg-success">✓ مؤكد</span>
                            <?php else: ?>
                            <span class="badge bg-secondary"><?= $statusOptions[$booking['status']]??'—' ?></span>
                            <?php endif; ?>
                        </span>
                    </div>
                </div>

                <!-- وصل الدفع (إن وجد) -->
                <?php if ($paymentPending): ?>
                <div class="detail-card">
                    <h6 class="fw-bold mb-3" style="color:var(--green-dark); font-size:1.05rem;">
                        <i class="fa fa-image me-3 text-success"></i> وصل الدفع
                        <?php if ($booking['status'] === 'payment_pending'): ?>
                        <span class="badge bg-warning text-dark ms-2" style="font-size:.72rem;">⏳ بانتظار التحقق</span>
                        <?php endif; ?>
                    </h6>

                    <?php if (!empty($booking['payment_receipt'])): ?>
                    <?php
                        $protocol   = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
                        $receiptUrl = $protocol . '://hajzmr.com/' . htmlspecialchars($booking['payment_receipt']);
                        $receiptAlt = $protocol . '://hajzmr.com/' . htmlspecialchars($booking['payment_receipt']);
                    ?>
                    <style>
                    .receipt-img-wrap {
                        width: 100%;
                        overflow: hidden;
                        border-radius: 12px;
                        border: 2px solid #2db37e;
                        box-shadow: 0 2px 10px rgba(0,0,0,.12);
                        margin-bottom: .75rem;
                        background:#f8f9fa;
                        min-height: 120px;
                        display:flex;
                        align-items:center;
                        justify-content:center;
                    }
                    .receipt-img-wrap img {
                        display: block;
                        width: 100%;
                        max-width: 100%;
                        height: auto;
                        max-height: 70vh;
                        object-fit: contain;
                        cursor: pointer;
                    }
                    @media (max-width: 576px) {
                        .receipt-img-wrap img {
                            max-height: 55vh;
                        }
                    }
                    </style>
                    <div class="receipt-img-wrap" id="receiptWrap">
                        <img src="<?= $receiptUrl ?>"
                             id="receiptImg"
                             alt="وصل الدفع"
                             onclick="window.open(this.src,'_blank')"
                             onerror="document.getElementById('receiptWrap').style.display='none';document.getElementById('receiptError').style.display='block';">
                    </div>
                    <div id="receiptError" class="alert alert-warning text-center mb-3" style="display:none;">
                        ⚠️ تعذّر تحميل الصورة — <a href="<?= $receiptAlt ?>" target="_blank" class="fw-bold">اضغط هنا لفتحها مباشرة</a>
                    </div>
                    <div class="btn-spacing">
                        <a href="<?= $receiptUrl ?>" target="_blank" class="btn btn-sm btn-outline-success rounded-pill">
                            <i class="fa fa-expand me-2"></i>عرض بالحجم الكامل
                        </a>
                        <a href="<?= $receiptUrl ?>" download class="btn btn-sm btn-outline-secondary rounded-pill">
                            <i class="fa fa-download me-2"></i>تحميل الوصل
                        </a>
                    </div>

                    <?php if (!$isRep): ?>
                    <hr>
                    <div class="btn-spacing">
                        <form method="POST" style="display:inline; flex:1;">
                            <input type="hidden" name="new_status" value="confirmed">
                            <button type="submit" class="btn btn-sm btn-success fw-bold rounded-3 w-100"
                                    onclick="return confirm('قبول الدفع وتأكيد الحجز؟')">
                                <i class="fa fa-check-circle me-2"></i>قبول الدفع
                            </button>
                        </form>
                        <form method="POST" style="display:inline; flex:1;">
                            <input type="hidden" name="new_status" value="pending">
                            <button type="submit" class="btn btn-sm btn-outline-danger fw-bold rounded-3 w-100"
                                    onclick="return confirm('رفض الوصل وإعادة الحجز للانتظار؟')">
                                <i class="fa fa-times-circle me-2"></i>رفض الوصل
                            </button>
                        </form>
                    </div>
                    <?php endif; ?>

                    <?php else: ?>
                    <div class="text-center py-4 text-muted">
                        <i class="fa fa-clock fa-3x mb-3 d-block text-warning"></i>
                        <strong>لم يتم رفع وصل الدفع بعد</strong><br>
                        <small>طريقة الدفع: <strong><?= $paymentLabels[$booking['payment_method']??''] ?? '—' ?></strong></small>
                    </div>
                    <?php endif; ?>
                </div>
                <?php endif; ?>

            </div>
        </div>
    </div>
</div>
<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/js/bootstrap.bundle.min.js"></script>
<script>
function printTicket() {
    var ticketHtml = document.querySelector('.ticket-print').innerHTML;
    var win = window.open('', '_blank', 'width=900,height=700');
    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>طباعة التذكرة</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { 
    --green-dark:#0a4f3a; 
    --green-mid:#1a7a58; 
    --green-light:#2db37e; 
    --gold:#c8a227; 
}

@page { 
    size: A4;
    margin: 0 !important;
}

* {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
    color-adjust: exact !important;
}

html, body {
    width: 100% !important;
    height: auto !important;
    margin: 0 !important;
    padding: 0 !important;
    background: #fff !important;
    font-family: 'Segoe UI', Tahoma, sans-serif !important;
}

body {
    padding: 15mm 10mm !important;
    display: flex !important;
    justify-content: center !important;
    align-items: flex-start !important;
}

.ticket-print {
    width: 100% !important;
    max-width: 550px !important;
}

.ticket-box {
    background: #fff !important;
    color: #333 !important;
    border-radius: 16px !important;
    border: 2px solid var(--green-mid) !important;
    overflow: hidden !important;
    box-shadow: 0 4px 16px rgba(0,0,0,.1) !important;
    page-break-inside: avoid !important;
    break-inside: avoid !important;
}

.ticket-header {
    background: linear-gradient(135deg, var(--green-dark), var(--green-mid)) !important;
    color: #fff !important;
    padding: 1.5rem !important;
    text-align: center !important;
}

.ticket-company {
    font-size: 1.05rem !important;
    font-weight: 700 !important;
    margin-bottom: 1rem !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 8px !important;
    letter-spacing: 0.5px !important;
}

.ticket-company i {
    font-size: 1.1rem !important;
    color: var(--gold) !important;
}

.ticket-header-content {
    display: flex !important;
    justify-content: space-between !important;
    align-items: flex-start !important;
}

.ticket-ref-group {
    flex: 1 !important;
}

.ticket-ref {
    font-size: 1.7rem !important;
    font-weight: 800 !important;
    letter-spacing: 2px !important;
    color: var(--gold) !important;
    margin-bottom: 0.3rem !important;
    word-break: break-word !important;
}

.ticket-ref-label {
    font-size: 0.7rem !important;
    color: rgba(255,255,255,.8) !important;
    text-align: right !important;
}

.ticket-status {
    text-align: left !important;
}

.ticket-body {
    padding: 1.8rem 1.5rem !important;
    background: #fff !important;
}

.passenger-section {
    background: #f8f9fa !important;
    padding: 1rem 1.2rem !important;
    border-radius: 10px !important;
    border-right: 4px solid var(--green-mid) !important;
    margin-bottom: 1.3rem !important;
}

.passenger-label {
    font-size: 0.7rem !important;
    color: #999 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
    margin-bottom: 0.4rem !important;
}

.passenger-name {
    font-weight: 700 !important;
    font-size: 1.05rem !important;
    color: var(--green-dark) !important;
    margin-bottom: 0.7rem !important;
}

.passenger-details {
    display: flex !important;
    gap: 1.2rem !important;
    font-size: 0.85rem !important;
    color: #666 !important;
}

.passenger-detail-item {
    flex: 1 !important;
}

.passenger-detail-label {
    color: #999 !important;
    font-size: 0.7rem !important;
    margin-bottom: 0.2rem !important;
}

.passenger-detail-value {
    font-weight: 600 !important;
}

.route-section {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 1.3rem 0 !important;
    border-bottom: 2px solid #f0f0f0 !important;
    margin-bottom: 1.3rem !important;
}

.city-box {
    flex: 1 !important;
    text-align: center !important;
}

.city-name {
    font-size: 1.2rem !important;
    font-weight: 700 !important;
    color: var(--green-dark) !important;
    margin-bottom: 0.2rem !important;
}

.city-time {
    font-size: 0.8rem !important;
    color: #666 !important;
    margin-top: 0.2rem !important;
}

.route-arrow {
    font-size: 1.8rem !important;
    font-weight: 800 !important;
    margin: 0 1.2rem !important;
    color: var(--green-mid) !important;
    opacity: 0.7 !important;
}

.ticket-info-row {
    display: flex !important;
    justify-content: space-around !important;
    gap: 1rem !important;
    padding: 1.3rem 0 !important;
    text-align: center !important;
    border-top: 1px solid #f0f0f0 !important;
}

.ticket-info-item {
    flex: 1 !important;
}

.ticket-info-label {
    font-size: 0.7rem !important;
    color: #999 !important;
    text-transform: uppercase !important;
    letter-spacing: 0.5px !important;
    margin-bottom: 0.4rem !important;
}

.ticket-info-value {
    font-size: 1rem !important;
    font-weight: 700 !important;
    color: var(--green-dark) !important;
}

.ticket-info-value.price {
    color: var(--gold) !important;
}

.no-print, form, .detail-card {
    display: none !important;
    visibility: hidden !important;
}

</style>
</head>
<body>
<div class="ticket-print">${ticketHtml}</div>
<script>
    window.onload = function() {
        setTimeout(function() {
            window.print();
            window.onafterprint = function() {
                window.close();
            };
        }, 300);
    };
<\/script>
</body>
</html>`);
    win.document.close();
}
</script>

<script>
(function(){
    var sidebar = document.querySelector('.sidebar');
    var overlay = document.querySelector('.sidebar-overlay');
    var toggleBtns = document.querySelectorAll('.sidebar-toggle');
    function openSidebar(){ sidebar.classList.add('open'); overlay.classList.add('show'); }
    function closeSidebar(){ sidebar.classList.remove('open'); overlay.classList.remove('show'); }
    toggleBtns.forEach(function(btn){
        btn.addEventListener('click', function(){
            sidebar.classList.contains('open') ? closeSidebar() : openSidebar();
        });
    });
    overlay.addEventListener('click', closeSidebar);
    sidebar.querySelectorAll('.nav-link').forEach(function(link){
        link.addEventListener('click', closeSidebar);
    });
})();
</script>
</body>
</html>
