<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$booking = null;
$error   = '';
$ref     = sanitize($_GET['ref'] ?? '');

if ($ref) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT b.*, COALESCE(b.travelled,0) as travelled, COALESCE(b.cancelled,0) as cancelled, r.from_city, r.to_city, r.departure_time, r.arrival_time, r.company, r.bus_type
                              FROM bookings b LEFT JOIN routes r ON b.route_id = r.id
                              WHERE b.booking_ref = ?");
        $stmt->execute([$ref]);
        $booking = $stmt->fetch(PDO::FETCH_ASSOC);
        if (!$booking) $error = 'لم يتم العثور على حجز بهذا الرقم.';
    } catch (Exception $e) {
        // Demo data
        if ($ref === 'MRT-DEMO1234') {
            $booking = [
                'booking_ref'    => 'MRT-DEMO1234',
                'passenger_name' => 'محمد أحمد',
                'passenger_phone'=> '22 XX XX XX',
                'from_city'      => 'نواكشوط',
                'to_city'        => 'نواذيبو',
                'departure_time' => '06:00',
                'arrival_time'   => '12:30',
                'travel_date'    => '2025-08-15',
                'seat_count'     => 2,
                'total_price'    => 10000,
                'status'         => 'pending',
                'travelled'      => 0,
                'cancelled'      => 0,
                'payment_method' => 'bankily',
                'company'        => 'النقل الوطني',
                'bus_type'       => 'مكيف',
                'created_at'     => date('Y-m-d H:i:s'),
            ];
        } else {
            $error = 'لم يتم العثور على الحجز.';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>تتبع الحجز - نقل موريتانيا</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root { --green-dark:#0a4f3a; --green-mid:#1a7a58; --green-light:#2db37e; --gold:#c8a227; }
body { background: #f0f8f4; font-family: 'Segoe UI', Tahoma, sans-serif; }
.search-card { max-width: 560px; margin: 3rem auto; background: #fff; border-radius: 16px; padding: 2rem; box-shadow: 0 6px 24px rgba(0,80,50,0.12); }
.booking-result { max-width: 620px; margin: 2rem auto; }

/* ===== تصميم التذكرة ===== */
.ticket-box {
    background: #fff;
    color: #333;
    border-radius: 16px;
    border: 2px solid var(--green-mid);
    overflow: hidden;
    box-shadow: 0 4px 16px rgba(0,0,0,.1);
}
.ticket-header {
    background: linear-gradient(135deg, var(--green-dark), var(--green-mid));
    color: #fff;
    padding: 1.8rem 1.5rem;
}
.ticket-body {
    padding: 2rem 1.5rem;
}
.ticket-ref {
    font-size: 1.8rem;
    font-weight: 800;
    letter-spacing: 2px;
    color: var(--gold);
    margin-bottom: 0.5rem;
}
.ticket-company {
    font-size: 1rem;
    font-weight: 700;
    letter-spacing: 1px;
    margin-bottom: 1rem;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
}
.ticket-company i { font-size: 1.2rem; color: var(--gold); }

.passenger-section {
    background: #f8f9fa;
    padding: 1.2rem;
    border-radius: 10px;
    border-right: 4px solid var(--green-mid);
    margin-bottom: 1.5rem;
}
.passenger-label {
    font-size: 0.75rem;
    color: #999;
    text-transform: uppercase;
    letter-spacing: 0.5px;
    margin-bottom: 0.5rem;
}
.passenger-name {
    font-weight: 700;
    font-size: 1.05rem;
    color: var(--green-dark);
    margin-bottom: 0.8rem;
}
.passenger-details { display: flex; gap: 1.5rem; font-size: 0.9rem; color: #666; }
.passenger-detail-item { flex: 1; }
.passenger-detail-label { color: #999; font-size: 0.75rem; margin-bottom: 0.25rem; }
.passenger-detail-value { font-weight: 600; }

.route-section {
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding: 1.5rem 0;
    border-bottom: 2px solid #f0f0f0;
    margin-bottom: 1.5rem;
}
.city-box { flex: 1; text-align: center; }
.city-time { font-size: .85rem; color: #666; margin-top: 0.25rem; }
.city-name { font-size: 1.3rem; font-weight: 700; color: var(--green-dark); margin-bottom: 0.25rem; }
.route-arrow { font-size: 2rem; font-weight: 800; margin: 0 1.5rem; color: var(--green-mid); opacity: .7; }

.ticket-info-row {
    display: flex;
    justify-content: space-around;
    gap: 1rem;
    padding: 1.5rem 0;
    text-align: center;
    border-top: 1px solid #f0f0f0;
}
.ticket-info-item { flex: 1; }
.ticket-info-label { font-size: .75rem; color: #999; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 0.5rem; }
.ticket-info-value { font-size: 1.1rem; font-weight: 700; color: var(--green-dark); }

.upload-area-check {
    border: 2px dashed #2db37e; border-radius: 12px; padding: 1.5rem;
    text-align: center; cursor: pointer; background: #f8fffe; transition: all .2s;
}
.upload-area-check:hover { background: #e8f8f2; }

@media print {
    body * { visibility: hidden !important; }
    .ticket-print, .ticket-print * { visibility: visible !important; }
    .ticket-print {
        position: fixed !important;
        top: 0 !important;
        left: 0 !important;
        right: 0 !important;
        width: 100% !important;
        margin: 0 !important;
        padding: 1rem !important;
    }
    .no-print { display: none !important; visibility: hidden !important; }
    * {
        -webkit-print-color-adjust: exact !important;
        print-color-adjust: exact !important;
        color-adjust: exact !important;
    }
    .ticket-header {
        background: linear-gradient(135deg, #0a4f3a, #1a7a58) !important;
        color: #fff !important;
    }
    .ticket-ref { color: #c8a227 !important; }
    .city-name { color: #0a4f3a !important; }
    .ticket-info-value { color: #0a4f3a !important; }
    .passenger-name { color: #0a4f3a !important; }
}
@page {
    size: A4;
    margin: 5mm;
}
</style>
</head>
<body>
<div class="container">
  <div class="search-card">
    <div class="text-center mb-3">
      <i class="fa fa-search fa-2x text-success"></i>
      <h4 class="mt-2 fw-bold">تتبع حجزك</h4>
      <p class="text-muted small">أدخل رقم الحجز للتحقق من حالته</p>
    </div>
    <form method="GET">
      <div class="mb-3">
        <input type="text" name="ref" class="form-control form-control-lg text-center mb-2" 
               placeholder="MRT-XXXXXXXX" value="<?= htmlspecialchars($ref) ?>"
               style="border-radius:10px;font-weight:700;letter-spacing:2px;border:2px solid #2db37e;">
        <button type="submit" class="btn btn-success w-100 py-2" style="border-radius:10px;font-weight:700;font-size:1.1rem;">
          <i class="fa fa-search ms-2"></i>بحث
        </button>
      </div>
    </form>
    <p class="text-center text-muted small mt-2">
      مثال: <a href="?ref=MRT-DEMO1234" class="text-success">MRT-DEMO1234</a>
    </p>
    <div class="text-center mt-3">
      <a href="index.php" class="btn btn-outline-success rounded-pill px-4 fw-bold">
        <i class="fa fa-home me-2"></i>الصفحة الرئيسية
      </a>
    </div>
  </div>

  <?php if (isset($_GET['receipt'])): ?>
  <div class="alert <?= $_GET['receipt']==='uploaded' ? 'alert-success' : 'alert-danger' ?> text-center" style="max-width:620px;margin:1rem auto;">
    <?php if ($_GET['receipt']==='uploaded'): ?>
      <i class="fa fa-check-circle me-2"></i>تم رفع وصل الدفع بنجاح! سيتم مراجعته من قبل الإدارة.
    <?php else: ?>
      <i class="fa fa-times-circle me-2"></i>حدث خطأ في رفع الوصل. تأكد من أن الملف صورة وحجمه أقل من 5MB.
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <?php if ($error): ?>
  <div class="alert alert-danger text-center booking-result"><i class="fa fa-times-circle me-2"></i><?= $error ?></div>
  <?php endif; ?>

  <?php if ($booking): ?>
  <div class="booking-result ticket-print">
    <div class="ticket-box">
      <!-- رأسية التذكرة -->
      <div class="ticket-header">
        <div class="ticket-company">
          <i class="fa fa-bus"></i>
          <span><?= htmlspecialchars($booking['company'] ?? 'شركة النقل') ?></span>
        </div>
        <div style="display:flex; justify-content:space-between; align-items:center; margin-top:1rem; padding-top:1rem; border-top:1px solid rgba(255,255,255,.2);">
          <div style="text-align:right;">
            <div style="font-size:0.75rem; color:rgba(255,255,255,.7); margin-bottom:0.3rem;">رقم الحجز</div>
            <div class="ticket-ref"><?= htmlspecialchars($booking['booking_ref']) ?></div>
          </div>
          <div style="text-align:center;">
            <div style="font-size:0.75rem; color:rgba(255,255,255,.7); margin-bottom:0.4rem;">حالة الحجز</div>
            <?= getStatusBadge($booking['status']) ?>
          </div>
        </div>
      </div>

      <!-- بانر تمت الإقالة -->
      <?php if (!empty($booking['cancelled'])): ?>
      <div style="background:#7b1c1c;color:#fff;text-align:center;padding:1rem 1.2rem;border-bottom:3px solid #e74c3c;">
          <div style="font-size:1.05rem;font-weight:700;letter-spacing:1px;margin-bottom:0.8rem;">
              <i class="fa fa-ban me-2"></i> تمت إقالة التذكرة ولم تعد صالحة للاستعمال
          </div>
          <div style="background:rgba(255,255,255,0.12);border-radius:10px;padding:0.8rem 1rem;margin-top:0.5rem;">
              <div style="font-size:0.95rem;font-weight:700;margin-bottom:0.6rem;color:#ffd6d6;">
                  <i class="fa fa-headset me-2"></i> يرجى التواصل مع الإدارة
              </div>
              <div style="display:flex;flex-wrap:wrap;justify-content:center;gap:0.8rem;font-size:0.85rem;font-weight:600;">
                  <a href="tel:+22241010052" style="color:#fff;text-decoration:none;background:rgba(255,255,255,0.15);border-radius:6px;padding:0.3rem 0.7rem;">
                      <i class="fa fa-phone me-1"></i> 22241010052
                  </a>
                  <a href="https://wa.me/+22241010052" target="_blank" style="color:#fff;text-decoration:none;background:#25d366;border-radius:6px;padding:0.3rem 0.7rem;">
                      <i class="fab fa-whatsapp me-1"></i> واتساب
                  </a>
                  <a href="mailto:info@hajzmr.com" style="color:#fff;text-decoration:none;background:rgba(255,255,255,0.15);border-radius:6px;padding:0.3rem 0.7rem;">
                      <i class="fa fa-envelope me-1"></i> info@hajzmr.com
                  </a>
              </div>
              <div style="font-size:0.78rem;color:rgba(255,255,255,0.7);margin-top:0.5rem;">
                  <i class="fa fa-map-marker-alt me-1"></i> شارع الاستقلال، نواكشوط &nbsp;|&nbsp; ساعات العمل: 8:00–18:00
              </div>
          </div>
      </div>
      <?php endif; ?>

      <!-- بانر تم السفر -->
      <?php if (!empty($booking['travelled'])): ?>
      <div style="background:#c0392b;color:#fff;text-align:center;padding:.8rem 1rem;font-size:1rem;font-weight:700;letter-spacing:1px;">
          <i class="fa fa-check-double me-2"></i> تم السفر — هذه التذكرة غير صالحة للاستخدام
      </div>
      <?php endif; ?>

      <!-- جسم التذكرة -->
      <div class="ticket-body">
        <!-- قسم بيانات الراكب -->
        <div class="passenger-section">
          <div class="passenger-label">معلومات الراكب</div>
          <div class="passenger-name"><?= htmlspecialchars($booking['passenger_name']) ?></div>
          <div class="passenger-details">
            <div class="passenger-detail-item">
              <div class="passenger-detail-label">الهاتف</div>
              <div class="passenger-detail-value"><?= htmlspecialchars($booking['passenger_phone']) ?></div>
            </div>
            <?php if (!empty($booking['passenger_id'])): ?>
            <div class="passenger-detail-item">
              <div class="passenger-detail-label">الهوية</div>
              <div class="passenger-detail-value"><?= htmlspecialchars($booking['passenger_id']) ?></div>
            </div>
            <?php else: ?>
            <div class="passenger-detail-item">
              <div class="passenger-detail-label">نوع الحافلة</div>
              <div class="passenger-detail-value"><?= htmlspecialchars($booking['bus_type'] ?? '—') ?></div>
            </div>
            <?php endif; ?>
          </div>
        </div>

        <!-- قسم الرحلة -->
        <div class="route-section">
          <div class="city-box">
            <div class="city-name"><?= htmlspecialchars($booking['from_city'] ?? '—') ?></div>
            <div class="city-time"><?= htmlspecialchars($booking['departure_time'] ?? '') ?></div>
          </div>
          <div class="route-arrow"><i class="fa fa-arrow-left"></i></div>
          <div class="city-box">
            <div class="city-name"><?= htmlspecialchars($booking['to_city'] ?? '—') ?></div>
            <?php if (!empty($booking['arrival_time'])): ?>
            <div class="city-time"><?= htmlspecialchars($booking['arrival_time']) ?></div>
            <?php endif; ?>
          </div>
        </div>

        <!-- البيانات الثانوية -->
        <div class="ticket-info-row">
          <div class="ticket-info-item">
            <div class="ticket-info-label">تاريخ السفر</div>
            <div class="ticket-info-value"><?= $booking['travel_date'] ? date('d/m/Y', strtotime($booking['travel_date'])) : '—' ?></div>
          </div>
          <div class="ticket-info-item">
            <div class="ticket-info-label">عدد المقاعد</div>
            <div class="ticket-info-value"><?= $booking['seat_count'] ?></div>
          </div>
          <div class="ticket-info-item">
            <div class="ticket-info-label">الإجمالي</div>
            <div class="ticket-info-value" style="color:var(--gold);"><?= number_format($booking['total_price'], 0) ?> أوقية</div>
          </div>
        </div>
      </div>
    </div>
    <!-- Payment completion section for pending bookings -->
    <?php if ($booking && in_array($booking['status'], ['pending']) && in_array($booking['payment_method'] ?? '', ['bankily','masrafi'])): ?>
    <?php
        $pmConfig = [
            'bankily' => ['name'=>'بنكيلي — Bankily', 'icon'=>'data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAgAAAAIACAYAAAD0eNT6AAAAGXRFWHRTb2Z0d2FyZQBBZG9iZSBJbWFnZVJlYWR5ccllPAAAAyNpVFh0WE1MOmNvbS5hZG9iZS54bXAAAAAAADw/eHBhY2tldCBiZWdpbj0i77u/IiBpZD0iVzVNME1wQ2VoaUh6cmVTek5UY3prYzlkIj8+IDx4OnhtcG1ldGEgeG1sbnM6eD0iYWRvYmU6bnM6bWV0YS8iIHg6eG1wdGs9IkFkb2JlIFhNUCBDb3JlIDUuNi1jMTQwIDc5LjE2MDQ1MSwgMjAxNy8wNS8wNi0wMTowODoyMSAgICAgICAgIj4gPHJkZjpSREYgeG1sbnM6cmRmPSJodHRwOi8vd3d3LnczLm9yZy8xOTk5LzAyLzIyLXJkZi1zeW50YXgtbnMjIj4gPHJkZjpEZXNjcmlwdGlvbiByZGY6YWJvdXQ9IiIgeG1sbnM6eG1wPSJodHRwOi8vbnMuYWRvYmUuY29tL3hhcC8xLjAvIiB4bWxuczp4bXBNTT0iaHR0cDovL25zLmFkb2JlLmNvbS94YXAvMS4wL21tLyIgeG1sbnM6c3RSZWY9Imh0dHA6Ly9ucy5hZG9iZS5jb20veGFwLzEuMC9zVHlwZS9SZXNvdXJjZVJlZiMiIHhtcDpDcmVhdG9yVG9vbD0iQWRvYmUgUGhvdG9zaG9wIENDIChNYWNpbnRvc2gpIiB4bXBNTTpJbnN0YW5jZUlEPSJ4bXAuaWlkOjlGQzA2QUY5NUU5MDExRTk4ODc0RTYwQzYxNzQ5QUNEIiB4bXBNTTpEb2N1bWVudElEPSJ4bXAuZGlkOjlGQzA2QUZBNUU5MDExRTk4ODc0RTYwQzYxNzQ5QUNEIj4gPHhtcE1NOkRlcml2ZWRGcm9tIHN0UmVmOmluc3RhbmNlSUQ9InhtcC5paWQ6OUZDMDZBRjc1RTkwMTFFOTg4NzRFNjBDNjE3NDlBQ0QiIHN0UmVmOmRvY3VtZW50SUQ9InhtcC5kaWQ6OUZDMDZBRjg1RTkwMTFFOTg4NzRFNjBDNjE3NDlBQ0QiLz4gPC9yZGY6RGVzY3JpcHRpb24+IDwvcmRmOlJERj4gPC94OnhtcG1ldGE+IDw/eHBhY2tldCBlbmQ9InIiPz55aS0KAACc9klEQVR42uydB5wTxRfHJ7kGR+9NutIsIAqifxUQe68oVuyeiti7HmdvSPfEigVFbCg2bDS7giIKiHSV3rl+l+T/ftkJLGE3yWZz/ff9fOaS2+zO7s6W9+bNe288gUBAEUIIIaR64WUTEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCKECwCYghBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCHVEg+bIAJZ2XvJ3/f1fxOlTFKZGWvZMIQQQqgAVF3hf7j8fUdKM9NSv5QvpTwvZYooAyVsKEIIIVQAqo7wv0b+jpaSEmGt1VLGS3mOVgFCCCFUACq34E+Vv2OlXOlgq2Ipr0l5VBSBJWxEQgghVAAql/BvLn/flXJYnDX4lDFk8IAoAgvYoIQQQqgAVHzhf4j8fU9KywTUFlCGw+C9ogisZOMSQgihAlAxhf9g+fuslDSbNf6WcpGUPlIypHSOseYCZQwnPCyKwFbeaoQQQqgAVAzBnyx/R0i5PsJan0i5YKcAz8pGex0r5TYpA2Lc0yYpd0h5SeoJ8JYjhBBCBaD8hH8T+TtZSr8Iaz0q5T4R2j6bOg6Wv3dJOTPGvX4r5Rqp7w/edoQQQqgAlL3w7yF/P5DSxmaNPCmDRVC/HWN9B8rfTCmnxbA28gY8ga2k/iLefoQQQqgAlI3wP1/+viClps0ay6WcLsL59zjqhiPhcCn/i2HteVIujms/hBBCCBWAmIVzkjJM+rdFWOtrKQNFKG9yua+zdC+/Q5Q1i7Tl4EnbYQZCCCGECkDcArmhQg5/pY6JsNbTUm5PmCDOyq4RrM/wEagRZW2kFoaj4XrejoQQQqgAJEYQ76eQs1+pjjZrIFTvKhG+r5XS/tvL32wpx0VZc42Uc+U4Zle0Jjz8/e+QDrmvlBOlvPjNGYf9yceGEEKoAFRk4Q/v/Fel1LJZ4x8pZ4jQnVMGx3KxMkIOG0ZYC9aHO+V4nqoAQr+efByvDMdGCP56+qftaDNRAr7mo0MIIVQAKprg9+KvQiY+e2YpY7x/XazV1n3sxYYpXi+GCl7ddPulX8dxXE2VMYvgqVHWfEVbJco0SkCEfmt9bBD6/ZT9REiY++ASUQLe5ONDCCFUACqK8K+rjDS8J0dYCyb5oSJgi2OttsPoift7PR6EDrYPdtX9/o+K/f6b/r3p4iVxHONl8neUlNoR1kLOgDNL2y9AhH4PLfBRDnSwKaZFvkKUgJf5CBFCCBWA8hb+XZQx3m+Xqhc96mtFqL7opNp2o14/PdnrxVBCHfPyQCBQ6AsERogi8MB/N12c7/BY4ZOAHnQvi19R10xlZA58O5FNZBrPD/X028SwGYZKPpeCEMrw8MlrRQnI5mNECCFUAMpL+KPH/7raNVYdzlrdo/7eSbXtR71+T5LX+4B89dqtI4rAyhJ/4LqVN174scNjxtTDjwatEUrNlfKFMiICvpPjLEyg0Lcbz4/Eb8pIlvSBCPhfdT1HycdHFkrAYFnnFT5KhBBCBaAsBT+O/x6FKXjtz+VHZTj7rYm12r3HTEzzB9QEr8dzXqzblPj9kwpKfDesveWSDQ7PIV2OLS/BPf1Yx/N3Hr6UGVrofygCfZVNvVZKAIYD4Bj4IR8nQgihAlAWwh9j6BOknBVhrZeUYfaPuUfdesRrLVOTvB94PB7k+lcpSV6V5PEoEe5Rtw0EAhuLfP7r/7nporfKujniGM+HRz8mO4Lg/kQE+LYY93O83sasVCCccoDU8R0fKUIIoQJQmsK/gxZC+0bo0d4ogn+ck2rbjXr9kGSv9z352hL/d2/WSJ20T1v16DdzlZNp/PyBwIRlW7ZfLvv3l6LAj2c8f5VuN5QZIrCL49z3OcpIrmQeGoHDYm+pcyUfK0IIoQJQGsL/WC18GtisAUGEEL+ZTqrtMHriBV6PB2F6QfN2l0b11cQzB6hTJn2qVu+IaqEXmR/4Q5SEr33+wOe+gH/Gv04dA2MTvBi/P1EL/RNUbOP5GMMPjef/lsBjuVkZcx+YQf2Hy35y+WgRQkjFJrmSCf9blJFn384pD850GO9f5aBOT4cGdR8V4X+HefGD/XupH/5dt1P4Yyig2OdXdVJTVIHPF/wuQv9nEfqjCkp801bffPHGUurpt1G7j+dHu2bo1c9Qu8bz/3G5/ySpY4/xD1n2tPyGaIZrTYsxDAGry2A+WoQQQgUgEYI/XRmz+A2KsBbi/68U4R9zz7vZUxNq1UpNeVOE/ynm5e3r11E9mjdWT30/b1dDeTzqsWMOVXvVra3OffcLw3zi8XQRJeD3RAt/EawHql3j+T1i2ATj959oof9ZrOP5dlz45a/N/QF1jpzy6Ukez0Gdps8b8FL/7lYZE2+Q0lVKf9OyS+T4v5RjeJ2PFyGEVFwq/hBAVnZb+Ytx+Z42a2CcHRP5DHdSbZuRr3VI8Xo/FCG+hx/BmV3aq8eP7hNUAMbPWRBc1rBmmnrzzKNVW1EOxv+yQI3+eb7y+YOeAcvzi0t6/XfzxXHPIqjH8/tpgY/efusYNlsV6uVLmRnveH6I87/4tZ1HBc7zeLzY/yEi/M1WlpVyoxz46oAeWyyOvYl8/KJ290HAEEAPOaYlfMQIIYQKQDzCH0IRyXAa26wBgXSOCP+vnFTbbtTrfZO93nfs6r1g/33UsL4Hq4/+XqlummY4ttdOTVGpSV51Xa/91IOzdu8M+wOBWcu2bD/KyWyCYeP5+Kwbw2YJHc8/9/O53bweNSgZFhCPp3vElQPq8+U78o6X/QYszqW3MrIXmi1KM6QcZbU+IYSQ8qfiDgFkZQ9RxjS9dsc4X8rpInSXOam2w+iJ13g9ntEqQmz8iq07gp/HdNhLtapTS/23I1flFBkd7OGmYYEQUt+R7evXeWa5UldHEfrlOp4PBn0xt7dHec5N8qiTReh3sr0xRDPoUDddrcktVDuKS6AqHts8PS1TfhoWvq4c109ybsjH8LhpMc4vQ8ozfMwIIYQWgFgEf5oy8vVfGmEt9N4Hi/DPdVBvUocGdUeJsL4uqlbk9aoZl5yqmtWqqeav36wu/3CG2lKwZyqBg1s2CToDzltnWP99fv8Ny4deOMZC8F+jDOWgzMfz7/vxr6Sl2/OO9HjUQLnYJ3k8nqjDC/1bNVIntG6i3liyWv22cbvZ0uHbXFDc/9OTe8+2OEfcS3COGGBaDE1qHzmHdXzUCCGECkAkId1KGeP9vW3WwHj/fQopdDMzYjYttxn5WoMUr/cdEX5HxbrNgPat1DMnHoHevdqYV6BemfeX+vG/9cGEQHASPGHvNsoXCKgbp31r3qxEhOQJy2644Msw4XiQfEBo1rTZHRLpPKeM8fxZbsfzL/ryt1S/CiBc8hzpyJ8gl7lJrNseJ4J/0N4t1ANzlqhl2/cMfyws8a1anVe4nxzjDhsLxx9q93kTXpJ1L+ejRgghVADshP+hWvg3j9AzvlAE/0dOqm078vWuyV7PVBH+HZ0e0umd26kH+vVSNVP2tNS/vWCpypz5S9ACEMbmDbn5B2+78/LlYcIRpv/3lX0I40ARlHFP/nPZ1/PS833+k5M86my5qMcpj6eu0zoa1khRT/Xpqn5cv1WNX2BEUtZLTVbbikp2W29rYfHEqSf2utCqDjnPK7UyEwKKWi85tzl83AghhApAuPC/Sv6OVfbj8osUxs0zMxY7qbbD6IknSg/+DRVbwhxLGqfXUKeJItC5UX2V4vWqFdt2qGlL/1GLNm7dY91AIKDW5ebDXwDOeoeH5/gX4YiwuVE2u8qRcpAIypjPceDnc+olezxniXJzRpLHMyBgb2GIsfffWF2wTyv1rAj/79YaDv9H79VY7V03XX24cr1anVtgmGH8AbW+oOjcL045ZLKFAoB7aoaUI02Lp8l5Hc/HjRBCqACEBD9mxBupDGcxO6bqnv92J1W3H/X6bUleL2bbSyqLU/GL8F+bk6fyinf2lt+UYz7fQkAi2+AVNtXAfI50ura5DC788tdmIn8Hej3qNBH8R6roE/3EzDkdW6hT2jZV2X+uVN+v26rSk5PU+fu0VAc1rqce/XWpWpWz67Dyin2b1+UXdpJj3WRxjvspIyugue0PlXV/4CNHCCEVA285Cv9m8verKML/Ad3zj1n4Yya/jqMnviLC/4myEv4+v1/9tz3XLPzBIDnHmy1WhxOi3aQ5EJwj7PbTd8r3fUVnW53k9YwW4T8gkcIfbMgvMg6ioTGEn1fiUx9Lz/+en/9Sa/N3d4JMT0lqWDc1eaRVPSLoociEO0M+yMeNEEKquwUgK7uXMsb797JZA+bwi0Xwv++w19/M6/FMEeHYp6xOBT4Aq3fkqmK/5bw/0Aj6y3l8E9ZDhvKDMfFWNtWeKULU8twv/uq39wMIfywF6qQkqxGHdQ2GAD752zL155aciOuXyDmvzi3sP/P0Q2dYWAHqywdCNM1zNvSU8/qVjx0hhFRHC0BW9kXK8Ii3E/5LpfRxKvzbjnz9QBH+v5Sl8C+UHvK/23PshD+A9+Bbcs5Nw3rICIvDjHp23v4vigC1bB8RzoPloi0vjfNBvP+ri/8LRj7c0r2DOrtDC9UiPU3Jv0FnwMY1UsOOxasapqU8L8eaZmEFgJPEw2GLh/KRI4SQ6mYByMqGMHwqihD4TMr5Ivy3OOz5DxSh9bII//SyOh2Y+zHmj7H/GEB8/PHh0wOL4LxR2Zv8sc1xVpn0rpw+78hCf+DrQCkNcXRrUFud0b656lSvVlD4bywoUjNWb1afrdqgisKVHTn/FTvy75p9xmGPWVgBoBj8rXalNsYYQ2s5p/V89AghpDooAFnZjeQvPMYjxeE/KeUuJ+l09Ux+w0T431eWysyOwiK1PjdfOcxxe6ec2+MWQhJJjc6y2eZ6EZbjrH649Ot5w0sCgZtL8zyTRPoj/XF+ifUlwRAA/AQ2FxRvk7boaOMQiIyOo02LbpX1hvPRI4SQ8qX0hwCyspFjfk4E4Q/X8kEiHG93IvxbPv1Kugj/d0T431+Wwn9rQWEw1C+OBPcPad+HcJAkZ6XNNk+IAN3H6ocGaSl3i4BeUJrnikRH4cK/yOdXW0QB+i+nQP0jZVNBMdoCYZb32FSDWRzXmv6/mI8dIYRUdQtAVva58vclKXameQg+5PN3NLFNx9ETW3s8HoQHdi/LxtqYly8KQJGbKuDf0EPONyesl3yYfMxS1iZ9LO9nNRRw2fR5RxT7AjOUpxQVOVEC8kqMnj6Kz37IA/4MneU4l1tYAe6QD/MQwYGJmMyIEEJIRbMAZGUnScELf1IE4T9DykFOhX+bka/9TxnTz5aZ8A8m+MnJcyv8g7qLMvwgdkOEIcIC7cLkEOtvOcnQS/27z/Z41IREny/8GnKKS9T6vEK1Iidfrcs3JgTyRfZ3QEjiAza/ITOgOSnS2Xz0CCGkqikAWdkI+0K63jsirIVseMeI8N/kpOoOoydempqU9JX0/puWpfBfI8J/R1Fxoqq8WtroBIvl8Jj/0WabJ+yiAoRbPUptcC30/X6VU1Si1uYVqFU78oM5AXKlxx9wNtYxSI6zvYWCA6fOV0yLTuWjRwghVUkByMrupoWYXdpXZJPBLH43SilxUK9XhP8Ir8eD4YS0smocJPj5d88EP4ngBTmn+mFCsiTYNkYbhYPMPKOtKnp1QI8tJf7AA/EJ/YDaLorNmlwR+jkFakNBkcov8cfj3xACQxi32fyWbfq+vygK7fj4EUJIVVAAsrJP18J/nwhrnSGC/5U4aq/jjWEa20SCBD8Q/oU+X2lU31JZDwVgzoM77dpOhOaJVj90rJueHQgEYnIIhNDfVlgczOu/Mic/6MRX4HMl9MO5VI6zqcW5zZePn02LODcAIYRUagUgK9sjZZgyZrqrHWXtibLuNejRO9pHZsa2JUPOPzvZ6zneY8SVlypI8POffXa/RHG5tMPRFsvR07fLmT9GhOseE/48eEhnny8QuNVe6PvVjqIS3dPPV5tFASj0ldq51ZByo81vz5u+9+PjRwghlVUByMqGafoDiOgYt4B/AEzBP8m2hzjd3aLrBk3r2KDu/qIIPOqxz6LnivzikqDwLyld4R/iOWmHmmE9ZewYU+pajTt0UDYm9jeP6fmpdOO/D/0P34XcYj2mn1MQTOaT4J5+JK4URSXVYjlyHhRRASCEkMqsABiCa4aUU+LY+iAp30sdz0tp6GTDzy48uVAUgbtrJCcd6vWohIaS5RQVB/P6+wOBsmp/OMzdG75QT6bzqM02d9o5BCZ51D1w5IP3Psz76/Ndj+nHS2NlMV+Bdgb8XP/bzMphkBBCSEVXADIzkMDnDGUkeolnoBw5CDAt7kJRAs5zuvH8jHPntKhdq1eSx/OQx7q37IhtBYXB1L7lICxvk/PvarH8EWVMphMOFK/HrSqaMKDH9A0FRdPi8N4vDa62WT4pTBEkhBBSqRQAQwlYJQXm6i4Kk96ouOQnHMbeFCH4sZQ2TjacOfi0kr+uH3Sf7PSIQCCwNN7T2JxfoDbkFZTXNUD8/DiL3jIO6Aabbc6X3nNvm98eriD3Vn85xg4Wyz9WuxS2A/kIEkJIZVQAdikCS6SgF99TGTkA4gEe7gtECRjq1ElwyZDzf8gpKu4uSsCrTneKnP6b8wvLXVjKOZ9toQRAWE612eYJq4WyDWZa/KYC3Fuw8FxmcXxbTcfXnY8gIYRUZgVglyLwmxT4BByudg/5ipVaUkZK+UoEoqPx4XW3Ds5desMFl/gDgctEEciLtn4wwc+OXLW9sKiiXIunwh0CNZg90eog+0oP+yTbuioGdhn/QkpNZz6ChBBSFRSAXYrAt/IXXv6XSFkTRw39pMwXgXh1MMzQActuuODlIp//EBHwi+3WgZMfPP1z3SX4yZXyqRTMRAhfiB5Smisj0gGllZTTlJEDf7pePxJtpdxi0WNGbv3RNts8KkqA10bALq8A91dnOb79LZZ/pT/bye9JfAwJIaTsKf1Z9LKykRvgLimYurZGHDV8oWBKzsz418lGe495o66c3BsBpXbrJSO8D57+RfHFwcPZEfkOJkj5Uo6p0EE7QNDtK+VQrRzhs0vYWpgkqKPUu968UIQksgYukdLIouZBoiRMCl8o29wkH09XgHvsQTm++8OODfcdzhHRAh2sJhAihBBS2RWAXQKwnTK81wfGsfVmhYiBzIz3He7T06lRvYf8gaAC4iny+UT458UT44+cA4h2eFSO4Z8Etkl9rQz00QXfJ8k+rrUQ6KcpI2pif20tCLFQyn46f0C40rBaGVED5ckfcmz7W5zP28oYIugvv8/go0gIIVVVAdgl9JD97lllzIznFMwqd5MIyDwnG3UdN+m8HUVFL4nwrxlHjD/M99fKPheVQdvgerSXfS2LtJoIz3rycYCpPCdCdI7Feki7fHEFuM/2keNbEnZsyBY4Qsq58ttkPoqEEFLVFQBD0GEoAAlwbldGGJwTIIjPFyH5q8N9hiIUWjjo9d8ZFFKZGYHKeHFFyMIZc6YqLV+P2LlWhHx22LHB4oHMhdfJb8/wUSSEkLKlfARDZkaBFCgAcJz7zuHWXZSRRfAah/ucqwwT+x8xrI0hhwGyzdOVVfgDEawIt4Oy1TF4Pph/QFQhZUzNC8VgpYoviZNTBlgsgwKH6IamfAwJIaS6WAB275njGJBMCHHt9Rxu/YZCxrnMjBwH+6unLQGH26yxWgv/RdXhBtBe+IhYaGcqbXXBdyRnSnG5G6QAbmzhpwAlYKYsv5GPIiGEVDcFYJdghhCCo53TaWLhBHeOCOw/HewrXSsPp1kIqr5S13zeGjuFNKxELbUi0C6shJalxVDVweF+ClL3BPnIleXXsaUJIaS6KgC7WwMQvlbLwZZwCkSo4FsO9oWeLzIHnq+X+HTPf6bb08iZURMpcBHyB9M7Qt1C0yRvk7JOGTH6KCtq98svqOw3kQjy5hZKgdmaAIXraxH0A8K2Q2joAbJ8MB9FQgipzgrALuGMLIAYpz7C4ZZPKuQcyMzwxbgfKAFjpVyjt3ssToGPXvIxUpAOGVEOeznYHImSVuiyUzHQn6tEQSiu7DeZCHooQc31LIfm5VCMOsnyuXwUCSGECkBIOEOoYmwYs+KlOdjyM2VECWxxYHXIkDI+ZsVhl+BHjD1mvbvFodCPFYyZ/xemGKAs05//iYLg421MCCGk6igAuwQ0ksggaYyTvPGYGfBUEegLSuuwRPijt4849ubl2DrIZbzSwoKwSv+/WhQEP29zQgghFU8BGDjkBPk7TU0e44+gBMAfAFPmXuKg5u3KcA78PMGCv6EyhidOrgTXt9ikDISXlVpBoAWBEEKoAJS58IcX/hRlTA97iSgBy6JYAy6Sv0goE6uDIITbdaIEjE+Q8N9PPj5UyNZXNYAF4R8bBQGFQwyEEEIFIOHCHwlgELrXWC/BbHm3iBIwPooSgERAmPzGyVzyiCq43ekYf5jw7xm0VOw63uoAFIR/1e7DDObyrygIJXyMCCGECoATBQA96VPClg4XBeDWqNsaqYQxJHCZgz1iIqELnc4joIX/PvLxozKm+SW78IUpCPDy/03KD6IY7GDzEEIIFYBw4Y+UtC+ELYXwOFgUACdT7CKBzEgpyTFu8W1Q6Yg1QsAQ/nXl4yflzAmxLEGq4o1SmlQwxQApnuG8+bYoA2v5qBFCSHVXAAYOwfj572pXchyAnPCHiPD/zXF9Wdl95S9mk4s1pzwiA44TJeDfGBWAFx1aGsqa80XAvinHmaqMUMTWps+2pu8oDcvh+DBEAD+P4XKcP/CRI4SQ6qgADByCxDsz1J55+O8S4f9YhO1qy+85EZQACLf3ghaE2EBs/bHRwgRFqCKpzxcV/BrCvwHhiGuiOezpvAVtdNlLlzYmBaFNmGKWaD6Qcpsc59989AghpHopAHfI33BBD7N8XxHwlsKr45Csw5K83qklPt+Vy8YOey+CEgC/gOekXBTj0WASoeciCEu0DXLXH1hJriXaD1kF4dW/Sn/+q7//q/9fJ8I3EEVJwGRJXbWwLo2Z+jDEM0zKk4wwIISQ6qAADBwCr32MpaealsLz/wC78L+212XWSEtOnufxqE4BEVvFPt9Ty9dvutNOWdCKwH3y94EYjggWgC8iCMKTlDFrYFWi2KQYhJQDs4LwjwjlTXo44Rcp+5fisQQzNsr+tvAxJISQssdbRsIfqXxfCxP+4MZIsf8pSd5HIfyDmoqoKqnJSbd2bNb4i70y7rMfy87MeFD+XqyFXSQ2RPn9mip4vTGtLyYqOlIZkyDdKeUZZeQ2wNS8G0X45ytjwiK3wh+5HaBErbT5HbM+/ij724uPISGEVFUFwOiRhwuUj0T4v2C3AUz/Xo93SPjy5CRv//TU1Dntrx/WPYIS8Fqwh6/U1gjHlBOh999IPk6spvcEhlLqJ6CeLOndf6IM/wQ7EF45Q9q7OR9FQgipagrAwCGY0S88th9ha1fYbQLTf5LX+7L0+uE0qFo3aqBOO3iX/iDL26UkJX3b9tr7z4igBMyQv4cpIz7dikgJbI4tQ+WoqpIXTdEK6XpSPhAlII1NRgghVUUBGDikjvx91WI/V0nvf53dZmbTf8Pa6Wr8VeepGQuW7LaO/F4rLSXlnQ7XD7szghKwUP72UUZyGiccyVvDNdfpnv3VMazbW+3pHEoIqU5gZlbDmZuUEaXrBDhwiFUM/QQR/pfadgcNr/9Zod7/nacfo/ZqWF9d/9Lbwd8b1EpX2/LyVfd2rdSvy41Qfr8/8ErLhvWumDlsaInNjQXP9o+l/M+0tL0oCJbWARFcs+TjiDjOGEoN/ByYMdA5iE7oU7tf/k9sClLNBSEU50kuajhZ3m05leRc4QsEf6T+UlpIwXsfx47EcHAUflnOZVUc9Q6Wv4PjPKpvZJ/3VodbLbnUah445FQL4Q+HsKF2m4Sb/sGJPbqpz+YtNPf81cd3XqM27shVN054V23KyVVer+eSNVu2t+p288NnLHj6nhwLS8A2uSFg1kcY4XExHH28k/08JgJsJLIHrq8x9KK6xV8Wpvj/a5wU2IpwunYoAZXSyaOKaylipYwiq+NhbApSzUEvuG+FfK8nTvBjYrXnlWGhDae2Xo5yj6yLCeDucpjGvZ2LNtxaXW600rlRBg5BWtoXLHp4mPFvu91mZtM/qJWWqprWq6Pqp9fcuU6dmjXUyo1bYP9X0usPKgBaMTi6xOf/rutNDx23cMS9ayyUgDy5kaCUvK4wTXBk6ro5/cV1v4HDQu7W1HO6yee4nj0P2ukJP3fuN4M6bT/8Y60MdMhJOfLcOsVfrQkpCLpUVwvCoaI8HSlK1KxSfPHg2swuw3PC/Y6prhGVslnKJv2JXg0iYJYGezuZGRsUIdXDwnGUMiKPYukIIXLpBoVhWXTi+JxUCgsAhH94bvqnRfjPtNvAyuvf5/crxP//r0sHhACqohKfWrlhs7rm+Umqe9tWav6q1bt3IT1qf9nm+xoX3Ny3YOLTKy2UgCK5iQbpl3KpKABz586B1oppjhGJ4N9d+M9Bm2wTAYf9/y7KwN7yeXuL/330j2md1GT/uls65JwVVBJ8njpdCpK6nZkU2NEs1b/K7w3kIEKhXhW+J6+XMqsU608q4/aLbV9Z2cvl78/KmHHyM7lXV/P1RKqg8N9X/k6Vku5wyx7B7bKyj5Bno5gNWVEVgIFDYPY/NWzpH0FTjg1Wpn9QUFyiFq5eq7q1aq6GntBPPTn1q52/zVv5387vfbvurRb8t1Zt2J4jSoCnbYnf960cx9GicCyyUAJ8chNdqQVBQtmRcswRukd3h37xhw8lQOAv0YK+FbRbURD+CVvn+BJvs49ESZivgnMm5H84d+6n05WRnQ/H3DvNv3R2q7zbliT717cs8u51ULG39fEp/jU1UvyoKmkfjyqqzB71p+XMqFmnGs4m2F6XgfpFiQyZE6S8JfcsZ1YkVUH4e3TnMD3OGg5Bh0nKw2zMxJDYKABjop+RYUuhrV0UaZa/cNO/mWe/+Cb4eflRh6pHBp2iWjTY1aFq07iBuv/s49WRXTsGhT/IKyxSJT4/hOtsOR7ruQEyMwJSEj6PvSdQkCcCfaoUDHfA4fD7sFXaSVkrwh8PAkIY3w+zHsCBsLNsPz9suz8hHGT5y/J5W6G3o29Z7fcuXVz3m64rak+q+V/6kxc2PHLh/n/XnXng33W/fkoZQwgH6n3cJGVUibfpD35POpSPbRX8nkQbHMtHM3j/YIz0H3lxDpNSn01CKjkw/fdxWcet8izUZFNWNAvAwCFQJl6RUidc3Eaa5c8u4U+Iz+ctUmOnzVLXH3ekOrN392BZv22HSktJVvXSa6pvFi1V171oRAhguGDdtp2dpcZSvpLjOk32P6MsGrNWyXe/mv5tJgI7fLyqvizbLoIeHq+/yPei8N5/8JjDkPXyoBxISZPv0HTeku8faKvAb1rhAMiqh0mB4MTymzKFP86d+x6UDoRMjuy0/fA0ZfI5EIWib1Jgq7RXoGNyYHO6Kv8hhn5S3uXjGaRe8BlSKkNefENFcZ3EJiGVlFMSUAcU4QGq6qVpr+QKgJHsJzx0DnPCP2G3gZ3pP5yxn80Khvxd0vcQtW/r5io5KUktWr1OTfl5vvrg59+VP2DIv007coN+AiYwlv+JKAHnihIwtbQb06N8ubonDyGab2Xs0L/1EKE9wqL3v58s/9CmeoRCYPxsrlYKCpSRvtcMLB8hRaEwTIkIyHJMm3yuKAgTdlcQ/hgpvw3VStPDoiDUUDujFpI65Cd3Py29ZO4Wk9JQ2gpCTz6ae4BIkjdFCThBGRNZFbBJSCWjU4LqOYAKQEVSAAYOwQV5MGwphOHFkSbuiWT6D+fbv5YFix2FxSVqc65llEjNYG9y4JCz5Vg+LOX2DAndLlL+tmlvjPG+Y/Ebph7+LHyhCGYoR8cowyT8e5T9QyEIDsPIdlC+PhbBv9mkBCyV5UdLaSffV4Rt+5KUUVLaiIKw2KwgzJ07Gl7sY2WbEtk2JTmw8Zl6RR9936jwhc1q9+iFRCkI+/LRtAXzXOwtisAxDsOiCClvEtVxSGVTJgb3PgD2E/3cLAJ3qd1m0Uz/TgiZ/gMB25luU4JC18hNUBZ0lrLcYnlrGArCHf9EqCYH5XPPg+aGLYcPw9Mwlki5U36PqABgqEAKwhxvVEa65Syp4yYpHUyrvSHlQu2HYN4WYyfYtpdF1X+btPdLSzyN/2t76JiXRFGYgrwHUm6UcrqUHlJgomuQm3zYMVtSB44sTNr7Ca1YYMhinorNB6Fezoya6Xw8bUGuBHhEJ7MpSCVibYLq2cqmrDgWgAe0ScbMxyL8n7PbIFbTf8x3Q16+yi+KGhkSUgLKwhLQXATqpjBhjv3DxP6WTe9/umld9OIv0xaFJ6Su/5zsXJv/P5V6PtMC/Qr5Du1oijKm+f1ZWxU+D9sUmQyvknW/lzrM5hY4IR4iy5trS8TQSPs3fBC++lLWRzjfhVK+k/p2RmSIcK9vshacqeAkuicwea/gI2rLUfrZu5tNQSoJv+vn3S3fsykrggUgjol+gpLYgek/GsU+n9q4Peasl2VlCbAyRWD2wjnopYcpBsHQPghJ+d5Ij8XDMjJZ1n3IqfAPUwQCUn6SAiEBEz+u1xh93fvKvsLzHaAhMXRwlj6uEMhlAO/dq6Q8LPVtjXH/cHJE5EJ7qa+ZWUGQ8hssCPLv1zab1+HjGZU7dEY1QioDE6X4XNaxQArThZe7AmA/0c/V0sO2NfUk0vQP1m/L2ekE6FAJaJroxsxJ6XeAFpz+MCEPc/vJNpv1g2KgjHzYiG9FCOAtFqGArsD4vxQMJwyTAmGMYYFrw5SAHbp9YCE527QcY/JwMBwpdSyOQwn5VL7uL/tq7GDTJD6eMT2/D7IZSKUgMwNhyC+4rOXmYBg3SQhuhgAQ798ubNmrIvzfs9sg0ab/nILCYIkDCLmEjzEXePdBL3mwlPDwP5hrkdDgkDDFwKsFLfwnYI6/wSI0MKFI/bDQTJB9I5wM1obn5TuGH9Abh1NfbVnnL1l2iPYdQE6B26TAEvG3i13PkHKp1PlqWIRCZZwX4R/dVrEIaChYNbTSVRqcprKy95KX4r98nZFKwC36Pdgjjm0fkvt8GpuwvBUA64l+kNs8Ys8+kaZ/vz8Q7P1XJOoWf/7O5rRLDkePHr1+HXoH4Y6wtlFmBUCWw3SLoRI4Cz4v624py2NFGKEcw/P6gUSv/m4t5EOKERSEu5SRa+BJbQHAbF2bItUrdcLSgSEDDBNg4qXXIPB1BMFUXc+yMGWssnG/vIgmONoiKxvt2lHfA4gEOSZBxwLr0gVSHufrjFQCK0CuPAvweULylv6xvu6l3CfbPsIGTCzOhwDinOgn0aZ/TAKE8f+KRKp/JXqG8KSHl/Z9IvAwq9VJUqbqnn0NONJJgWCFyR+/j3Ur/LUlIR4lAL1YDDWUaGvAF0qHGurjhZB7UL5jiGK9VgAiHUc9fV5HaAUA4ZCIQuik68TQUFp4BEI1efHlSZkv5QUpx2pFYFGCaj+GrzJSiZ6FTfqezVDRIwOmBZ8VCv8KYwGwmuhnRKRse4k2/SPmf0tufkVsz2KtVD2thSA+54vgC6X87RDsPRrOMBCQh4U7BcYg7DGOfi4EtWwbmtVuoDbX43948DtJc4xjwzjyDzoMca5JQTBPqAQFYJ8odV2tDKc+hIWeo+tCTvsj5fg6al+AxbonvKSavwR/kp4QIirgdNnZZW19FCGV6/5H7+1ZeQZe1pYAZPdDJlOElWMIFc5+H2u/AVIhFADriX4QInZPpM0SafoHUWL+yxskHlqLTH8i9GACN2frezYkoOU3mNxfdCD4MZaMEBooUfCCPV3tmtYWQwzwyWipe9yYSW6aHu+PZgUolPU/1XVHSjO7Ttdvd3xH6R7/tbpOnDecB3vJ/6/J/72lYBImPPD5sBbI8m3V+unLzNgsL8DLtJLkhlpSTyup7z++0kglewbgD/SZskiCRkqf2E3H9hP9XCi9f9u0pIk2/W/LK4gl5r88gcNXrhauEMLrTcJ2thb+GAf3yfd1MQj+WlIwhfF1UqbLNi9KQRx/PVneQg8z1JVlq6VgfgGM1/8oZbD8doeU7jGY3GG9+Z+s1zCCooBzagZBbnGMUO6ukTJcpyjG+n/q+6uL/h9Kyyd6PVg/DufjF3wBfqevl1vasDEJIYlXAOKc6CfRpn+fP7Bz1r8KTCxpKk9TRqhdJMGPnP5nKmMimL9FgD4aZpLHpEEYR0N+gd/ChPUSKZgVcIIyzMNPS12n6HkIrCwLmCQIn9Ec8oZL6S/bPCnlAL09kgPdJ+V1LfTNIPtfu1Cooc5pgOEBpLNtxcdvt2vpllpsRkKIE2IdAnA80Q9ItOkfwt/n95djc3l+2ZZ6SlGht+P0pgUjnqjdL3+n02POjJoQcvm6p14SQbCjzY9Ue07kY/4dgh3e9DCL3SWC02fTa4dARq/9B5teOywM46VOKG4nShkl35GO9xNk+tOphm+Q8pcyQhAjmuS1AH9c+xtcLJ/wRWgk5RurSYxkGUz94+XrQUpnOsQ+ZBmGAe6Vz5pqOw0BwtIyUjzjx0g73EJbGpDSGkNd9bTSCJMcTLkYu12h4OeRmbG90l+VrGy0Ke71+lrBwrgjLFx4rlbJORbz1iVVWwGIc6KfRJv+Yfbfllc+jn8BlfyzR5XcUnvm8O861U0/tUOdmg/M3zLuZJVVWKxfgPkNZnv8bWvVEGE437dkR34PeXlACcjRL4wC3WbFPaf+tO2IZvWX/q9pvUdufefj9T9s2P7BN+u3Lk32eoruPaDdvou25R6fnpz086f/bnpw/KBT10YQxltEgC7TysSLUQQ3EvxgCmE4/MHh5nb5jmuHMf1nMVThpD208jBCKyA4/9rIYhie/liD1MOPIS1wSJHRIYg4ppOU8nrC8iZVRzZWkDrMwg8WGviw9NYK3AEOlIyAbL9IWzamBJVVw+krkcd3vcKkSJHBjbVGwTE1M2NODHWma8X7WP1cwVnVzkrqk/Xna0X8nWCHqColqMnKDnUaoAA1Uc4jxtD2D0ibbA2rF9fs+njFgNR3Vzm1B3zfjopjS0R4wRn6k4Q/A7uODco4rMrwuXKSQTUvOYrwt5vo55ZIE/0k2vQfmuynHHr8gdzkQyeNWlLn4kdWHgdnrdcXb89rI2WPNYv9ASWCP/Rvt0i1zl63NVhCrYw/JbL9sN92zh+EuO6RcmHxvUhbFnJ1T2u7tjBsP/rzX+u0Sk9rPH9LznOybqFWOPDbVmWk3Nyoe2Q/IfQGoX0ieDdrob1B13uqLMO2s20sDVZWCvT8HtJWDDg2HqqMiYeQ+3+KOZmRzoUAxQCxv2ZFA/fGtPyk/R+p6ZtX3RWAwgTUsSYBLxJMOjVYyhnKGFqK+8FRRv6Irvplv1LqHhO8VxAHnhiQQKuvg3NDEpn7bH6DULpDynnKCM2NBdy/PXS5MWhFy8p+TCEZWmZG5dZos7IhTBDt1dhFLXsKfwN4+g+Ns05YKO8qp1ZZ6eK4wffBqbwzM7Yl+Fphrpf3dLs65dnkqBdxz4l+4Mj1XKSNEm3635qbFwz9K2OKN6Zd8+7l8w954Ks1m2dpIVcepOqyx1SamwuLg0VFdwArSX3w2Rm37td2qdYQXxDBPF0L8wP0yxQzBL6LXlukbIQ6sVGWMvIFoB70er6R5XBkO0XKU/L9LVlu9mxHKE9bDEXAGqFDGeEEuWPLrI6bFWnocvu18mL5x8VL5HhlJIQaoIV3ooFiAZ+Um2Vfd8ixvl4ObXyv7BthZT+YzhvDdogvv0a5Tz2NUE4MbV0bjOzIzPijkgp/+B29rdzNE/OFlh1Vh8yMedI207RVLB4gP8Yq64nP4r1WeG8ggqtRPP1qKSO8EXr/VhP9oCd3ufT+bU1ddS+5rXciTf8lPr/alFP20577PHWvfm/LifNE+H9VjsI/USQX+QNHP/L7iqsP++SXop5Tf/rW1ENHPgHkJkDvBclpos3WBaUR+f2f18I/VE+xFGiicFrsI0L+fu0gqJThY7BC9yxBH60UqBT/6i2KdHW5/fQ4XyDHSPlBv0SOLiXhbwZDTq/JPt+RUq8c2nmw6dxhPVioDJ+dRM47gR4ZcjxcUAmFfzutxLgR/vATuqDUzN3lyxMut79A2rhDAo/nkjiFP5gq12ix10b4xzXRD/B4PG18fv9MKQkZsC8nx78XPvK/7b9n7tKhKkLse2WkwOcfHDQZZWXv5vGPyAFljGdGNEfrxEU/iHDvY/P7FinwDcDYLxz9MHaGsQ2MIyI/QGstbH6m3N/JyS63n+TwRd9SCnp5n6uw+SnKiLOkzArOYVC2YN4Eb9AKYSSsKq1nG2Oyr8t+rqlEwh9KEBKU1XVRC8yR54hg2VAln9LMDNwzv7ioAQr2lQlWAOIF72hbTc9qop/XRPi/G63WbROeeGfpmMwBS9ZurF9YXHK8zx/IDgQCK+I5Qjj+bc8vKHshmdT51kd/X3Fzvs/fvIoKnJN0jz8cmOZj6ZEjvO/kSPkFYFlQhlkZk+AM058fKSPqoER+X0W5r3vhSh3oooY/dbvGur8LlZGC+OxyPnMMPX0lx9OkDPfZXAv+x5TbqdBjY1xw3LdygMRkh7ms4zYRkt9X8SfW7Zwbl+voErfvjf1V/H46v8h1mmWtAFhP9IPxRWdm/cljilaMy5q2ZPT91y4edX97kRQHe5RnhJRlsWyOTH/l4/gnTbDwzlP/2Jp7QBW/kW+Umyj8HPEy3umkIgK+hvlHhP9JSdHJfjDm3z+KtQCTAGHCIUQpNNDJhBA+OpWSP/gQowf8kstahsTkdJaVXUPKeGU49dapIC0AP6H3dYhhWdG3DPfl1ZaA5hX8PoQ1L9NlLW/LfTiqGjy1GOZ0k54Y79jTE3AcF7vY9mnzDWoW/pEm+nHlvbho5H1zFo289+aFI+7Zu0ZqyuFej+cFKbYOYFvzCsrD8Q8Pg/fHDdvvqwY3Mq79UAsLwGYt7IMz+cmnOVAfuf6RVwC9VpiPj9Z5C1QUReAvKffp7+9LmUnhH+z5QxlyYwZ/XF66sY7/I0ToygrYEv9LgPCpyMBRa1QFvg+hDML078YP4q9gz7Y6YCjbT7ms5WqX1wzXKl4fk1XKcPJUVhYAq4l+MCY8WJSDi6S0cNt+Ho8nMO+JO79dOOLeK9s0btAyNTn5MlEEvjOvA8e/jeWX8W9wbolvH1U9OE3fTGYFwC9CHZkB4a2KHuNZJlM/4qQfVoapEFokQhKPK40DW1nQMK2KCXyPlP2C8etZ2d9qBaq1ixrfUIbZNtYX1xx9PSsid0ibdKrCz9lAOb8DK+ixjVZGrH+8wCfoLLm/dqjqA/zj1rnY/igdehoviNZpEff1zszY2bNONvX+rSb6ATW0ueFivR7CW77UZaaaPCZuST3tnuugXMDr9OX9bnnkgKIS381KBQZu2J5T018ek/0Y2nB1mnYSHqSY42GJSQFAfP8KKUN0siEoQ7ACYOIhryxDKGGWDh8cLOVc+f6XdiJMGIP+vPQ7ldXqey20Jlaw2Oor5F7pF2UdKEsY60MWOTibIVQzUUoN2uS6ONrkbmU44DWpYPdhilYsz6nCz9pNyp3ZtjTedwOVOTIiPq6R+/BPVZ3IzMiXthut79l4uUrK7XFuG6/zH5S0580LkrVQt5rox479dEHyi2LZFs4EyDA3RZSBuGcj+2P43b9rSwMelGv1A9OojC8tXpDNVPWimZ498DIttDDnwwemED9cW2QO/Ma8EZz8ZBmc/BA2OFy+I/b3tQTO8Afr1P90GRJ8WWVmrKggbRY6rrIGPhTXSztMiPPFtUXa8VZ9jZ2C+wFTtMKBcIs+lhSt3Byu3CWNAWfIsbWXY1xejtcVvk6wlMBMWqLfPwjr65aAus8OWn8qSopkw//ErUUIiZ1eU9WTZ7S8iHcOjsvkGtynZ0N02kmN14fgufD7LznCRD+xau4DdBkrdf2ojPCv90UZ+CuuQ5w8ZktQsxo4ZJQysojdkoCXSywN204rNdWKk/ZqjJfb5fpa/iECfEqYoF+rFYQDtRAw/4Ysf1O0AMCNNVr+nyyfn8WaVTBG8BL+Ua7R/6rx/ODvBpViNwl/DEKTMQ2Icf0/da/hTdn3eptnB+8Q9CYRJx3vsAaGohCh8GAZtytC16BQZcv5/Wpzfrj3x7hU+hAaiPDX9yqA8Pfq+6C+i1p+qY7vS5MyvVU71d4cZw1QLmGNe8PhdmfpjppT8D4ebdXLsproJ14QU/xosJcwcMgCKcOkxDfWgaGFyWMQrtNGWwPWlvIlRXhHjep2Hw9s1xRmV/TeX9Q9ICve0UJjj+EeLei/1tverhWFEaIIdEnwoTaV8rHO115dQNvCYecgeeGcnQDhr3S++vOV4bgVCfgpIFx0/6B3t53wN+r0S5mkjDkD/nJzO5Zx+2Kyra5y7FfZCn/j/PAb8sB/7nJ/x1SQ+wrPaT8X26OTdo7j3mvVY4RWIOPlqji2iTeTIKI0VlkpAB7da/8nwY2D7GbBqWxFCfhOytVSGsShCORLwfAEFIlhynA6SbRGfHg5vHzKnSSPx5eenHStCPE3leFUYnkPyO8rlBEdYJfH/Qvdu1kv68KHAKlebxUl4KrwUEKXwFHsjmpyef4KCozMDAx9zE1w7wXCHKFfCEE0J+yCFQcWnCNlncOlfOJoghsjAYyb5CRwkmxcBm0LwYWxa+RmXxrjuRVpJdiNs9vBFaD331O5T9N7YQUajitPK8C/cfTgzfSV69HZwbWDda1/nPsabrXQK8L1cSlnSGmjzRLHacH9mX7pJwKk0n022IsfOORtKadJSXFUw+QxuVKQg34f/eIKJOiBgBI0sjrev/5A4Otz+h4eMqnj+v8bpbeUYqMgIC8Axod76v9/UsbwDZTLsaIE7J/Awx5aTmlky5rOQctKVvYyKU8FIwgS+/LaKgVDP3X1tW8g/9eTcq6U2S7qxTCgm2QwZZGZcJgc5/g4zg2e3xNc7Ldbud5RWdkYr37T7jmOkYeDiiEJ8aTL7Z1YAS5U8aXrni3X7BdrBWB3IbtZyudSHpCCDFaNdU8+Q8pbyl3oA4BX9Nna4rBSDxE4S8c5ecxqKXhxYRaurxJwAWFSOag63rkBo6ceYq8oCgB68t1FmLey+R3Z6E4yKwVS8JKFL8cQ2e5yPZGQW+qpUgo9rKDAQRd+MPPlBT5D5w9IpCJQEhxasJ65LV4+c7Ht3mXQpm7Si37qYtt0PYFLeYFeoJtwy69V1c7ZEM/z4ywT555cGkzSFRvxRpHY5i3wRhG2ASmLpDwr5TwpzbVCMESftBtzfAt9M63UVoF+DhWB36XA7IyECOtdaMSPVNNbF+NBwRzyIpjhgFUfYX8R1scY/N/KxgNVe/9vlbrahi3HnOk36F5Hol4eR1fTa4Ysdp/LffuplDYV+DjdDFm0ruDXwO3c1fXL5aizsjE04yYBDRyBB1XRSX7c4iY9MIbFz4nh+sEROh6/qsWRFBTn+bANhWCsFEz92lC/jOEMEW/4TrK2CkwXJeBPKRlS0h0czxu6YZ6PY98YT25ZTW/aG/S4Zqj3H83JErHjH0rZX4S8XegL5gg4xUI5gDUAQ0DrEnTsbav5C+d4bRE4tYIen5uhw7oVvO3dDouWxfnVk3ujfnCehazs7sEhJHcpp4uU4fS3XhErKwBCpN0Me8UyDBBv739kpHwh7ibEmDymUMpXUm6WgmxSmJzgfhc9AIyRPRPsnQ4ccp+UhjEexxYpaEQ48y2IaZumTSH4b6umtyxCnj4w/Q8zczQnUFgA1ihjxsD+NlaAlVAKRUGoWyr32+7KSHUHbfx+BZ121o1lMLVCt3pmRkEluDdWKMNTHwL7N2UMIcX77EF4XCTn/R0fuYg85mLbw+U57hah9w/r6Xlx1LtJRfFZSeyMWIZZ/kEpGFPvqpWBRXHUBGfEB7QiMFxKqxj3j9AlOKI9qW9cexo2QO+/RjW8UeHLET6xE5S3lTEoAPDyxvhupHFojBMeZfPbzrAhURIaSLnZ70lPjfPGLk826fZyUvBCLk7wcRg5PLKyByhCEg+UHUShTGZTROWjOGVdLFaAkD9ePB29/EgrlN4sXBgqMJJ6PCgCHA57GIM6XwuSWIGp+eagwBo45NWgljV5zJKoVgnEuQ4cghnnsE27PdapWVOppKRTq9kNiqgJ+DtkWozjwQLws92Gei4AzOa3Vf//j5R95X+rFKA/SHlIfjdnEwxRordPUkYscsn2lOMOr1/0vtNz+a+c2/LWuLPxGTPDIVcChs4GqfhzeodICt7n6EFkZmwrk7M3eiTN9bHjxYTsmXDOTNdKdUfKg0rPwuD7OjPjNzZFDMDMbgy1vBBnDYNl+7ulHivrWTyx/xi2GRttpbKZhnPyGNxEv4lQvl1rM0g7e7KKfQYqvHAuV0aq4AlB68DkMaui7HO2rIvws5EqfKaqFs2r2+05KyhwjRAtK/DCXhrFIrPB9P+n+jruoQCI0C8RAQ/HE4Stzbep7zJ9Te+r6fsDSkk/h+czvRK/KNbq9oMjH6xQcMx6XMWfUhRgOAt13Z3w4zUmLemtCzzIEZ7YVrmbPY5UbIqDPVIKf6e8pgzLdTx+ZfWUkYtmQtjzByfBU+M6FiNstQIoALuEMm6sD4Nl4JDWWjBf6aDBkvQ2F8r2cCp7WOrcEGF/yFx3haz7sTKcYOqrevUMC0AZker1bi7y++Ek+a++yB4t/IIv/EOb1Ou/Jr9w/YqcAoyvh8bOa6hdwxN1G6alNE71emqvzS8K5XGuJfXWrpnsrV3g86f6AwGfdLVTS/yB0EsZY3/w2J85rk/nbrKP2+wm6xFhjV5crvweady2hbnXjZ6/bHcNxvrlu1Vu82lSzrVQAIpkGygOR0q5CcpCzoyaqx02KcySVSMO2ZiVa5yeHRBKWh0XtWVIPQ/Z9CCcCHy8cI7XCh7CLZsqUt3A++lzPf/GR2yOmJ/nImkzdDifiLOGq9SeY/ZQCuIZJh0Ry0rJ5dZYk8fA6Qx5AJA57jRlpPuNNdc2ZlUbqoU7pqV9WurbGmFf78t6vymv923VrFmZxfx7PZ7c8Yd2eebSo/s+ZLfOuLlzZspHLxGGtjfNl3Pn3CMfs2WdWSJAWwfP25jfHWNzU2R5kfbMP0UXCAHkHEeehDOUMWZvN3Syd5TeP7DKETBd99w/tLAC/KfH+GvoJEEhMCRwKcSMLN8YZ7OO1xnnqtKL4zd5cSBU8mUXtdTXgtt5rvmsbLwHYJHDMN2JqqI74pGyAL2kd+TeQFbIn9gcDt5PSt2jO3tOOVTaG6m3zR2neDJrfhbrDI3ecm+uyWNKpLwrBR78iHVEWF9JjFtD6N0XFGADh1wvJTnCfparLp0/Villp/OkeD3PdW9YO9oYL2Yf6yHCMsWmh44DxlDGYvkOa8kYLeAzRIhOhvDXQhe9+EnaQvKR7oG/oAVDP9nWbirafbS1IBKt1Z7j7lAAIqWlhNdwH9N5HKCFzCgb34FYgJXkwSr64nhdxZvPYhfO8iMgAYmheEA5hCPG6RT+JKyj9Z62CpHYlHlYRJ91UcNg0/PZRRlZdJ0yPOZOaoVqvMljfpGCsCaMScOBIdaQm4ZaMMLPYIDNy66V8nhuLcOzKS70+XEhkBzH1ulAm9BXaSFvBcJDYNpHZAOcKe+XbR6XssGmPsTcf6CtBBOVkeUQ2vxgm/h9jOsujnIuGPP9J2w/W/S52Tl8ITb2CJPwh6K2Sbb7Ns723B60FGVmbKqiLw4ovTNc1tLDgfDHNM5w9BqlmFeB2NNKv1tJ7OCZKopz2wu0RU6pcN+12Jgv75IvK6cCsEsRWCVliO55wkksVu9mmMW/FCUAJv/2Yb9hlsKynEluslwI9Jp/V4bXdyTgOX+IRe8f4XlwmENII6aDvUEE6O+x7Bzj61IwFo80zvB/QJreF6XOQSFFQD5x/Tso++GBEHZpgjF8cZTN/jFpik/20VcLfxzDsjjbckXQ2pCZ8XMVf3EsdLl9uxgEf20pE/T91E4REptQOpbNELMyD0vlq3FujYiaAdLe6PTF4/3/lJOVvRW6ISeP2SgF4ykYp4andG6MW54efJkOHPKIlFrSmL1V/NMoxsvT+nNeDD0zKAB9dLgdBHO6NvcP1wL6ARGoU/TUu47Q20zVPeipWmC/JPVfohWmDbKObayorIexrB2hoQaL4+4VOm4bBQFhnM/J9p/Gcb/ByoFcEvslfEa8ionbfPzpUYR/U31NLlGkKnOk7nSgHKqMdOmzXdaZ7SBnPTEEcbwT1sGP61itDDgBDtWTqo4CsLsicKfusaBhYxkawPjVXVL+UD7fy2V8xDNMAgu9ui66t20npNdqAb2PrAdfiGe0RWCMPlc3CSZCSsBMfb0ztHYKReBhFd38D0vKcpt6cWx/KyPkz4oftfLyhfZlcKrANNEWkOOryUsjpdRqNmZQRJKmnqV8Dj59L5PyY37QsdQoP0iBXxX8Q+a4qBMdkXvZtDFbATCd9/txbn1inB3Wsab07lVIAdhdEUD6XoxbT4hJw6pXt51KSirraTiHm4QkLgi87DvdNql/syhWAJjKcX4YJ8d0ujD9/xFPz98CvPxhjvdJfQiLvFxbKT6J4cGPNM8DFIsjbBQEDEOEXjoIcYxnLnUoffBGHiHFU8VfG26TAuVE+A3Py74JOs7FWomEQEAyI1jY2gavcWZGsr7PSMUSSEVq13BivNweMWUtCSfecEB0us5xuA2s446dD5MrZbMaIYSX6hDAp7S5xEK9EXnRrFlZH91iC6EKIdjryfOmvxbRamDkQ3hHhGZQ4GrnuYQk45A6l0p9Bbq3Ph/CWcXmdAYnv0hOJTi3S5HdL4qiAkdNNybuG6VgqOLuKvzCONjl9httev9IJHK6y7pnaCXis1gSjJAKqQT8LvfCi8rIvRIPsFCN16GBATZo1Pb+UdoK+T2OjGNrp7L5ZdnfFqc78VbqBp48Zr4UJCvBmMmeoWyNGsktm1LWRzXCYvalOdFe7oidl/JkSPhroADMS+CxRcrTH5cFQAv9P5QxEVQkGkXpocbCXfJAVc3eJWZuiy/kx4xdeOV9Lur8IXhtMzPghPkKhX+lB/fCDhfbH66MXB4kNh4vg30EVIyJf6qWArBLEfhI92zv2ClkkkWBaty4rI8EIWqvWAhJjPGnSi855gPSGfrgx7AqgceH2P1DI+QECD8G3B9poTkAIrAiBuGFc09EAp+Hq+iL4i7l3iI310Kx2M+FZQGJpPoGe46kqvRKocA96rKWJ7XCSqLzqe4glSbvyXWNK8Iquco08+QxGON6Qg0cAoeXkapZ07OUt8z1m2fNsy9df91QDE0g13ujtya92yIQ8PeSZSu1Bg5HqVxdoLRs05//6V4/ev+/W0yoEzeI3RehvkgL6xkxbAKvX2T0QyTGi1qRMSsIGJNHqkpMVfl0DArA/AScxv/k5dOzSkUFZGXD6WdoAmqaZrHMjQPl9U6dikilYIR+L8Wb/wHDefBzuphNGVXhCsjzDV+AV0v5esZFcpVr8Mlj/pUGR+4AJDopS6exPWZfGjtu1Oci8CHQP8vNzd1LL0ZiHgwRvK97+Mj/Dgc5jP+HHBZK3nv3g79btmxhedNInfDkztKCHCb4zcqYahfKRLFWLrCPrfp3KBeITZ1TWFg4Oy0trX8sCgDmBxAhD8EEh8FxmOEPLQzvf/mO40aIH0I0M2PITwAFIFHm4xMte7uVT/Dj/rxS3zdutdXF8rKx6mkcGGd9S6W+RYpURaFUoCeimuSilouC+SQyM75mg0blTWVYLluXQt2I8og3uVoVVAAMRpax8FctaqZ9seb2y9aGLxcl4M/77s18asuWrSNNi/Gynym/jQkT7JgLYTRk79at27pKeVSWwev2Clm3yFTnXFmOHP/PKWM8rmnYuUPgJ2nlAkoF1g2m85z4+lsbunTptHbqh1OfPeXUU9bYdv2uG4rtD37pxVfRS/h7n306ru3V+6Aja9SocZRWBE7SCsZNMeb1h5NgYYKa+6BKfXdmZSMz42lageqVoFrH2yyP11S72cWx7M13fsXvKinD6uTG7wS5AQ4QAVTI5oyocJVIOz3tpqcegeFuNq56CkBWNsInjijr3T54YIeUnnPnICzq2ZBA1CbyE/PzCwa8+cbk8E1gPhsTpix8K4L3iKSkpDk+n6/LTk3bUGYuClu3RNa9Sddjnpq1ofx2U5gwr62M9JQIA2qyaNHiJitWrJohy3vLutsshD/GjN9ShgNgkL//Xrpg+fKVwy+48NwecnyXaovDo+HCX7ZF6tBhypiACPcXHAhnb968BRMWpdokFNqDKNpbec/nfKzcZ/UdrF9XW3tw3LiusOAkMqkKfE9eTPA5tg1aKJx6e2dlI+nMy4pUdKEE0/RNynDyjBeEY9+ln3cSGczLcn+oI5YgVqj4cw3s7IlWJeGPl+zj5bDnL46o9/uVdYs/QcgcTOWnYDY8PGYQ3DVr1oDmF57F8ACrikQg53Xbt8sbYYsvFMF6jMW6EN7hpvczZV1v2HrGtMiY4lNTUFCAh/dVC+GfqnsHHXa7UbzewosvOb+rCP+GWpNFWt4ndWrhZNO+MORxhxZ2UAbgNXzX1A8/uXHhwr9ine1R1fAWutAPSp1Bug1iLRiuuVsrYIclWPiDB+SFbpcue1ucdTbVSlysz15dKc8rY1KjFEUqgxKARF1vuKwFkTmd2ZhR2xrv4HEJrhURZ65yxHirWDMjVrx9Oex3eKu8O05onv8ITOPjdW/9Zf0SHSK9Xnjfh89waDvr2sEH91wsgjY8ZO4am9XDx9XR229koSygJxceDnaqHnYwc7xVG/r9/gP//nsper3X43z09MWY5hhhhSNFCehkWv0G3ePdic/nq/fXosV3xdqg+f6IgQoMRdvFd1FeLCtd1P1qMOY7suBvLOUWZeS/uIKXo9KBZ7LAxfZ4j2VXgyRdiWC0y7Y2g+HXl9xWUjmHADDuZAjE27VmhWUY676nHI7mz9e6vYJEOX8GVMrduueMhwIJfDAHAJLkvPzSi7E7gXo8nln16tXN2bx5S23TYrves1VXGZP9WIXcodeOZBFmMxS8+M1OJL3tjmv2rG/rnnvuwJ0hgaIEzJVzQ8ZCRAHci/kF5DzraUVsD3bsyOmToDb/je+SIJuDymbkXsAvLurHMzVTnq1flTG7IxJwwckUPgxtlOFgiOGiJF6KStszXSXXd7jLd2d/3el5lQ0asa03SFujY5iRgNqe2yn7qoUFAFMkZmWfLQWpZ+fpRjzLtMZ1ynB6K2tGntFk3gny2XlTjSsw/okeE7zih2lBWC+oIRufMSHbrhElIPziNtOOeXEDK0BKSvI/YYvDJypqGaGKs+QYWocdKxQQeLlu0yGLN9qda3FxcR09xOCWT/k2CWZFPCWG+N8Zyl36V6UFPWbnhNUHQxqPaAX8EAr/KsFjUta6rGO4vJsbsSmjgsy1blO7F2trgmsqvgKAGcyystGzXiHlbbV7WkVzHGp5OIatl/JawFPDSE8bCGZkGiqCcJ4Wjiuk3FNQUDDKYtuIE6bk5xdYpXWsEeMyW80wJSU1XACHC+vaEQ4rSSta4WAM8G8R7vXtev8hDjhgP7fXaU5wgpPqDe6dk6Qdvouh17GWChOJco/kKPfW08Yq/tz31amtobC/67KWt/RU81VYAcjK7iUFWfXQY0UMZSuLtfrLOqEe6ZflcJTjcvre3M0TKAiG0jQuHD8RyXbCV3pj4mSrBDhFkRWA/HDBvlF68LkxKgAlUR5UM+FDCNF66FeJoA+fdhbZ5v6M1PsP0aJlC7exsNV9RjIowsjON93BNg/xzUuiMEG5Tzt+mbyPj2BTRsWtojQ8UQdSsRSArOxUKRdKQQ/vJ93DjySQzOFxU5QRDlVWwJkDpv1bdi3y24VM1bJYlmtXsQjYOoFAoEvY4q8cHJulyffzzz+vV1hYGB6+FjWhjtfrLTb9C/+BgWGrdFu+fCWczaJms2vcuKGb2ZnGieD7rBq/ODDU0iM4zauzXgeep1fK+FgRnnQG3/WVpmeKd8ZNCahpfPA9TiK19RwXHdavHD//lcgCMEAKZsw7xME2F+tGLSrjl9yr0vtP3V0Yeu08YVOcKADKcKozbxNpsoc9etxjx42yHF5YtPCvi3w+326Onz0P6rFg7tw5ZqVgj/j2ho0ahpuar9qpPRghgM2mfz3zlLBtC7QStxtpaWl7xdner6jEpMutjCDD3zFyj58fIdwvGhi6KQvnSViUEAUC/xxExfzFN36lEUzT9TVzQ1cF52wSjTVxbpfQZELeCnYDYqzyc4dbdRaNM+S5/mIZHi0uxPVmQZ2b3Nsut7ZV0pji8AUiTGs/My4bDlcPmpenp9ccLUL9xwhWkKhcf91Qz+rVa681L2vVqsXiHj0OQKz3sRE23daiebMxYcsOlfr21987iVKx1KL3gBCV/FgUligg0dCVcm8MdhvzWgn5XsrZypiN70uXz1auvs4/leLxwtJwoOxrTDDRjJFEaJwilYnbrd5NDrlX3skd2ZQ2ZGUjU+b5cWy5UO051XyVsgAApEd1+qK/RL/kFuiXZmnzifT+/1VhsfmFSZ33tVnfyiRWIEK0sZSaWkA3+Gb2d8OXLVuOkLyQmbyoXbs275w36JxIPbcUix5YuPBHdMQLOTk5XUPLWrRsvvqoAf2QswAzg5nD8/YIwO/V+6APGjSov87GCtBt9qxv4VfQOky5edzj8ex2fyUlJcFKcwAUnWgNXDe5YLYy0hy3lev6QjV6PcBJCMms9pfzPkzKuxbTS8erBCA0FE60Tyv3nshm4KdjJDnKzFgY9huu3Qq+9SuNFQD5HO53WQveIdlszAgKUnzRM087zsxZ6RSAzAw4k413uNV5pnGnshAWcMIYHN6zL/HUbyvCzcrcn26xDMMceCHniYDGRd28ePGSqwoKCmuGVqhRo8bW4uKSJX6/v7+emteKcP+CJKlvipR3pLwqBWPm/+oXtKpZs0ZOz549vjrhhGOPPeSQPhAEsCw0MU1VXDOsvqKePQ8qadeu7cyw5RdpZ8D9VqxYdWLYbxPHjhu1Kjk5ebfevs/ng0UAjkaPRZsaeXtJDTgTIXrisWAkSNVkh+41P6+MSYE6yP3fUcqdNhP7JOL5KpRyS1DBMBy/3CQm+UkrgntLnS9bvpyM2TExPPSHIpVFCUBYIKyb613Ucow8t+ezMS17/xfGsSVkxeuJPpyKmgjofm0iiTXfOtLTnqwwL7KRwx4T4pRKToBGaSlrVvYZMkMZE/Hs3piBLch7f5DaM7+2VY8XddylBXgd6S3XO+CA/Yb8+efCH0pKSuBX0KSgoKDpf/+tvvPdd6Zs79q1y1RZ9k4Mh+jXPa5UrXhsS0lJ+bFZs6YN2rVvW9ixY/uR0hN/X4R6sAcon34Rxr9oheRji/ry8Gff/bq+OX/+n8fIsYWSCNUTAX/RooV/dRcFpZtpfQiBh4Papddb38I6gX3AcfMR2e/davvhEQ0Byog/HxR8mWRmfJGAS7hKWxbKErTJNv25RT/Ma+R8tpbjS35hsB2ystG+xykjoyNyQuyjrCcQgl8J7m9sN0vBiSkz4+8Y9/WHTt7VTVuKGin7dMFLYjyDx7QCE6/i4oZLXd5/0djoch95Cbg/xsk1Qy/+QH3N6sdRi5W/yiIX5+ZkauopLixPq0rxyYu39z82OItjtVAAMjM2yc2H/OlOHB4uDioAGOvMyp6ke1QJ5+TWjX/0eeqdmxTYtscYVw3fIlgv+oYrAHXq1G6wY8ceoflrpJe8cz0RhnCOO+zKq664XnrWSNk7UcoJwW7ijpy6v/46b+KUKVP6tGnTeowI7ZURlIt1Uu+Nuk4oAEhOhJn7MAb8jGxrJUR/0L20j+0Up9TU1Dlt27ZesHTp8p0ZCUXAX/bHHwvCLQaTZf/Bl7goGuHDCfm61/uhMpyFrvd56hQkBXZEa/bGwWPLykbim2ku763NLgRHVezt4cZ8V5ljkw1rWrq2BuUH753MjGKX+4Hy86cuiTjuz8qxzSaUwTWZUAHuDXQm5uiSqDrXlsm5GZ7yFStjaFZ2lzh7/xD8z5TGIVXkREBwHlrsYP2TgnnJDUprGGD1JR1bwNHQMmlGeslP0BxbasG7a3l6ersYtNm9Q70fEaDoJcKLemcPq7i4OPWbb76/THrgY6X+e6R0tlHi0KP3SDlaGUMp6NU9oF/kdg8yUr3urcfmw7XTHdpS8M+BPbuHUsGGjung7dt3dAtb/2GtfNT1+XwpNr0CXKdn0RvekXL0cTG2PeqaJNe4FaV2qb88i4LWicyMNfqzmI1CiGuGxdn7f1WewY2lcUAVVwEwXjo3O7RmDNLbwsQ3vxSOamyPokt2SO9/3wjrzNBWgJ2kpaU2sRGEZjqZBb4oAfkqbJrNgvyCBlPenzpHa4SPi5B9yOPx7KYASK8cH09KuVwZwyE36PU3iRC3nONdT9GL9jrQQqHY6SxWt27duTVq1tjpCxAIBLxhN/RHctyhdu8pCkB4QqLtWqForNMGj/EGCpzks66vlRlCCKk8ZGWjozQwji3xnny6tA6rYqcCzsyASdpJWKA5NfDzCT4ajKuNT/WvvDbKel8rYzx1J0lJyc1itACEj6m+r8JCcqTHfa4ITzghwvnqHxHCuzkB1qpVC0ISYXlXyXof6bH+niq6GQ/DAL3UnkMKZiG+oEvnTpGyhZkzVB0kCkB4z9Evx1Oge/NB/4O6xdO+dngdLpKHqSXfKISQSgT82uKZMfETkYOllkujMkwG5CQs8GCtaQGMoRcm8Dhezul7M8bHz4q0kgg19Ow3S++8Q2iZx+uxsgDsTAQEk70yZldbupu5wbAChHtPd8GEPLKf9VL2iJbIy8tbLcuzpZgH1mNRAH7RFoBwzD30P3oc2B1C/V+L9X6V452hzwdWgYainNgpE6YHwe80rAXKw0l8nxBCqnjvHzxVmodW8RUA52GBocyAMHe/m6CjgJBCZAE8pmMZw4Gj2vE7LQB7esPvpgAoYwa+Tbp3HI6VsA0OQYRyCJiRXvducxFgLF4+WqD3HoPisk5FngxoldfraenxeN6w+G2s6Xt3Kb9bKRNyPIgiSHN5PfrxrUIIqeK9f0x8NqN6KwC7GjDWkCnMJRA6r0RlBvxQev+Iib0qxvXhVLcvnOrQGy4uLrESeOYhAFgL7KZ13WNin9TU1FA6Xat6w83u6P3PC4X9Rb3h9lRw8kxKAhShld26dQn3roXyMMn0P2L7vg8/vuTkZCgsTyp3c9QrrdAQQkhV7v2PKO3DqxwKAMICpSljXBte4gP0d+S2XpqAI4AZ5goVY24BLShn6eNoWFxSbOVFbXYCbKeMGGsr9gjVbN686d76q5VWGZ41Dv4HPUURuURbA2zx+Xxzoigq4K9D+vTqlZ6ebs749ubYcaPytMUBCsRe0gaIiNhtpsL69evh2oyW36a7vB71+GYhhFTh3j8sv29RAdiFk7DA0DAABPFLbnbauEbKKun9w0HuBoebwnkRwwBNiwqLrKbnNfsntI5gAdhj+tySEt+CCIIwfCKgycrwIsX4/guRFIE333h7QwznhUQee7fv0O5qZWQRxHDHfabfkQjJ0lFw69Ztf4jw/z0B98IGvlcIIRW897+vi97/KJFfJaV9iMmVpjERFpiVDYfAj2JY+0xZN0Mn1HhZGaFj8cRfqrPaNP1tR0r/++sUT2/rZDsRdFtE0CJhz4nFxcVWudzNE+XsZWUBuP66oTjm8Dh7tXr1mi9ivX7aGvGDHAuENbL9YabBE+R/zPr1ofy+0xehqKjIyiEvfOhlNQRwRsbVyNXfx2J9mP8ny7HX21NxKUlUJqulfLtUXHJm1PTW7pfvZ0tU2uuHobpmCahqm9wHW6pxUz4cZ+8fcuv5sjhAb6VqztjDApGI52y9DaZdjHcGpVUn7tXouhq+RVfEuT3S9x7h9/ttU3Nqk3kt7YRnXu7db79uSBsZPpHQ72PHjVrj9PpBEZACSwZm7RuplYEXZT+DpIRM9bE458GnoJ6OXAg/F3joN5H9/HvSSccfHIMyES9fKFLRhEa6lEFSoKA/zhaptNcxSb+3lrssmEK8+g7VZQVndT0tzq2fdzHtdxVWAAxiDQu8ZLcGjY8xA3xHt03xr4nL6UwEISIYFki3enOEtkfd/4UJUqQZHr5+/YbLLbYbH0WgpjlUBA5TxtDAqWlpaY2iWCoAkhytsekhwPw/X+rKSE5JvqSUrj/M/9MUqRDCQspxUl5VxsQxiA5BiGYKW6fS8oTa5UMVLxiGPFF6/yuqcTtmxrkdZNuosjrIyqcAxB4W2Fe0sJDZ/lMttOIxw9zi8ojXtWzZwmosp53+xBj/P1rwp0rBRDlP/fDDz7VFAQgf/19gVmbGjhuFl274Q9bFoUUAvg2Ilji1V++DrLxOV5oUk+b6BkWUQxuLdTHVLCZl8vw6d95tFr8nJeAOeErPMEfKT/D3ljJSK67IyY97thZbptJf1/OVs+yrVsDh+SwR/r9V24Z01/t/Rt5vK6kARCaWsECYqC/USgME8MsO9/FCTt+b0SM+3eWx1urRY/8StadzHqbThXkf4///inCF4B5VUlJy5HvvfrB8wZ8LB4etj1zQp4nQD48oGB2uWEi9hzqwUgS0V/41Cxcsskqc9Knpez8pM7XCspdJMUiSAmcXOL2Mkvqeuf2OW5FTYFNYXXu5bEtEKYxQpDyEw95SMqXAERf+JENVYsaJScW4vrDeJWIOlcEi/L+s5s0Zb+8fls07yvJAkytn88Y8WyDM0A/r7+jl3u3QDHOLcuTE4bVat5bwivSu1/380xwoJKEJizBJz/yPpn66uWbNmqpGzRoN1q/bsEWA+b+JhRC+SoS/VVIgKADtlTF/d2j/k0QJuEY+Z+hsglF56cVXMba/m+mvSZPGv55y6omYtTC0CDMB3qV7/8dq4d9WCwMI93Ei/H80VYEwFnPq5N5yXLWlvpw4rvrSoDLGiWnKUig0VYYXM+7bQ9giVfY6432DqdRruqzqVhH+b1TrxszKRiK15Sp2M36h7txh/ppZOnKNCkAMICwwQxmT6Nixj1yQPtKoP0hZJt/3yNNvw/vS+4cThqN5q3ek9O1k4W8I0+gX+++/78l+n7/nnDm/Yv8wETVPSUlpUlxcvG9eXr43Pz8/x+fzwR8ADoOYEwBmoG+lfCAC81e7fcpvUFZuEMGKPPyYAbC1VmCaa0Ui4tzW2goBIQ2fADgD+r1e74p9Ou29oXfvgzCn9jMi5N9RRkriVSLgkc0PFoB2utePaYQxBnyEMhx/zAyTcowy5pgHcM4cPX369Cf69++/SLbf17fjhBoxTAcM58/BpTUjFrEFER9JbIYqLfwhAyYr6yE9J4wS4T+82jeoEXl2U2U53ORK3NCxhgUiJ8APJitALApAaLIdR+Oa+Uk9T54790EoDm8hDFAv9mDSGxF2U7r32P+oSy8b/Ip8f1UZQwsXKCNj3kBZx1XPVhSBlSqOzIeyHRL9jNRF6V49LAkYMoE3935SEPN/rpQH8TvmGZB1MDwCa8UNWtFoHX4OUvcGUTBg6bhSKydtatas2e/7737sIctPlf+vyUvu1bRO8Z7zASV5AhgygSlxvFzrzxUpDyj8qz6wovZzWcfblUnokaphATDCArOyIRyOjbDWebLOTbIuTC2YGwA56xtEWP876f3Plc93nB5Oqn/VT7q3O0YEJEwB75l+ngEhK8u/1soFeuqPoBPuRvhr34FiqWOpaVl/rbx8rqf6dQT8AnQvv4V8h1c/TPy9leH8F+JW+W2d3h8UmQ9tFAxYNEZppQeOgZguGJEKMJVNL/E0vt1qu9k9n+5brR2JCCn93v9gZQwdugEZTy+UZzXAFq18eKvAOUQLC4SwP1krDFACXotBI4Zpu5XTA6lTPA3j37laG8ZY/7MmoYpjhFKAMXscByYWwljRpjgFf30p6H0/rHvoZpAD4Tgpz8s6Z5ni/J2AYYj2oWOX8r1OKhQ6n5DwhyCvq1P/RlJSHtFKQmjOAIQffpLqXzmfjyEhZS78e5nfT3GCZ/dUEf5FbFEqAOVlBYglLPBi0/dInq4QyO+rOENhkgLb8SAg1W0nEYgQ9Ejk84FpFVgrsuS3h/R0vVBOHKW11R73p+iHt6YW/rVkWTv9Oxy3vFI/FAw4ouBBDyX8cTKkAW/vjjGsB8fB6TbH6oECoi0eD+qwQ8yMiHbKxeyH6SW//cXHkJAyFf7wD4J/j5tZOeGQjFj/bWxRKgDlTbSwwBNVVnYTrTBAa/3ZZr2R8jt66ge6OBb08o8QwZeMjHhSvjRbAaSYzdoQhjE7tkmd3bSFAnMMPCZ1PS4F20/TPX6AcJ65en9zpdwpXx+V0lnKy7FMCqRZEbIARAHDDZstjhU+AlnaEnKnHMdq/ROuQ1dljO8rjyos4WNISJkJfzj9YnizpYtq8K49ToT/v5XknGvD4iGln5RDpNThnVCVFIDoswXC12GQ6X+rzIDQZF9yeygi6DDmDSWjXwyr11PWWQLDhSlS72JYAfGlM6TcEKZIoAd+uKyTphWAOWHHhEl4hilj0h4IdWT+u8DOIiDL4dEPk/0/MZzD61DAZJtjTNvj3OEw+IHsd3yYHwIiHTbIsk18/Agpc2CZ/J+L7TGfB8z+CyqB4O8r5RP9jv1Jvydhhdwmy6dDIaACUHWINlugOTUtxqE37bG9EcKRCNAjHwArQJT1MATQym6MXpvQEbXwjDJC6K4Twfme9icwC3gMJ2AGvqN0T/8PG+XkL60IwGKyr1YEzg7tXz7bS4G1AD4ET8m6URUiWecXrVhgiOFaKUhkgQmB7pLfrKYXRvKYqXwPE1LmAhFDcVe7qAITPMHhb3YFP88UKc/oztIJas/U1B7dQYMSMKw63xPJVeZMoocF9gxOzwifgcyMHfIdQg5j5HD2w3jYQwk8GiTVgZc/HOQiDU3Agxa5BuCsh2Q/H4nQ3K6FMcbprtP1jIUTXgxKxz0Q/tE8/+V3TOl7t+xjf2WkcT1FvkNp6K6MfO6fIXTRgdVjmWz/rn65rNeKSqGVQqMM/4jJO98ontpp3kBOoh58mDcPUEY65A7a2oAhiFT90OOc4HOBtNDowfwiL7MlFA2kGgh/ZAcd67KaofK8vFvBzxPP+UQp58QqOWQbn5zXg1QAKr8SEC0sEFaA2/W6M7TASygi5DBZDuLeHxBBtzWK4MT4/ZOyDQTVGVKy5ft0rTQgEuErKY/qYYVoQIDDEvC7g8OFEJyp2wUJlRDBsN6J8JfjhRUDWQcRM56hvz8sy++3OO7DtRAObVsjJ//BPnWLp7l54DHkcaYyJinCDIRpDrdfoYw45hfkJbCYooJUQeGPTs57yt0kTY/J8zG2EpzudQ6Ef4gHpI1mVHTLRmngrYLnFCks8AJREEotucmmtMvO0DcghHbMwkTWXYP8+coI6TtRGVELiEj4OEbhr3QPt7aKnBnRLLghODEeiPj+23TvHS+JofLbA6Gogih1IAIAvgKzdWQDJofJ0grMMO2TEFoX7Y6kQKGJj/DblbVKfv4ljhdaIyn3SUHuA2yPFM//U/F5NbfT579I6ntTSmuKDFKFhH+afq6bu6jmFRV7GvXyPFf4ND0Qr4JTHe+PqqcARA4LhOfrgNLadYmnEZIAwbegK2b2c2g5gNVimDLy/sMsj+GBO2T5fUiZG0MV2Dd6s10ihfvJb62lYD+XSXlJhHamlJXo9UtBVxzjhAjNe0LWS4/S80fkwe2y3TcmZaZEP0wYyrhNm/1BPynIHbBIHx/SD7+dFNic6+ABb6hnoVulH/QOCbx8OM7zpCzUCVIIqQo8o5X8eIFF9apKkugH2VUbxLntYfLct69uN0dyFT0vOLlhasv6Fr9dom/qhJPu++XDbeo0CCjE6SPrH3LYT9NC0U6QQkOH2Rw9z4dl3Xn6J2z7sR6nP1k+YRVAIp3vzAl5TKB3/ZN+AI5Uu8/ih/3U0W3SRxmT9HwR7kyoBXi+zmLYOYr1AebEZdoBMbyOEqnjSWWEH8LJELkQkJ8Agh/RFsg+9hzSJW+Z1bFBin91NMEP4XyFrq9RKd87OMaXZZ9IgXwbM5yRStz7v14r+vGCcOKzKlGinyNdbo/w7+W0AFR+K0CksMAzVFZ2qcSB1imevgjJbaRgTPk2LaweibJZQ2X4ImSahL9ZmM5HvL8y8vJjwo7HRKCeZDavmxQAPLBfmK0ciESQgrz7cHiEt12G1PeZlfA3gWGIaJ76UABsUxhrJ0Cc+6naqgClYm/9/9jQXAk+T/060Xr9WvF5rgyEvxnMBPkkxQippMIfPjFups6GIESin5xKdNpuh++aVrf7xFuFz80uLBDZ884u7Z2LgEOmO+S/X4c4/gjrwSMdiYk6R6lvs5Q3lTEWB/P6zTqWHzkCcE5NtCkfY+wBbeqH6Q8WCYTe3Sy/TYSCElHlN4Yu4En/i/6/kfk3KXvrf6GA5EU55o1acK9QhoMi8iM8jbbR9XX3qBJfhJcY2gTzD5xcTvfQLXIMlypCKpfwhyBEpE28Fl48t0j0s66SnbrbqcKrnbUvucqeWeSwQAwDvFxGRwIBj+x3kVJmIvTuLhGI86L0zENzCsBbdbas31YrMxirN4cJhsbyocUjGmG9g+NFZj9EIjSQ+i/U1oTT9G/4PFOWI/nPQmWk9I2mCJk9ayealAk4Be6X5ltiaf9PCtQ6zqOS7y3xbKtdznfSGHmhzpSX4TKKFlIJhD86A1Nc9GbzoXDL/f53JTz91eW8PS0AFUwJwDi61Xj/kaIctCtDBaCZFnp1zGl45Xsv9OBFSEI5QIaqYxxaGdDjxxTAmN/AbLKHAyEiEV5yIvy1wx4EPszuGG9HmODPCNfTVgzE1N+lFYFrXWrch6jgPAn+gLUC0OCR5EDD2hXgLoJPwAhF/s/emcBJUVx/vHpmWVh2l1MBFREFlUPEaDzAiCvGOyreMUYl+ve+8IrGmHglXvHWiGc0XohJPIgHXgsiGuOBIioqggiiHKLcy17T//fbfmOGYWZ2prrn2vl9+dRnlpmpmqru6nqvXr16RYoDWNy2t8yLLbqHi/D/b5G2fYrP/O9QAWh7JNoWCEH36xxqpRuKAIVQxZr4GTGfQZBiTR/OOoiaV5PK8z6FIlAXK+gRCCiD7YOxQAGBiR/LAOfqOQYQ8pit41Cff8l7c/Wawow/wqa+Gt1wqZSVdH3RMeGQY9rBElAIfeggmVkNp2whBT77H+NzXIO3//NFfAlQd9vDiV6Xti+kAtD2rADJtgUen0MFAB7l2BqH+P2v6Ja/lmfWeIGJPlKhCrPdEbm+RFjXlwTlBJ72Z4pgfjBGgYAzH04FbIoqGSq4seMAuxuuSeXjkOC3EJGsCmGJ0/l+2HQulJ50AUUMKWDhD8vdjT6KuFwE4P3FfA30ZMKbLLNfU4r9JlQi7Ux0WmB/c8XYXMzq4CyHCHWvwVwvCWamzUQQYlkAjnGV8t5kVQAQaWt7+ezPujzgZFnw95B0ngp+LEE8H3NqXxSYBRFp76m493vqQ4OwwpelYwmQ7/xc86Ud+i/sVhknfVcV1BX+C9gxgW2T2PaIeAFBrGcezCBBpECFf1/jOf3Zjuf3ivC8oo1cDjz7mZryEQX0BSoAbdcKkGxb4HFZFrAQipcb7zSqx2I+gjPcMcbzoq/SWbWL43vVUgA/AcyUb5My9kuw5c93vXAssCpG/9Ujg3FE7zMJvg6noBkJ9vt3Ut+Fu4x3Nvi5yRQWOPxJwhIC7sO0ROcEpKLMbdUKANMdtl32lgd5pKSLJT0saZyky7RtF5mYMMSWz8rJFDekwIQ/xhg4/XWzLAK+Q6e1leshzzvGFmxjnppmFjiDn1qq/SdUQm1NtC3wKHPF2CCEKzrdm5K+ihF6uLZwmPtCZ7y9o5+peR0zVVgg1tkHr9sC39QEAY1teAgqdKxG3/Mj+CGI8XDATAbhPUZ+7w0N+7s0ujc/5vsQ6NiKV5us72hQotuNF4Bo/wS/ifeP1vZiGWFepvUOtygASY0hiG/QTx78GyR9m2RQwGEf16ulww8nyoBbZggpDOHvqACzPdMEO4d+ieejLV0XaQ+2MdaoYE+2eweOjofId09oa+2nApDYCgBntvPi3kWkwIMyL8zB/ljE175AhXgn6US7Snp/HeXCizkAxQNr/IPjBD2+O11n+/HgxC3sfUcsAWy5O8d4e3MRo39MOnH6EwjiaEwAHAxyoZT7dEyEwlHanniwJRAm+xVxZZWrZSDalkZVKo7U7X2xwh+OhY+rAmR1hjiWALAUkIBT5JqPkbQmzYHhAeNv++dGJn8xCQiJB1avIy3zYjJ0ULrPThEqAVD675YE/6VBkg4wnoMkjgfeRN7fRdLTpd6BSms2k/i0QBzg848UuWA2/tDTlkNvLO4wZs2y8kM7GM90PieJsEXEPoQDhid9o/wfa9DwfJ8Y91VYBs6Sz99UIRoVqA0aPhdr74/r8b4vyHvIv6Okk+VvaK34zntJQgNH69JDFQg47l0Tv8avJxFiF8H3ce9DecGBQe8niE2A+APx6+rYFTA+7rs74OhfvR7zW4txkLqjdjbNZp1ViDvlAb7Hoqjz9Z53sawKlgFKfuAgeZ/972vsHdewZLaPzpTbPNJOxCyZyV5TyhaA/xG/LTCR8xoE82U6e+0sHegnkk6vqln9qAh/fIYtexuLYDtYUqIjNkdLekwE3qKoQIcMS7BGDnM4hPcx8QWohaCXOgtG34OfwNuSEA3wQeNtI9y9lfZC+M6TPNckcPAzqqgkmv0jwNATJvG6+ZaxD5Qud+BaTZS/t9ClBhzUM0sjCbaLX17IuKO6HY1jfjxfqUHvj81ggHrc6qMq+8rguxmHDpJH4Y+tuuMsx29o0QjxO5dXkpSeApD6tMCokNhX0pWSXomPha3r99CccfQtAk8cHRcuFybw7glm+x+p4Iwtq16VgFV6PG88CCWccF+v5MVRuPDAj5+5x/s0fKxKQCLrwIYqnJcksAqEEWjIJA72s7Ee/RsFpwLCZwGn6Z1rvFMX4TGPNfk+WtdkrLe4387dQDrm+q4ZMc6Ar/ucvYw19kGMogcTEZIP4Y+1MFigbCxY6POHxS1VEioAJUeibYFpo+byehWeENI7RWf3aubGDHPXuGxwOtkhyUOJLXY18fvp9Xdm6d75REDIzleh3UFPDBwrr1chzr6WgbV6nA3QIUH+Q5PM/uET8IQqMw1xysE66//yf2xxxDID1tawlQbOfnuqlQSna33QyuXcYF3hv6EI+sQOzWG3U1Rf8LWtT2Ocj/dRBJ0BST6Ev6OTgsGWRcDh7WVeSVLaCkDq0wLTVQJgTq/Q2TLi3Q9XgbifWgiWqONd9PtwpKuMdZJTZusM/W+Sjk+wTIBwxnvqmnw8CJO3TD7bzXhBQGDeO8l4jm77yPvXS8Lxv9D4t0kw+w/rroPY9xGi9wO1dOA7X8f9JoT6O/rdLXTWP0NjHMC8vlyVEjjepPRPUHr8T/j3EOHfNcXUOxx1BqwPoBfc4SMvnQFJPrjUeP4rNiCc9T94CQkVAI9kpwVmogTARI5Ze4UK/E119gslYIik9vLe9nFWgB3jioGJfoAKz0nxgkUtCljvOypOUIf1t/9svEBDl8p3n8L34Zwo6Xq1REAJwU6HXeOUi4PiBwRVMraTvNGDhfqpghLLVpIWyHdPNN5Wm99p/ILotsGfqlXjo5hdBqlosXqUu71E+Ldu1Szzvr6R35uv8c79xP4+jcNHm55tb11g9fmFz0kLlubWSjmLJL0s6WocGSwpzLvdcn3bSerXRtqStlwvXQUg8bZAGyUA6/CwTa9WwQSPepiXYQ7HWviRUSVA3sdxuAPiioAS0SvmczjQDYj7DQjhiM64o2b40caL0f+wfH5zIic7rNNLus142xWx/HADlgZ0e54bv/ZvPKfCJ2L+D4VmToyCAIfJbfW3wQOxuxfUCrImxoKQRgcs3xDC3zPvp/F9zxlw2wCVQFv2kgdtCw6dbUoI9JP0e0kzVFkvlHphPEDwsCAig8LihoiciFEyWRIUghvbivDLVFBKGiEJwczg0/SHIm5LH0kXSXrPZLC1PVTST7x3WuCLfotRAQ2vNawt12MmDJO/KgKIsY9Y+ydJgqCfLa9bxuR1VbhH15SxtW+3BPH1UdYoeR8zcMzusVA+SfLPTKN+EPQISIRlAgTrucp4sQZiZ/8YZL6JUyScuFk8fhPxwuE/8fdY877mx3LBfbrckRYy61+QrvD/X55OW0tH7xpAD0B8AltnQjoDtg0h0FvS+ZLe1mfkTyZuuSzP9cPD8bRJHC8kCLrrROgz+a0HSyHctbRxF0k36Xj1mqRTjLfcWWzt2EjSWZKiQegQRTajkyBDHALMPbYZm2uHhhprt/5Zw6T+dw5Z9qvnt1x5IALtQPgdHiN8oQhgVv2u8U4ChGlxVFxR7+rMOqoQPGzigurojoEJkk5UQY6OuzKD6uIgn0ZsB5TXSzSMr4mxKOws702JeQ8CNt5CsFA72FOxioHGGqjQ44nrMrmGEdP4VqbXXRQGEb6hffzeeA0beq+PIk6A6ZCPUNENnD0knSYJvjvYhXODWX9prhDqCSXzER0zsg3GGoQH/xSnCra1pQFpzxBJ10jCZA1LnFgS2agI29FN0kmSXlUFBhbeYbbl0ZP5stPSDk4jAr8sYtbuaZzI0cYNjxDx1SdkOoSNzoND7kLsmUf4SewK2F2E4WsxAvx9eQ/Csa+kmRDuMYFxECHvWMhS/e5a+XyCKhLjY8rADOUiFbqwImRy9CU0RGj3SxLM0EepcrGO4cB4W/uiQj6kpqWnY837aqnYXN6zMpm6pgkWj9szm3qXmTK3+ixjVj8eQA+A+e+3OgBmSk+9Jv+iWC34gRP9FOdRIHLeXkUy+cFBVgfm+DexzAeHQRyBfbTumCnWew5rKXynEIp8YBG3A9YfLM/C4XrvIOU2LQCpBX6HxtqtDm2ctOX4xtoB80Vc1YvAnxhyOx4fMu03l8u3ntBA8B9J/1Yhv1vcZ/AXgMm+m4kJsKOz/m/k+xvElgNtHIpEkupVZqgAzE2h8cJRcJAKdATygWl7eVTQq/BHKM2JccIfyx7b2Ap/ULHH4vmuaWzIvONW7aKDul8rAGaA//ZRxCl8Ugp68NxDEpRbWMCwfLVPMYx7Umd4+1+axyogDPg0qcfQIrznY3Qt/DNVogYWYRvKJR0uCZMLyAJs/9w/6Ek7FYD1hf5OIvAnNNUOXCgCf03IVPxLBP6RIvB7y9wz7eslQhEDzqzYrYD6PmbisAz8Qk3vUSbpe9vHeOvXmeQOHVA+VmTQtK9SKACIqneY/O7laqGAc9+7MZ9jZ8OrccIf/gw7x1oJbHGdxgWZ5gm7lSFRxs4M6Lbf7iPvz+kMWNAcr7Po8iIa/AfpgJ9v4MQ8BbsFiuyeYxzbvsj7LfoAdmkhVkuHbP0IFYD1uUQE/oGOKe8pAt+X160ITKyZzxFhuWPc+xDc2CUwIursp8sBf1fLwGh5H+GBEcP/hhT3rimD6sDZJ35Pf3QvP0yj0aOAm2Jj9svnOMNgWpzwh1LTCz4Daezzb10BME2v2+QLu1VnB3TPoXx9YpmXzoAkSOEP3xtYLKoKpEowP78g9dqZd6ftQQUgy4iAhJf5x1gOkFQd8z4E7Svy55BovH+N9Y/IeVj3H66CaS9E21MzfCzYvZCJIxxm8S/HCX/8Bk4HfFj9FcbFapsaTfBr+Wyp/r9aErYQzdJ6BoJrImPtFIDqHqsmd/yZ39+vqqmDEuNnSyCcAcvZ24lP4Q+r3mPG8y3B2HCLKpdYfoMAxhkAm8ek7Yznz3CCThRwbHddFqqG+CAvSf0G8y61LegEmBslYI0Izqny547q2f9WdOYsr1PlPQTpaYoKWuNtQ6qV//9LBS/WsI5SAR0tc7W8PwPWBfk7ZUAbdRj8LNGpfvLeOP0OBpRy+f9LqmzAsx9BhT7Xz+FQs7EqLYHSfo+v3mqqrVzrmHYZmbrk+1AC/mjMmr0DqAZ2XmAbTbVFXgzYLeGT2duJD7AX/y+SDhaltMGmABHSeIZgsofjG5yIKwO0BDwr5e9YKqcI0gJAglQCWk7yM97RwrvHBvuR99+Ql9669c7o92A12Eb/D8fBT6P/V4Ec0rLgtNfaQ471sEVQNGLy9zaeYyD+xjajMgQikr8xq4BXfBf5/0fwU9DlCCgIU7J1fVyn8W0rK4CpGimDUhe/vy+DGrZUPuCjCDoDEr998HNJtbbCX8tYK+lFSaMxphgv4M+SgKrYFxaKTCLNESoAZF1FYLWkyfLnchGsh+geerw/XV66QzHQdXd4sCLk7nA9chgm90ExRXXQhxv8KsXsH8If6/ybmHWDiSBU8dvqn7BW0te6tg9zH5zy5um5AKjLi1I/pEgWL42VI17YrQyHTPvTA6rDnT7yjtRjWgkpFIVimSRYtWABROyQ5gCKxZLDRby6VACIP0UAh/C8ZLwY/Ti4p7Pu84eQxQE+CN2LmT0C5eyo2vcHUcuBOuVBKcBJgnPl/fMwe4/uIMCWQklYNhhhPNM2Qvp+G/1MXnDMMUyFnxtvRwGEF/JivylOIYRZHZEBJ6ofQ3Y7otvxSdc0W8x8HDgDnhXQgAmly89paSezZ5MCVASWS0I48GHG5/knypWi7G7HK0sFgPi3BkCAwz9gkAhm7PPcUGfk0Nph2objTTTcLwL59Isx+UMJQLheCC0sB8CvABEEj1YFAkJ/nPoboLyPNeQwthbCqoBTAjfWWT+8jrF18Z/GOyTnGck3P1fXIjxyesQ1jZa7Aap7rZrccdeAquLHGXA0nQFJASsCeK5xWNcEn0VhDLmPR2JTASDBKQIIT4nwjjC/z9AZekitABvoLB1CHocO4VwBmPOxBz8aZwB+BHDqGw/HPpjsjedUVK9WASwZwAR4hJYDa8BAFfw4jhgOiPOw/x8xDILY3mcxl7/eLl85rABBBU1BUKC5lnmhvI1ijyYFrASs1D56h8+iMME4g1eUCgAJThGolzRXZ/QvqjKwTK0AXdUCACGO7T7DdPaOY4g3k1c46k2OK/JJ4+3xR1QvPPhYv0NAICwzLNe/UT7M/J8n2CWQYwWg3SuuabbaxhQ2VXsF5AyIazPWRxF0BiSFrgS4krBsdr3Poi7HuQq8osULTTiFqww06Kx8qQj4z3WWjvcWq0UAs/qWULz6/29MTHhhBUGGZuksH0GJpmV6WE8uwTJAU+3A5+SvwzPO61aFHaedCN+66wKoCkLGXmHsInC1OAPKAPsFezEpcC42XoCwEy3zQ+HGEbpn8VJSASDZUwYg2OfGvLVQE5iZIh+2/ywpprY6ph2OTz7cJmfYrT7HmBW+FQAR3ktFiCM+wm8sizhN0vnsuaTQLQHSz2GxwlJhjWUxp0gZN0pZc3lFiw8uAZACswJ8+L5rmqxOIBMFAOdjDw+oKn7OBzhe6tGed5MUgRKAZT+ckPi1ZRHt1ApAqAAQEgh323Xm9ogLcElAAyN2SPzHMjvMqofxNpIiUQJgJcShSbaOv8eKwtuHV5IKACG+cUzZXbaDUdhU7xuEM6Dix1OaMQFIMSkBcCy2tXrBCnAuryIVAEJ8Ex45/VvXNE2zygtnQFMW1Ol8iImwyDLv7qKIbM27SYoImPK/scx7ovT3TryEVAAICcAKEL7ZtkuH3eoxAc2KsOvibh9F0ApAiskKgGPKL7DMjkO0fsOrSAWAkCBUgCeNcevtrADVmwToDHiPpCbLvHQGJMXG48aLEGplBeDlowJAiG/CI6fXuSbytF2n7oCzBS4OaFaEYExPWmanMyApNisAfG9sHWmHiMK7Pa8iFQBC/NsArJcBWiID7hegM6Cf8wEYGZAUmxIw0YcV4AReQSoAhARhBfivayJfWeV1O5WJAhHIYCQD4hTjnZ9gwwhRRAbxbpIi4xrLfEdz2YsKACEBWQGcW+zywRmwKsitSX6sAHQGJMUGTim12RHQTdKBvHxUAAgJQgV4yFg64YXdTr0DdAZ8xHgHJ9lwnNSjA+8lKRaqaurwzN1jmZ27AfzTJRc/QgWAFDThkdO/NybyrF3nroBD4IUBDYhr5OUBy+w4yfEI3k1SZNxrqXwjGNdGvHy0ABASRDe1jssfdqt/EbAzoG24VC4DkGKzAmAJYIKlXDmWV9AX5VQACPGYZEzkWzsFoFOZdPPRAQ2Is+XlBcvsPysmZ0Cpa5gDKVErgA353A3QsQ1c9+4+8q6hAkDaDOGR02XWHbKKy++YMJwBzwuwOqVyPkB1G+k+HfkE+eIlY3dS4NaiRO6Spzq3awPXvZuPvA1UAEhb42+SIjYZy0ynTQN0BnxR0mzLvHAGrCiS613pI28hbQOragNtyN/Fq6nDM2fr+zI61/X1eR5BWQFdej8+FMupAJC2ZgVYaIz7kk3ekNsRRwWfH+CAaLslEM6ARxXJJe/lI2/3AmqH7UDaQYQJrQf/U75t+JVcw8oi6rc9Cuiab04LACHr4NxprUC41QcF6AyIGdEay7zFsgywiY+8fQuoHRu3kXbk0wowV16mWGTFMtIvi6jfblZAl72fj7xLqACQtshzxrhWx/N6zoDO8QENiIgH8Ihl9mGiiAwpgmu9lY+8gwrBiVDqgBmdH6VvCB+5H3nIMt8pRdRv++XBYpGo30IuD7bM3iTj0+J0v1zGfl06dL3qLgSjgXl2A0kb6t+VMcpgdI0d659v//CHU98rpPqHR06PNNcOhRPeVRnbDqSre86Aa24NqDp3+JjNI99ZBd5d/Ai/Ss3/QZ7bMNhnfjixjefI0cI/tc9nGtBqRyi8IpRm5Kie2/gZYiTtZFp2HeVd+bb1XZmXyZepALQd4b6DvAyNE+aV2pGq9O9y/ayd/o01zk6qEGygCgGc1D6V9LCUuUyUgNkF1tT7JF1hLKxXYdOpz6rJK3eTwej1AKwAM2Rgg1l0hEX2YyXvRRpcqFDx68G9XwEoAMMCaMO5HF1a+vty6bOICXBkgSu8fu/5/gWgAPzMR945VABKT/ifqNrrQZL6qyDvZuyXeAbog7DQ2Hu8Z8sKsLC5dlsZiJxRGed1K43jlJ9jjH8FIMYKYKMAdNaB9MFC7E8y0Pcy/kypAMcgX5PnpuzuMz+2sg0S4fcJR5kW/m6pAORE4ZXfwHO1nd9+K+X8Vo9Fzhf7+Mg7M5Mv0weg+IU/ZvcI13mlpAMwaOls3u+97SupuTBb7dxmrUC41QfLA94toIrYHpgSnRUVKkEc5rKDXOef5FGJgQNaTQBF8Tjn/4FdOIst8nW2VBwyZV+dCPkB3vd757Hftvf5+xmdWkoFoPhBdLmVknoG3RchaQu0zZONca2OCS4L1hkQitddltnhDDiiQK9vUIP1eXlsA6xhQUQBHC33qSuHmR/7+zjL7CcWUb89P8/91k8sg4z8tqgAFD9dAtB6E7GsUBvsRQa0PSa4HZYCxgRYHZyY1miZ9xYRLgW1DCf12UJe9gyouGOkvMF5aspJAZWDwfhiDjM/YrsbAKGwt8liv+2lwjMI9pLy9ijCfruaFoDSVACyIURWFbISoANRg03GsKnuIw/4bgHNirAt8R+W2WEiv6DArut5JjjLD8r5q1zrnFqSNATt7gEWeY6UOYBDTUt/nyYvn1lmPzOLVRsT8Dh4h5rjc9lvt4fy4aOIKXJ/Mlq2pQJQ/GBbTjYilsH5b2ahNto7Jth9wiqvWwVLwNkBVsfP1sKrCmUpQOrR1wTvmwBBfEaOm3JlwOVBEPxNrk87Q4DtMsCv1VEv6H7bMwvKBZZWr8jxdb3aZ/4XM81ABaD4id2/75c6SbOMZ9b++oc/nPpZYTfdsTwm2IESMCooZ0DRut+Wl6mW2TFrebJAZpiItJgNIXejtG/nHCkxR/mcRSUD28v+wuGmBdvYCNiK/Jss1OdW4+/simRcJP1pVI767eHGn/c/eJoKQOkBL3RsU1qQ4jsIDfmxpJdVe8deesSzv10Htd9LOlvTdapJXl3oDQ+PnC6C17XaolXmdobgPT7A6lznIy+2bb6Sx/VyDEDwdt8vS8XDGe/ZbCs5Uv5mxv6chnTAUsB5pT7giMKLOCHTLLOfEeSSkJR1jMnu+RqPBbVcmKINfXTS5Yd35b5k7BjNOADFD4Q6gpUg0AacbLqoRQDr4z8Yb4dAc4yVYLUqC9jjv0Bm+XXF3XwH2v/dmdsAynFIEGIC3BxQRZ6T9L7x1vVtQAzzqTIYHC0P8sQcC/89VRnMJhuoknOAtG96FtoA0/JTJvsHEcGa4UgbbqQVwGxvka+/znQnBnDP4etxb5bbWaHK62Fyz1/JUr99xngHhfnB6sRGx5B1aK4dCjPKwTZ514bmzqysWT4oH/XuetVdeLAQ+3xx2xDsad+vSmPcJdKVMz5mt9lZYRqchSOCiAyoDzPW8l/zWQwCkEC4/FHqlfV7KHX+ubxM0IHOD7WSRqbxPSikx0vbngqwDVjKecF4YVz9gHuH2V46llEInnNycY8KEZ21fmWZ/Tm5br/w+fvD9Z53ylG/xU4fWH/+GlSQIPVdmBBAv4XD9iZSrxVUAEpUASjxewaz7+k2snZt6MsnKmtWBmZClIcaOwIOD6AoDK5Ymhmv+6+DHsAh5LADAUs9freRYu8xtk1hOaZ3BjMWRFz7zmc7dpQXOIP2DeCywIKGpZB0w9bCFP5/0oY3SlQJQLuHWyq5W8p1m23xm44+67Dc+fVX+VLvOUJWb5mu8oL+IXX/0ue121VeHs/geUnFTVIfq9gF9AEgRUfDpH49GiZtvnv9pL4nyevVEVNnGbYWzoDVhwYYGRDAj+L7AMrBejZOHPxM6neBzhaCGrhh8ofj4nUmmBgSf5IBCDP7THYQwBnsC6nLpXpqX6Zt6C1prPz5VkDC/xlpA/xkLjHpx1OHTwOWbf6ZKyfHAuNxY/vgWSjsKjTfNF4I7iCcVW/Q8MQnmPQdqRFtdabU5WbdNZNpG/pLgvI7NSDhvxbtMD5uBKEFoACEev8+rmka4LTEoHfkwXI2Ff20l2OcDYwb6ip/Vzsm1EFEdlmQ3TZi6k196KtzZSC4Jagy1aP3HwFfIsya/iPpVR0EZ0idF6RZHwyWcDCEkx/OZ982wHrB72GHqFlUfgs7CU7L9PZLelbSvyVhOWZOIjOrlA0/iZH6fI4ywQXAcrUN7+vvYFY7xaJ85MfSxot6f9r08oAqbt9aTiThn9Q71fkAGiRroPF8Bo42dj4HyYDzdP/oPZLfwrkVF2c8fHjPI2QGlo8+jd+Hr8di99N+iz67d8By91r5zd9RAaACUGjXMdzsrOjnGnegCPF+3izN6a1CvbsI9S4i0CtljBWhHgrnsyvWh+bP7Vjz/eYBD46YnZ6a5apj8FqgFodEwgYxIrroAJQth991fCik3R10drODn8snab62C4NsZ7WIdM5SG+6TNpwUd/8ulJfrfemW3jIOljjWtOFHfWeT+RHBUWB6X57g/fZ6r/ub7GxLBcfIPX8sTtmAP8BuPp9H9NulqhR10X7bIUttwG8NlHasti2AuwBIJkK9vMlZJrN0Z4AnVBzp3I7MykI9HTfUTf7uLDN0EeohPMChsNupKNol9ey7anLdbkE5AypYR8a64p5ZrHqFDpL54v74ayb/X6sWkP8azynVhiqd+eUCRHJMNIO6QZUYW/8QCIDNNZHEbJen34U3/7i4ftukMSTQbzf18TxulcN2/J8f4U8FgJjG2q2qXadhoGvM1iLYtxAhDu9eCPUenlAPdZIZekcR7NDEQ2VulzZ3DcrcatPkfIdodYEpADqgHGE8U/I2bbDrYJ383CRtnyttx4mCk43/3QXZ5oREjohYgpA2jFZhMJwjRZvhB73nboJ7/q3ccxyDDufGQp+93CL1fclvIVwCWH+WW/RLAA2T+m8oLRngmogI9dAW3nq6s5H83cO4TnQ9vcIxZSLUHfYBKELOoqYmZ3lPeai+D7JcGVDkXrSYFtuSEgCT9jC5Vh+20nasez5bwEoAnBf/0EobYIrGQLsTn5KiB8sy+8s9f7GVe76z3vNCVQIwnuwr7Wj0WxAH//UVABwyc6xN3nrn65URZ023bGzbapy05aYR0wjT+1YyU+8b4yS3oTrJVamTXDveVpuRYa2pD80L1BkwZkBBkA84Be7ZBi4VBp1D5To9m2bboQRAqa4usHY8iuc8nT3d0gaYvZ43XjhgUrycLvd7bJr9FjsO4JRaaEdBQ+mG383yIAqjpFhfAbDcUy5CxFkjSsCC31XVrLk2jd8JNzsrt5BZOtbUsY67ueck5/QUQQ7P987yWmVMuL28lvFWZR9RAOZ0rPmhXzbKVk98RC08rYgvEYQ/gviMy7DtWEtHwJONC6QdT0pCxMWGDNqAA7ewLfMQPilFCWJO/CXDfjtYlYBC8eOYpjP/JUEVSKmyvmDGuuZN9jPJOtPsrJrkmLLXZTbeU2bmG7cIdTfUPcZJrlxew7zahUWTs8w0OotHBOwMGD+oQIAgilz3Irs88Mz/pVyb5yzbjTgG2Ddek+d24NqflumxqdoGjJdwGMRpg3x+i0dpxcz/Pst+200Vv/3y3I7nVWldEWShVADWVwAQGvVlXonSw8VCQGjOuKqa1b/KqiT1hCGsRKOL5NLgWOjDZfD5xGe74RmPc9v/ZHLvF1CP35Y23BXA/fupvGCpcCCfmoIG2+SOknv+H5/3G3ISESJhQajKcRtgpbpU0o3SjkjQhVMBWF8BgKlvBTX80qTBWdjU7KwI3BkwycCCMLZXGf/HgGYL+LIg5CrOJVgbYLv76GB6RI7GIAROOlFPsQuqDVjSwRn0cCLsyienwHR5L9T0eUGtles930gV92Nz1G+xG+GMbByeRQUgpRKw7UtyafbilSg9sIRTH5qfFWfAVmaUECZHmsLwmMcA+i/MPOQ6fJbFdmPHzCWqCJRnyXIBBevxoA5wSdCGKr132Ebam09Q3sEpg7+X+z0ti/0WPltYCjo6S88rBP4VQR6YRQUgMysABuLxvBKlSX3oq9kda5blPMCObjk7yHiHCWHHQGWOq4CwrljvRGS8z3PY7g10MD1UEk5U9HNGCUymz+kM8LlsmE2TtAEWw31ViTuQVoGcgjgO47TffpjDfovdIb/UfovDsPzE1UF8AuysuUfaMDVXbaACkFgBkBvpful55ZO2jyv/miOuiYjwiNQ1O8s/bXKWY837m3zVSEOTwjKA/eeImIYIY1tI2tAEE8ALe/kRqhYH4OA0P0RHm5YrgZmi3dh7jcA7OOt9sLZ7I233eo+q8WK6f6FtgMn0VT2YKJ9tgDIwxHhhZXHuAnwFsOzRy2QvtG2pUKf9FtaddyVNkvS2jVNnwPe8SvvsMO23Wxtv10uPJG2YKwlKNg7lwhLV1GxsH6cCYK8EwBHsUV6JYhXpkGPNTfK61jjNq0TEi4bd/J28yiw3Ml++8ZV89olrmmZV7LFoXjG1TYUkhEymsfExSMKbv8FvCNE8CdVqbTfGLQyWy7Nl2s+yoCiLaQtJD6zlry22A5bU8RXPa9SqtTbVAUhUAApHAZBr406VS8QwoAUj1JtdFep1xomslFcR6pElItS/UaE+R74zyzWNMyv2WLKIV4wQQqgA2CoBvUWofCKXqZpXI6tCvUFeRai7K+T1e3l3sQj3BfIqQj0yW/6eFTH1n3TcY+lyXjFCCKECkCslYDcRRLVyqXhwUpoi3VtPb64X4b3GdSIr5HWpvL9IBLnM1N258tlsef2s2Vn1aWXNirW8ZoQQQgWgUJWAA0RgPV26SgCEepNM1SMQ6qtUqH8n/18on8lMPSJCPSJCPfJJk7Nsdj6cWQghhFAByJYSMEwE3EQcj9s2WhTBTD3WSW6ZtBLr6RDqX8vncJL7zDUNM2WmPq/YnK0IIYRQAQhSCeghQnO8Y8I1hTlPT+gkB893zNK/VvP7pyLUP63Y47uFvKOEEEIFgGSkCGy7nwjSsY4p2yxHQj3WSe6HOCc5eL5/HjENH9NJjrQFVk2uQECdXxtvHz32/y+TNMN40QkftdnCqNuxDjZe4Bbs18aefPifiGLccr76nVLuTF59EmA/rtB+jAPAhkrqpn35LeMdjPXPfMcvoALgg6babXZ3TdPvRBEY4ZhwmiEhf3SSa1AnORHake9jnOS+lM++9JzkVs6srFlZxytNSmTA3NJ4Efx2TfE1xGz4jQyctRmUi8AsD0v6SarHWdJlkq7hchcJoC/vqX150xRfQ5jtY6S/vUcFoOiVgSH9XGft3iLetxfhjdlFhQjyVeokJ0I98qU6yX0hN7yRV4yQdQZMHIz0okkvhC6E9UHyHL2QRrmIpviq8YKxpMMdUu5ZvCPER1+GlQlB5NIJaY0J3gHS5yZRASCElOKACTM/Yrj3yiAbTmsckipcs5QLZeIj44VkzYSTpdx7eWeIRV9GCOh3JLXPIBuWBQbnI/Q497aXMM21Q7tGTP2ljnFEYw33dEwoDJ+DiFO/OmLq3ml2ll1VWbN6kkW57V3TcKZr3FPhJyHltnNbdh00NEScullNzoqb5O+/53v9ixQMN2Qo/AHWUy+WdHaK71xqIfzBdTKQj5P+uYq3hmTITRkKf4BDha4z3jHDtACQXAj/IcfIy/3GhJJ21ohpMI2hRS+JMnCEDIYr0it32+Ei7Cc4Jtw92XdEyTCNzpI5zc6KA4I8o50U5YwJJwF+azkZgdNr90SKpJSL44UXm8zPS4gCP4MHeYdIBn0ZPiy2p2hiWauX9LmluaxziLetFIX/tufKrX8klfD3Oke5aR/ZZO+QqXhTDzFpbea/l7y8nkr4e1pn2JS7vbYoc7u8J+UO5R0paQ429pZICPdkjn07+RD+gGeAkEzZy0dePAP75brCVABKTvgP3V1E8I2ZdJHySK/BIrTHtlLupjK3f0bKTrtPtXN7dAy5HSeKEsCzFkqXQT7z90nyfj+f5fIocJIp/fOcnwoASSmkccLhXSbDpR/HtDNht9MxIqi3Tv4t9xr5ZkWmdWrnboi139/y7pQsHXzmr8hSuR15a0iGtM/zs0AFgKRkmAjpATYZy9zOUBpOSaJYdJVyj7LrgO0lVZyu572T0sPvsc3fJXl/YZ7rRUoPv+v331MBINnEeo3KMeWwBIxM8jEitlnvKAm5FfDoHsjbU5L4DYIyI8n77/ss9yPeGpLjvjyNCgDJJlv6yey47ZKtUW3lrxPCYdv3mi0pTiZLWmmZ98Nke6flfUQM/MBHvZ7jrSEZ8oqk1ZZ5saPlDSoAJJv4XaNK5jsQxNoVt6SWIBrX/07L7Le08vl1luVOkXpN490hFn35fsvsiECZ87DvVABKi8X+RHQk2XrrEj/FIi6A8b9+RoqXP0n6IsM8bxsvvn8qxkt6KcNycUAQQwETW66QtCDDPLMlXZuPylIBKC18rItG5F/9W0k+fNdPpaRcvHzI21OyMydE3MMe6PlpZkGwlUMkX1Mr5eJQnyONd/paOqAjHiX52BeJbV/+XvtyupMiLFXtm6+ok1QASosJLRNuC5ocLNO69ydXLFxLr2vXRJw178gDwKOMS3vghAVgB+OdoJasj8JUdJ+kXdKNm679ag9Jf9bZfTLelDRcvj+Bd4P47MtwTEWAqidTDnzegUE/1b6fF7juWmI01277sNz2X2c6R18bmveGaxp2S3ZUanPt0PONF9M9s/o4K0yDs3CUlPsM7w4BqyZXIAjPQZKwZRWn+GHpCUenTpB+sshHudhtgsiD20hCtEpYEGZJeplr/iRLfRnOzftrn2uvfflz7csL810/KgAlpwAM7SvK50y59Wk77omAXi6Ceqh02K9SlFsh5cog7Wya/ty/2dSH5k2srFmxH+8MIYTkFi4BlBjhkdPnipA+Od2Zf6OzeIEI/5+mEv5abp2UK4LcTcuUD+Hf4Hz7nmsaD+NdIYQQKgAkN0rAwyKCfy0Cfk3SGb2zqqHe+eaOJmdZ/3TXqKTcj0UJGOyaptdSWiGc1U0NoQU3RJw1w6TsNbwjhBCSe7gEUMI01w6tjpiG4+Svw4zj9nJNpFFm5HMjpu4JUQCe9LMvVcruHzFrzxBFY1cpu7Nr8K9xnpT972Zn5QNS9kreAUIIIYQQQgghhBBCCCGEEEIIIYQQQgghhBBCCCGEEEIIaQ1uAySEELIeZ55xDkIx94p7G6HAcdDNrDv+emtjhuVtIi9bahlTJL+bZj6Ehu6f4KMfJH0h5awOsM0I2btBgo9QV5zyN0d+L5JGOdvJS5e4t3GWxWK9dpEMrv9M+f6iVr5bJS8/lbRKvpv24Wxl7OaEEEIScLGk45N8tkKEDg6z+b0InB/SLO8e48XFBwdIej7NfIdLujnJZw1Sj+fk9UKpx+wA2oyjqQ9O8fnX8nsXy2892ko5t0jaPcln30kZ98rrlVLO2jSu/yuS9mrl93DY1dmSpkvaLt3GMhIgIYSQVCyV9JqmN3QmjEOaTpM0SYRZq+eKyHcGxgh/cL5FPepj6jHFeAc5lUs6RNJb8hubBtjmOZJu1XSbpCeMd5APrBGPyG/tnWY5C2Lq/B+1nsDC8DtJT0k56Vjhfy7fO7IVq8UZNo2kBYAQQkgqpspMdVSc0DkGglDSUEnH6ew+FVGB/7zOZkdKGTtIue9lUI+F8v2auHrsLC8vqVC9VNIpAbV5hvzWmLjf6iwvMyVtJOlI/d3W+GdsOVIGJt0XSrpW0r6S9pE0MY1ybpa8L0hZiSKo3i4pbNNIWgAIIYRkhJrA39D/7tTK7L+nvESPIIeQHu/DChBfj//Ky0P6352z3GYcdDZX/9tgWQbW/q+X9HU61y6GjSX9McG1PUpeamzbRAWAEEKIDVHnu9aWAM6S1F4tCe8bz6wOjhQB1ieAeqzS1/YBtq2j1K1vTBoiCQJ4F/38Hz4UCTeDawemGs8JcYzUYVCM8K+Ulxv0v/+mAkAIISTrqIf6CP3vJym+11FeTtX/3q4CEF7qWA+H2focn/WAp310ffzjAJuIZYovY9KHkq4w3s65G6UNk3zUGc6BW+t/P0ojC5ZJxhpvyf6OmPcvMZ5PwouSnrSpC30ACCGEpGKACK3L9e92kvpKGqWzVzgI3p8i728kdTeeM1yskIIVYJikk6Xsq0SgLkujHp3ku2NiZs6bSzrQeGvyzTGz4SBYGiecMVneTBIsFudLPb6TOl+bRjm7xFw7WCiwDTK6ywCOhk+lWR8snWA3xB5S3i/l9R1JFxhvKQIWll2pABBCCAkazFYvS/A+ZtzHJdujrg5vUYGNo8Xvk/fiZQ/2r59svHXx1uhqEm8HnC/pNKnHWwG2OZHjo6PtuUnSn+T/D8p3FrZSzs4msW/Cm5KOlfxpHbmOrZbyexD4D+nvQznBDoir5bNZ8hkVAEIIIYHzmaTH9W/MtLEdDmb8d1sJ5gMBGg3g098kDuYDzhYBdouU1ZpjHeINXBnz/zO0zDcl73PZvghoq9RznApgLF9gPb41BQBOilEvfwROwjbAN6Qsm+UK7Lo40XjxBWD1mGe8/f/WUAEghBCSik9FYF1ukS/q5Q/l4boEn8OJrVYSIgTCm/3hVspbIfW4JWZG/qbOpI+Sv5+Vzx7J5kWQ34AJP9Zn4bs0sr1lee2SKSCnGy/YD2T3ufLeGioAhBBCCgYRVFjfH67/vVYE1fQk33tMXkZLulD+fiTd8MAqEN+WPLAIwDnvr/L36/LeVwE1AWvtH8T8H8IfDndV+v/n5bc+zPV1ld/8ROp1Juoifz/ptzzuAiCEEBI00dn/lGTCX7lNX4eY1sPdJuJqzLKNF5nwIfU7CAKUNzQmYdcDHA+hFCCK36H5urByPe+W9IcgynJc12VXJYQQQkoMWgAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCqAAQQgghhAoAIYQQQqgAEEIIIYQKACGEEEKoABBCCCGECgAhhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCCFUAAghhBBCBYAQQgghVAAIIYQQQgWAEEIIIVQACCGEEEIFgBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCKECQAghhBAqAIQQQgihAkAIIYQQKgCEEEIIoQJACCGEECoAhBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGEUAEghBBCCBUAQgghhFABIIQQQggVAEIIIYRQASCEEEIIFQBCCCGECgAhhBBCqAAQQgghpK3y/wIMANK+mcUAtSxJAAAAAElFTkSuQmCC', 'number'=>'22 xx xx xx'],
            'masrafi' => ['name'=>'مصرفي — Masrvi', 'icon'=>'data:image/jpeg;base64,/9j/4AAQSkZJRgABAQAAAQABAAD/2wCEAAkGBxEHBhUTBxEVFhUVGRkZFhgYExcYGBsiFxcfGBYXGxkaHyggGiAlHxUXJTEhJSkrLjEuGB8zODUsOCgtMisBCgoKDg0OGhAQGzclHyUtLSsuKy0tNy01Li0tNS0tLi8tKy0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS0tLS01Lf/AABEIAKkBKgMBEQACEQEDEQH/xAAbAAEAAwEBAQEAAAAAAAAAAAAABAUGAwIBB//EAEAQAAIBAwIEAgcGAgcJAAAAAAABAgMEEQUhBhIxQRNRFCJhcYGRsQcjMkJSoTWCFjNidIOzwTdDU2NytNHw8f/EABoBAQACAwEAAAAAAAAAAAAAAAABAwIFBgT/xAAzEQEAAgIBAwIFAwIEBwAAAAAAAQIDEQQFEiETMQYyQVFxFiJhM8E0UqGxFBUkQ2OBkf/aAAwDAQACEQMRAD8A/cQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAABUcRalPTbeLoJNyeMvojOkRM+Wq6tzMnGxRbHHmZd9CvpahYKdVYeWvZt3IvGpXdN5N+Rgi941KwMXvAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHCvdwt1mvNL3smKzKjLycWL57adYTU4pw3T6ELa2i0bj2JzVODc3hLdgtaKxMz7Qzl9xLQqZi6bqR9yx+5bGP+XPZ+vYN9sV7oSNK4go15qnCLh2imkl7lgWxz7r+H1nBltGPXb9l6VN4qdU12np10oVYybay8dkzOtNxtquZ1XHxckY7Rva1TzEwbSJ3G3JXUJVOVTjlds7k9sqY5OKbdsWjarveJKNtPEcza/T0+b2M4xzLWcjrmDFPbX90/wj0uLKUp/eQkvbs/oT6Tz0+IsUzq1Zhd2t3C7pc1vJNFcxMN3g5OPPXupO4dskLlHe8TUreq4wTm1s2sY+bLIxzLScnruHFaa1ju19ny04opV6iVROGe7xj9iZxyxwdew5LdtomF6nlbFTexMTG4fQkAAAAAAAAAAAAAAAAAAAAAAAZ/iXWXZNU7X8bWW/JP8A1Lcdd+ZaDrHUrYNYsXzSo7jR6/obrXXbdptuWPP2GffG9NPl6TyJwzmyT599L/hO89I0/kk94bfDt/77CvJGp23fQuT6mDsn3q98W1XT0hqP5ml/q/oMceVnXMk04s6+qu4T02ncW8qlxFSecJNZW3V4+Jlkn6Nf0Hh47Y5yWjc71Cv4pto2WpL0ZcuYqWF2eX0+RljncPD1zFXDyImka8bba2n4ltFvvFP5oon3djht3Y6z/EMZxh/F/wCRfVl+P5XH9e/xcfiG1pf1S9y+hRPu7LH8kfhgNWt/R9alC323WN/1Jd/iX1n9rheoYuznTSnjcx/q1Wn8PUbWmvFipy7t9PgiqbzLquL0rBgrHjc/eXu+0GhdUWowUX2cVj9u5EWmFnI6dgzUmJrqfvDN8PV5WGteHLo24yXbK6P9i63mu3L9MyX43N9GfaZ01+o1HS0+pKPVRk18iivu6/lW7cN5/iWS4TsoXd3L0iPNypNJ9N33Lsk6hynQcFMuW03jeoSOLNOp20ITt4qOXhpdOmVt8yMc7err3Ex0pXJSNfRecO13X0iDn13XyeDC8eW36TlnJxazPv7LMwbIAAAAAAAAAAAAAAAAAAAAAAzdTV68eIPCUfU5ksY3x+rJbER2tBfmcqOb6cR+3f2+n32r+LqEqOqRqLo0se+PYyxz401/XsNqZ65o9vH+jS2F1DVLDK7rEl5bboqtGpdDxORTl4Nx+JZWwqvQ9bca34c8r93WMi75quYw3/5dzZrb5Z/2XfE+LvRm6LTw1LZ9uj+pXSJi3luer2pn4kzSd61KNwdeRVtKnNpNPK9qf/wyyV+ry9A5VIx2xWnU72r+MaqqakuR5xBJ/NmWONQ8HX8lb8iO2d+GwsViyhn9MfoUT7uu439Gn4hjuMP4v/JH6svx/K5Hr3+Lj8Q2dOrHw1uui7lExO3XY8tOyPP0YnWpJ8SvH6ofRF1Y/a43qNonqO4n61bjxY+a+ZTqXa+rT7vFa5hRpuVSSSXtJ7ZYX5OKlZtNoYjS5emcRqa2Tm5fAunxXTjOHaM3UPU+m5lrtXqJ6ZU3X4Jd/YU1idus5uWk4Lxv6Sz3BclG5qcz/KvqyzJG3PfD161vfc/SHbjO7jOnCEGm88z+WF9Rjhf8QcmlqVx1nc72teGabp6NDm75fzexXefLa9IpNOJXf5Wpi2YAAAAAAAAAAAAAAAAAAAAABmql1dLiHlinyc2Mcu3L55LY7e1z9783/jdR8n9l3qFnG/tXCt36PyfZoridS3PIwUz0mlmS0t1NH1tU59JNJrs89JIunVquT4kZODzYw/Sf9mi1jRYamk2+WS6PH7MrraYdHzunYuXH7vE/dT/0SmulWPyZl6rU/p2P875/RKf/ABY/Jj1UfpyP87ta8J8lZO5qJpdkuonJK3D8P46X7r2206WI7FToYjUaYjjD+MfyR+rL8fyuL6/55cfiHm/0enplup6nd0qUZPCdSagm2s4Tk0s4T29gra1p1WNvbX4f3ET3pi4Sm+lWPyZj6kp/Tsb33ol9otPTpQV/d0abqPEFOai5Pyjl7vdbLzMq2tb2jaf09/5ExcIyzvVXyZj6h+nfvd0q8JdPBq+/K/8ABHqSst8PY/HbaYc3wlN/71fJk+orn4e3/wBx7XCL8P8Ard/+l4+pHqMo+HaRXXfO3224TxVzc1MryS6/FicjLD8P4627r2208IKnBKCwlsit0NaxWNQVKipU3Ko0klltvCSXVt9gkpVI1qalSaaaymnlNPo011A9AAAAAAAAAAAAAAAAAAABWa/fy06zUqKy20t+ntMqREz5a/qPJyYMXdjjcqenxc0vvaXykWenDS1+Ibx4vjeLjiudSOLanhvu3n9ifTiPdGTrubJHbip5SNB0upUu/H1HOfyp9ffjt7jG9vpD1dM6fl9T/iOR830aYqdCAAAFLquq1dOrvmo80H+GSf7MzrETDVczmZ+Pb9tO6Gfp0auu6rzVYtRysvGyS7Z8yzcVjUNDTjcjncqMmSuo/tD79qWiLiG0tLVvHiV5qL8pRs68oN+zmjHPsMuNk9O02h2URERp7+yfXpavwwqV/lXFrLwKqfX1Not/BYb84yHLxxW/dHtPlLEfaVVeqcR21xl+HC7jbUd9n4UouvU+NTMP8L2nr4mq1tX+Nj9U1vV61ne0qOmWzrVKqm8yn4dKEYYy51FGTWXJJJRbe/kayKxMTMyIGi8Wu74jqWOrUPAuYR54qNTxadSO3rQnyxffo4rv5MsnDMU9SPYR7Di+trmo3FPhy0hUhbTdOdStcuipSWU1CMaVRtbdXgXw9kVm0+49atxlPTuGHeO0ly05yhXpyqKNSDjU8J8uIuM1nfOVlNPvsx4e+8UifcetN4mvNUdKpZ6bL0esswqTuacZJOPNGc6ST5YvbdNvder2IvjiszEz5HXhPi+Ov3te3uaToXNvLFWk5c6xnCnCeFzR+C6rzROTDNYi30kcOKNYVzpN/D0ZVqNvBxr/AHzpuWaTqVYQxB7xhKDzlbyx1Qx0nur590Jf2eV7e44Nt5aRCUKXK1GM5c0lyyaknLvunuM9bVyTFvdLRlQAAAAAAAAAAAAAAAAAACNe3dO1UVc59duMUoyllqLm1hJ/lhJ/AeUTG0elbWt5SU6MKclJJppLdNZXT2NE7lTbjYbe9Y/+I9jqFl6jtHFeJycn3bi34kXKm91spKEsN7ZWOuxMxZlTDjp8tYS4atRqSapT5mnNNRjJv7t8s9kuibxkjUrUi2uYXVPmt3lKUo536wk4SW/k4tfAjWh2AAAPmAGAM/xL/G9O/vM/+zuCzH8tvx/eEMRxXTuOEOP/AB9ChzLUoOly/lVfpCb9mXGXu8Q9WGa5MXbafl8/+h8+1DTY6Ppmk0qOeSlcU4uT6t7Nyk/OXLJt+eTLh27rX39YlK54z4iuqfHFnp2nVVbwrpynW5IyntzepDnTin6mOj3mvjRhxVnHa8+8CmtKXo/2404ekTryjbNSlUdNzT5ZPlfhxils08Y/Mejf/Rz+RMvOE1c1q1/wHeytazlUVaDw6Mp05SVRTi88j5k3vzJZykslFM3iKXjcCBqXElXin7ELi4voKM8qD5U1GXLWh6yT6dce9MspSuPk1ivsN9wHvwTZf3el/lo82f8AqW/Iw/2iQqcJccW2qadTc1V+4rwj1m3HEF75JL40ono48xkx2x2/MDU3mmy0r7OLmFw81Xb16laX6qlSEp1X7uaTx5JJFGO28sfmBw+x3/Z3bf4n+dMs5v8AXsmW0PKgAAAAAAAAAAAAAAAAAAEHVNNjqUYKrj1JOWHFSi805U2pJ9Vio/kiYnQj6Voy065coSk14dOHrSy5OEeWVWTxvOUY003/AMtdBM7EW24VpW9l4cZzxyU4JpRTTpJqnV6Y8RNxfN/YhtsTN5kSrXRVZ3bnazab5ljCaxJp496aeH/aeU9iJnYmafZqxouMG2nOpPfGc1KkqjW3k5P4ETOxKAAAAADlVt4VqkZVYxbg+aDaTcW4uLcX2fLKSyuzYCtbwrzi60IycHzQbSbi8OPNHPR4lJZXZsCLrWj0Nd090dVpqpTljKba3XRpppxa808kxaazuByvOH7XULKFLVKMa8Yfh8ZKpJe3mlvn29RFpjzA6Wuh2tnODtLajB0k403GlFOKlvJRaW2e/nkd0jhe8L2N9cSneWlCcp455OlHM8dOfb1vjkd0x4EutpdCvp/gVqFN0cJeE6cXTwnlLkxjCaXbsNzvY721vC1t4wtoxjCKUYxikoxSWEklskvIgebq0p3kErqEZKMozSkk8Sg+aElnumk0wPdxQjc28oXEVKEk4yjJJxkmsNNPZpp9B7ew52FjS061VPT6cKdOOcQhFRisvLxFbLLbfxJmZnzIkEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAP/2Q==', 'number'=>'22 xx xx xx'],
        ];
        $pm = $pmConfig[$booking['payment_method']] ?? null;
    ?>
    <?php if ($pm): ?>
    <div class="card border-0 shadow mt-3" style="border-radius:16px;overflow:hidden;">
      <div class="card-header py-3" style="background:#0a4f3a;color:#fff;">
        <h6 class="mb-0"><i class="fa fa-money-bill-wave me-2"></i>إكمال الدفع</h6>
      </div>
      <div class="card-body p-4">
        <div class="alert mb-3 py-3" style="border-radius:12px;border:2px solid #2db37e;background:#f0fdf8;">
          <div class="d-flex align-items-center gap-3">
            <img src="<?= htmlspecialchars($pm['icon']) ?>" alt="<?= htmlspecialchars($pm['name']) ?>" style="width:90px;height:54px;object-fit:contain;">
            <div class="flex-grow-1">
              <div class="fw-bold text-success mb-1"><?= $pm['name'] ?></div>
              <div class="text-muted small mb-2">حوّل المبلغ <strong><?= number_format($booking['total_price']) ?> أوقية</strong> إلى:</div>
              <div class="d-flex align-items-center gap-2 flex-wrap">
                <span class="fw-bold fs-5 text-dark" id="pay-number" style="letter-spacing:2px;direction:ltr;"><?= $pm['number'] ?></span>
                <button type="button" class="btn btn-sm btn-outline-success rounded-pill" onclick="copyPayNumber()">
                  <i class="fa fa-copy me-1"></i>نسخ
                </button>
                <span id="copy-ok" class="text-success small" style="display:none;"><i class="fa fa-check me-1"></i>تم</span>
              </div>
            </div>
          </div>
        </div>

        <form method="POST" enctype="multipart/form-data" action="upload-receipt.php">
          <input type="hidden" name="booking_ref" value="<?= htmlspecialchars($booking['booking_ref']) ?>">
          <label class="form-label fw-bold"><i class="fa fa-upload ms-1 text-success"></i> رفع وصل الدفع</label>
          <div class="upload-area-check" id="ua-check" onclick="document.getElementById('rc-file').click()">
            <i class="fa fa-cloud-upload-alt fa-2x text-success mb-2"></i>
            <div class="fw-bold">اضغط لرفع لقطة الشاشة من وصل الدفع</div>
            <div class="text-muted small">PNG، JPG، JPEG — حتى 5MB</div>
            <div id="rc-chosen" class="mt-2 text-success small fw-bold" style="display:none;"></div>
          </div>
          <input type="file" name="payment_receipt" id="rc-file" accept="image/*" style="display:none;"
                 onchange="showRcFile(this)">
          <button type="submit" class="btn w-100 mt-3 fw-bold py-2"
                  style="background:#1a7a58;color:#fff;border-radius:10px;">
            <i class="fa fa-paper-plane me-2"></i>إرسال وصل الدفع
          </button>
        </form>
      </div>
    </div>
    <?php endif; ?>
    <?php endif; ?>

    <div class="d-flex justify-content-center gap-2 mt-3 flex-wrap no-print">
      <?php if (!empty($booking['cancelled'])): ?>
      <button class="btn btn-danger rounded-pill px-4 fw-bold" disabled style="opacity:.8;cursor:not-allowed;">
        <i class="fa fa-ban me-2"></i>تمت الإقالة — لا يمكن الطباعة
      </button>
      <?php elseif ($booking['status'] === 'confirmed' && empty($booking['travelled'])): ?>
      <button onclick="printTicket()" class="btn btn-success rounded-pill px-4 fw-bold">
        <i class="fa fa-print me-2"></i>طباعة التذكرة
      </button>
      <?php elseif ($booking['status'] === 'confirmed' && !empty($booking['travelled'])): ?>
      <button class="btn btn-danger rounded-pill px-4 fw-bold" disabled style="opacity:.7;cursor:not-allowed;">
        <i class="fa fa-ban me-2"></i>تم السفر — لا يمكن الطباعة
      </button>
      <?php else: ?>
      <button class="btn btn-outline-secondary rounded-pill px-4 fw-bold" disabled style="opacity:.5;cursor:not-allowed;" title="الطباعة متاحة للحجوزات المؤكدة فقط">
        <i class="fa fa-print me-2"></i>طباعة
      </button>
      <?php endif; ?>
      <a href="index.php" class="btn btn-outline-success rounded-pill px-4 fw-bold">
        <i class="fa fa-home me-2"></i>الصفحة الرئيسية
      </a>
    </div>
  </div>
  <?php endif; ?>
</div>
<script>
function copyPayNumber() {
    var num = document.getElementById('pay-number').textContent;
    navigator.clipboard.writeText(num.replace(/\s/g, '')).then(function(){
        var el = document.getElementById('copy-ok');
        el.style.display = '';
        setTimeout(function(){ el.style.display = 'none'; }, 2000);
    });
}
function showRcFile(input) {
    if (input.files && input.files[0]) {
        var area = document.getElementById('ua-check');
        area.style.background = '#e8f8f2';
        area.style.borderStyle = 'solid';
        var fc = document.getElementById('rc-chosen');
        fc.style.display = '';
        fc.innerHTML = '<i class="fa fa-check-circle me-1"></i>' + input.files[0].name;
    }
}
function printTicket() {
    var ticketHtml = document.querySelector('.ticket-print').innerHTML;
    var win = window.open('', '_blank', 'width=900,height=700');
    win.document.write(`<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>طباعة التذكرة</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.2/css/bootstrap.min.css">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
<style>
:root {
    --green-dark:#0a4f3a;
    --green-mid:#1a7a58;
    --green-light:#2db37e;
    --gold:#c8a227;
}
@page {
    size: A4;
    margin: 0 !important;
}
* {
    -webkit-print-color-adjust: exact !important;
    print-color-adjust: exact !important;
    color-adjust: exact !important;
}
html, body {
    width: 100% !important;
    height: auto !important;
    margin: 0 !important;
    padding: 0 !important;
    background: #fff !important;
    font-family: 'Segoe UI', Tahoma, sans-serif !important;
}
body {
    padding: 15mm 10mm !important;
    display: flex !important;
    justify-content: center !important;
    align-items: flex-start !important;
}
.ticket-print {
    width: 100% !important;
    max-width: 560px !important;
}
.ticket-box {
    background: #fff !important;
    color: #333 !important;
    border-radius: 16px !important;
    border: 2px solid var(--green-mid) !important;
    overflow: hidden !important;
    box-shadow: 0 4px 16px rgba(0,0,0,.1) !important;
    page-break-inside: avoid !important;
}
.ticket-header {
    background: linear-gradient(135deg, var(--green-dark), var(--green-mid)) !important;
    color: #fff !important;
    padding: 1.8rem 1.5rem !important;
}
.ticket-company {
    font-size: 1rem !important;
    font-weight: 700 !important;
    margin-bottom: 1rem !important;
    display: flex !important;
    align-items: center !important;
    justify-content: center !important;
    gap: 8px !important;
}
.ticket-company i { color: var(--gold) !important; }
.ticket-ref {
    font-size: 1.8rem !important;
    font-weight: 800 !important;
    letter-spacing: 2px !important;
    color: var(--gold) !important;
    margin-bottom: 0.5rem !important;
}
.ticket-body { padding: 2rem 1.5rem !important; background: #fff !important; }
.passenger-section {
    background: #f8f9fa !important;
    padding: 1.2rem !important;
    border-radius: 10px !important;
    border-right: 4px solid var(--green-mid) !important;
    margin-bottom: 1.5rem !important;
}
.passenger-label { font-size: 0.75rem !important; color: #999 !important; text-transform: uppercase !important; margin-bottom: 0.5rem !important; }
.passenger-name { font-weight: 700 !important; font-size: 1.05rem !important; color: var(--green-dark) !important; margin-bottom: 0.8rem !important; }
.passenger-details { display: flex !important; gap: 1.5rem !important; font-size: 0.9rem !important; color: #666 !important; }
.passenger-detail-item { flex: 1 !important; }
.passenger-detail-label { color: #999 !important; font-size: 0.75rem !important; margin-bottom: 0.25rem !important; }
.passenger-detail-value { font-weight: 600 !important; }
.route-section {
    display: flex !important;
    align-items: center !important;
    justify-content: space-between !important;
    padding: 1.5rem 0 !important;
    border-bottom: 2px solid #f0f0f0 !important;
    margin-bottom: 1.5rem !important;
}
.city-box { flex: 1 !important; text-align: center !important; }
.city-name { font-size: 1.3rem !important; font-weight: 700 !important; color: var(--green-dark) !important; margin-bottom: 0.25rem !important; }
.city-time { font-size: .85rem !important; color: #666 !important; }
.route-arrow { font-size: 2rem !important; font-weight: 800 !important; margin: 0 1.5rem !important; color: var(--green-mid) !important; opacity: .7 !important; }
.ticket-info-row {
    display: flex !important;
    justify-content: space-around !important;
    gap: 1rem !important;
    padding: 1.5rem 0 !important;
    text-align: center !important;
    border-top: 1px solid #f0f0f0 !important;
}
.ticket-info-item { flex: 1 !important; }
.ticket-info-label { font-size: .75rem !important; color: #999 !important; text-transform: uppercase !important; margin-bottom: 0.5rem !important; }
.ticket-info-value { font-size: 1.1rem !important; font-weight: 700 !important; color: var(--green-dark) !important; }
.no-print, form, .btn, a.btn { display: none !important; }
</style>
</head>
<body>
<div class="ticket-print">${ticketHtml}</div>
<script>
    window.onload = function() {
        setTimeout(function() {
            window.print();
            window.onafterprint = function() { window.close(); };
        }, 400);
    };
<\/script>
</body>
</html>`);
    win.document.close();
}
</script>
</body>
</html>
