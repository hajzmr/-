<?php
// ============================================================
// db.php — ملف اتصال قاعدة البيانات MySQL
// مشروع: نقل موريتانيا - InfinityFree
// ============================================================

define('DB_HOST', 'sql107.infinityfree.com');
define('DB_NAME', 'if0_42227695_transport_mauritanie');
define('DB_USER', 'if0_42227695');
define('DB_PASS', 'ya31121976ya');   // ✏️ غيّر هذا فقط
define('DB_CHARSET', 'utf8mb4');

function getDB() {
    static $conn = null;
    if ($conn === null) {
        $dsn = 'mysql:host=' . DB_HOST
             . ';dbname=' . DB_NAME
             . ';charset=' . DB_CHARSET;

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
        ];

        try {
            $conn = new PDO($dsn, DB_USER, DB_PASS, $options);
        } catch (PDOException $e) {
            die(json_encode([
                'error'   => 'فشل الاتصال بقاعدة البيانات',
                'message' => $e->getMessage(),
            ], JSON_UNESCAPED_UNICODE));
        }
    }
    return $conn;
}
?>
