<?php
// =============================================
// دوال مساعدة عامة
// =============================================

session_start();

/**
 * توليد رقم تذكرة تسلسلي فريد لكل شركة.
 *
 * الصيغة: XXX-000001
 *   XXX  = أول 3 أحرف من اسم ممثل الشركة (بالأحرف اللاتينية الكبيرة)
 *   000001 = رقم تسلسلي يزداد بشكل مستقل لكل شركة
 *
 * @param string $repPrefix  أول 3 أحرف من اسم الممثل (يُمرَّر من process-booking.php)
 * @param int    $companyId  معرّف الشركة لضمان تسلسل منفصل لكل شركة
 * @return string
 */
function generateBookingRef(string $repPrefix = 'MRT', int $companyId = 0): string {
    // تنظيف البادئة: 3 أحرف لاتينية كبيرة فقط
    $prefix = strtoupper(preg_replace('/[^A-Za-z]/', '', $repPrefix));
    $prefix = str_pad(substr($prefix, 0, 3), 3, 'X');   // إكمال بـ X إن كانت أقل من 3

    if ($companyId > 0) {
        try {
            $db   = getDB();
            // حساب عدد التذاكر الحالية لهذه الشركة ثم الزيادة بمقدار 1
            $stmt = $db->prepare(
                "SELECT COUNT(*) FROM bookings b
                 JOIN routes r ON r.id = b.route_id
                 WHERE r.company_id = ?"
            );
            $stmt->execute([$companyId]);
            $seq = (int)$stmt->fetchColumn() + 1;
            return $prefix . '-' . str_pad($seq, 6, '0', STR_PAD_LEFT);
        } catch (Exception $e) {
            // fallback إن فشل الاستعلام
        }
    }

    // fallback: رقم عشوائي (لا ينبغي الوصول إليه في الحالة الطبيعية)
    return $prefix . '-' . strtoupper(substr(md5(uniqid(rand(), true)), 0, 8));
}

function isAdminLoggedIn() {
    return isset($_SESSION['admin_id']) && !empty($_SESSION['admin_id']);
}

// التحقق من الدور: admin أو supervisor أو staff
function isAdmin() {
    return ($_SESSION['admin_role'] ?? '') === 'admin';
}

function isSupervisor() {
    $role = $_SESSION['admin_role'] ?? '';
    return $role === 'admin' || $role === 'supervisor';
}

// ممثل الشركة: عرض فقط، مقيّد بشركته
function isCompanyRep() {
    return ($_SESSION['admin_role'] ?? '') === 'company_rep';
}

// يُعيد company_id للمستخدم الحالي (لممثل الشركة)
function getSessionCompanyId() {
    return isset($_SESSION['admin_company_id']) ? (int)$_SESSION['admin_company_id'] : null;
}

function requireAdmin() {
    if (!isAdminLoggedIn()) {
        $script = $_SERVER['SCRIPT_FILENAME'] ?? '';
        if (strpos($script, '/admin/') !== false) {
            header('Location: login.php');
        } else {
            header('Location: admin/login.php');
        }
        exit;
    }
}

// يمنع ممثل الشركة من الوصول إلى صفحات الإدارة الكاملة
function requireAdminOrSupervisor() {
    requireAdmin();
    if (isCompanyRep()) {
        header('Location: bookings.php');
        exit;
    }
}

// يقصر الوصول على المدير العام فقط (مثال: إدارة المستخدمين)
function requireAdminOnly() {
    requireAdmin();
    if (!isAdmin()) {
        $script = $_SERVER['SCRIPT_FILENAME'] ?? '';
        if (strpos($script, '/admin/') !== false) {
            header('Location: dashboard.php');
        } else {
            header('Location: admin/dashboard.php');
        }
        exit;
    }
}

// يمنع ممثل الشركة من الوصول إلى ميزات لا علاقة لها بشركته (مثل رسائل اتصل بنا)
function blockCompanyRep() {
    requireAdmin();
    if (isCompanyRep()) {
        header('Location: bookings.php');
        exit;
    }
}

/**
 * تحويل أول N حروف من اسم عربي إلى حروف لاتينية كبيرة
 * لاستخدامها كبادئة في رقم التذكرة.
 */
function transliterateArabicPrefix(string $name, int $len = 3): string {
    $map = [
        'أ'=>'A','ا'=>'A','إ'=>'I','آ'=>'A','ب'=>'B','ت'=>'T','ث'=>'TH',
        'ج'=>'J','ح'=>'H','خ'=>'KH','د'=>'D','ذ'=>'DH','ر'=>'R','ز'=>'Z',
        'س'=>'S','ش'=>'SH','ص'=>'S','ض'=>'D','ط'=>'T','ظ'=>'Z','ع'=>'A',
        'غ'=>'GH','ف'=>'F','ق'=>'Q','ك'=>'K','ل'=>'L','م'=>'M','ن'=>'N',
        'ه'=>'H','و'=>'W','ي'=>'Y','ى'=>'A','ة'=>'H','ء'=>'',
    ];
    preg_match_all('/./u', $name, $chars);
    $result = '';
    foreach ($chars[0] as $ch) {
        $result .= $map[$ch] ?? '';
        if (strlen($result) >= $len) break;
    }
    $result = strtoupper(preg_replace('/[^A-Z]/', '', $result));
    return str_pad(substr($result, 0, $len), $len, 'X');
}

function sanitize($str) {
    return htmlspecialchars(strip_tags(trim($str)), ENT_QUOTES, 'UTF-8');
}

function hashPassword($plainPassword) {
    return password_hash($plainPassword, PASSWORD_DEFAULT);
}

function verifyPassword($plainPassword, $hashedPassword) {
    return password_verify($plainPassword, $hashedPassword);
}

function formatPrice($price) {
    return number_format($price, 0, '.', ',') . ' أوقية';
}

function getStatusBadge($status) {
    $badges = [
        'pending'         => ['label' => 'في الانتظار',          'class' => 'warning'],
        'payment_pending' => ['label' => '⏳ بانتظار تأكيد الدفع', 'class' => 'warning'],
        'confirmed'       => ['label' => 'مؤكد',                  'class' => 'success'],
        'cancelled'       => ['label' => 'ملغي',                  'class' => 'danger'],
        'completed'       => ['label' => 'مكتمل',                 'class' => 'info'],
    ];
    $b = $badges[$status] ?? ['label' => $status, 'class' => 'secondary'];
    return "<span class=\"badge bg-{$b['class']}\">{$b['label']}</span>";
}

// يتحقق مما إذا كان للرحلة أي حجز (بأي حالة)، يُستخدم لمنع حذف رحلة عليها حجوزات
function routeHasBookings($routeId) {
    try {
        $db = getDB();
        $stmt = $db->prepare("SELECT COUNT(*) FROM bookings WHERE route_id = ?");
        $stmt->execute([$routeId]);
        return (int)$stmt->fetchColumn() > 0;
    } catch (Exception $e) {
        return false;
    }
}

function getBookedSeats($routeId, $travelDate) {
    $db = getDB();
    $stmt = $db->prepare("SELECT SUM(seat_count) as total FROM bookings 
                          WHERE route_id = ? AND travel_date = ? AND status <> 'cancelled'");
    $stmt->execute([$routeId, $travelDate]);
    $row = $stmt->fetch(PDO::FETCH_ASSOC);
    return (int)($row['total'] ?? 0);
}

function ensureContactMessagesTable($db) {
    $db->exec("CREATE TABLE IF NOT EXISTS contact_messages (
        id INT AUTO_INCREMENT PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        phone VARCHAR(50) NOT NULL,
        email VARCHAR(150) NULL,
        subject VARCHAR(100) NULL,
        body TEXT NOT NULL,
        status ENUM('new','read','replied') NOT NULL DEFAULT 'new',
        admin_reply TEXT NULL,
        replied_by VARCHAR(100) NULL,
        replied_at DATETIME NULL,
        created_at DATETIME NOT NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
}

function getUnreadMessagesCount() {
    if (isCompanyRep()) return 0; // ممثل الشركة لا يرى الرسائل
    try {
        $db = getDB();
        ensureContactMessagesTable($db);
        $r = $db->query("SELECT COUNT(*) as cnt FROM contact_messages WHERE status='new'")->fetch();
        return (int)($r['cnt'] ?? 0);
    } catch (Exception $e) {
        return 0;
    }
}

// جلب الشركات النشطة من قاعدة البيانات
function getActiveCompanies() {
    static $cache = null;
    if ($cache !== null) return $cache;
    try {
        $db    = getDB();
        ensureCompaniesTable($db);
        $cache = $db->query("SELECT id, name FROM companies WHERE active=1 ORDER BY name")->fetchAll(PDO::FETCH_ASSOC);
        return $cache;
    } catch (Exception $e) {
        return [];
    }
}

// التأكد من وجود جدول الشركات
function ensureCompaniesTable($db) {
    $db->exec("CREATE TABLE IF NOT EXISTS companies (
        id         INT AUTO_INCREMENT PRIMARY KEY,
        name       VARCHAR(150) NOT NULL,
        name_fr    VARCHAR(150) NULL,
        phone      VARCHAR(50)  NULL,
        email      VARCHAR(150) NULL,
        address    TEXT         NULL,
        active     TINYINT(1)   NOT NULL DEFAULT 1,
        created_at DATETIME     NULL
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // إضافة company_id لجدول الرحلات إن لم يكن موجوداً
    try { $db->exec("ALTER TABLE routes ADD COLUMN company_id INT NULL AFTER company"); } catch(Exception $e){}
    // إضافة company_id لجدول المستخدمين إن لم يكن موجوداً
    try { $db->exec("ALTER TABLE users ADD COLUMN company_id INT NULL AFTER role"); } catch(Exception $e){}
}

function getMauritanianCities() {
    $fallback = [
        'نواكشوط', 'نواذيبو', 'روصو', 'زويرات', 'كيفة',
        'كيهيدي', 'سيلبابي', 'ألاك', 'تيجيكجة', 'أطار',
        'أيون', 'نمامقة', 'بوتلميت', 'مقطع لحجار', 'لعيون',
        'تمبدغة', 'وادان', 'شنقيط', 'تيشيت', 'ولاتة',
        'أكجوجت', 'بئر أم اكرين', 'فدريك'
    ];
    try {
        $db   = getDB();
        $rows = $db->query("SELECT name_ar FROM cities WHERE active=1 ORDER BY name_ar")->fetchAll(PDO::FETCH_COLUMN);
        return !empty($rows) ? $rows : $fallback;
    } catch (Exception $e) {
        return $fallback;
    }
}
?>
