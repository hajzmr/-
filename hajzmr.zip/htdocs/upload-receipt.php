<?php
require_once 'includes/db.php';
require_once 'includes/functions.php';

$ref = sanitize($_POST['booking_ref'] ?? '');
if (!$ref) {
    header('Location: check-booking.php?error=missing_ref');
    exit;
}

$uploaded = false;

if (!empty($_FILES['payment_receipt']['tmp_name']) && $_FILES['payment_receipt']['error'] === 0) {
    $file    = $_FILES['payment_receipt'];
    $allowed = ['image/jpeg','image/jpg','image/png','image/gif'];

    if (in_array($file['type'], $allowed) && $file['size'] <= 5 * 1024 * 1024) {
        $uploadDir = __DIR__ . '/uploads/receipts/';
        if (!is_dir($uploadDir)) {
            @mkdir($uploadDir, 0755, true);
        }
        $ext      = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
        $safeName = 'receipt_' . preg_replace('/[^A-Z0-9\-]/', '', strtoupper($ref)) . '_' . time() . '.' . $ext;
        $dest     = $uploadDir . $safeName;

        if (move_uploaded_file($file['tmp_name'], $dest)) {
            $savedPath = 'uploads/receipts/' . $safeName;
            $uploaded  = true;
            try {
                $db   = getDB();
                $stmt = $db->prepare(
                    "UPDATE bookings SET payment_receipt = ?, status = 'payment_pending' WHERE booking_ref = ?"
                );
                $stmt->execute([$savedPath, $ref]);
            } catch (Exception $e) {
                // dev mode — تم الحفظ على القرص على الأقل
            }
        }
    }
}

header('Location: check-booking.php?ref=' . urlencode($ref) .
       ($uploaded ? '&receipt=uploaded' : '&receipt=error'));
exit;
?>
